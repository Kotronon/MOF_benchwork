# Module B: korrigierte Gemisch-Auswertung

**Pilot ausgewertet; quantitative Referenzvalidierung offen**

Quelle: `outputs/module_B_active_learning/smoke/mof5/simulation/runs/al_00001_0bee5392768160b2f713/isotherm_summary.json`

Framework-Masse: 6158.936 u. Herkunft: `outputs/module_B_active_learning/smoke/mof5/simulation/runs/al_00001_0bee5392768160b2f713/data/IRMOF-1.data`.

Komponenten und Gesamtbeladung sind absolute Adsorption; mol/kg = mmol/g. Selektivität ist dimensionslos.
95-%-Intervalle beschreiben die Streuung unabhängiger Seed-Mittelwerte. Komponenten: Student-t; Selektivität: Fieller mit gepaarten Seeds.
Das Präzisionskriterium ist kein Nachweis der Equilibrierung. Unbeschränkte/undefinierte Intervalle erfüllen es nicht.

Präzisionsziel: relative Intervallhalbbreite ≤ 20 %, mindestens 3 Seeds.

| Druck / bar | Größe | Wert | Einheit | 95-%-Intervall | relative Halbbreite | Intervallstatus | Präzisionsziel (Größe) | Präzisionsziel (Punkt) |
|---:|:---|---:|:---|:---|---:|:---|:---|:---|
| 10 | CO2 | 0.796289 | mol/kg | [0.282032, 1.31055] | 64.58 % | bounded | nein | nein |
| 10 | N2 | 1.86372 | mol/kg | [1.0396, 2.68785] | 44.22 % | bounded | nein | nein |
| 10 | total | 2.66001 | mol/kg | [2.30737, 3.01265] | 13.26 % | bounded | — | nein |
| 10 | CO2/N2 | 3.84531 | dimensionless | [0.952721, 11.246] | 133.84 % | bounded | nein | nein |
| 10 | N2/CO2 | 0.260057 | dimensionless | [0.0889203, 1.04962] | 184.71 % | bounded | nein | nein |

## Referenzprüfung

Reingasisothermen werden nicht als Gemischreferenz verwendet. Unbekannte Adsorptionsbasis wird nicht als absolut interpretiert.


Ein bisheriger Vergleich von CO₂+N₂-Gesamtbeladung mit reinem CO₂ ist ungültig; daraus abgeleitete Fehlerprozente sind kein Validierungsergebnis.
