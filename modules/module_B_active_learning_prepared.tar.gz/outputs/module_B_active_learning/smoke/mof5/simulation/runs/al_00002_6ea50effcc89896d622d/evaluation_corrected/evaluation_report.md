# Module B: korrigierte Gemisch-Auswertung

**Pilot ausgewertet; quantitative Referenzvalidierung offen**

Quelle: `outputs/module_B_active_learning/smoke/mof5/simulation/runs/al_00002_6ea50effcc89896d622d/isotherm_summary.json`

Framework-Masse: 6158.936 u. Herkunft: `outputs/module_B_active_learning/smoke/mof5/simulation/runs/al_00002_6ea50effcc89896d622d/data/IRMOF-1.data`.

Komponenten und Gesamtbeladung sind absolute Adsorption; mol/kg = mmol/g. Selektivität ist dimensionslos.
95-%-Intervalle beschreiben die Streuung unabhängiger Seed-Mittelwerte. Komponenten: Student-t; Selektivität: Fieller mit gepaarten Seeds.
Das Präzisionskriterium ist kein Nachweis der Equilibrierung. Unbeschränkte/undefinierte Intervalle erfüllen es nicht.

Präzisionsziel: relative Intervallhalbbreite ≤ 20 %, mindestens 3 Seeds.

| Druck / bar | Größe | Wert | Einheit | 95-%-Intervall | relative Halbbreite | Intervallstatus | Präzisionsziel (Größe) | Präzisionsziel (Punkt) |
|---:|:---|---:|:---|:---|---:|:---|:---|:---|
| 1 | CO2 | 0.768424 | mol/kg | [0.529164, 1.00768] | 31.14 % | bounded | nein | nein |
| 1 | N2 | 0.0257213 | mol/kg | [0.0113215, 0.0401211] | 55.98 % | bounded | nein | nein |
| 1 | total | 0.794145 | mol/kg | [0.555987, 1.0323] | 29.99 % | bounded | — | nein |
| 1 | CO2/N2 | 3.31944 | dimensionless | [1.80074, 8.04822] | 94.10 % | bounded | nein | nein |
| 1 | N2/CO2 | 0.301255 | dimensionless | [0.124251, 0.555326] | 71.55 % | bounded | nein | nein |

## Referenzprüfung

Reingasisothermen werden nicht als Gemischreferenz verwendet. Unbekannte Adsorptionsbasis wird nicht als absolut interpretiert.


Ein bisheriger Vergleich von CO₂+N₂-Gesamtbeladung mit reinem CO₂ ist ungültig; daraus abgeleitete Fehlerprozente sind kein Validierungsergebnis.
