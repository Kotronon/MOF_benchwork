# Module B: korrigierte Gemisch-Auswertung

**Pilot ausgewertet; quantitative Referenzvalidierung offen**

Quelle: `outputs/module_B_active_learning/smoke/mof5/simulation/runs/al_00003_47ec45e345926d31acda/isotherm_summary.json`

Framework-Masse: 6158.936 u. Herkunft: `outputs/module_B_active_learning/smoke/mof5/simulation/runs/al_00003_47ec45e345926d31acda/data/IRMOF-1.data`.

Komponenten und Gesamtbeladung sind absolute Adsorption; mol/kg = mmol/g. Selektivität ist dimensionslos.
95-%-Intervalle beschreiben die Streuung unabhängiger Seed-Mittelwerte. Komponenten: Student-t; Selektivität: Fieller mit gepaarten Seeds.
Das Präzisionskriterium ist kein Nachweis der Equilibrierung. Unbeschränkte/undefinierte Intervalle erfüllen es nicht.

Präzisionsziel: relative Intervallhalbbreite ≤ 20 %, mindestens 3 Seeds.

| Druck / bar | Größe | Wert | Einheit | 95-%-Intervall | relative Halbbreite | Intervallstatus | Präzisionsziel (Größe) | Präzisionsziel (Punkt) |
|---:|:---|---:|:---|:---|---:|:---|:---|:---|
| 5 | CO2 | 1.838 | mol/kg | [1.58781, 2.08819] | 13.61 % | bounded | ja | nein |
| 5 | N2 | 0.568012 | mol/kg | [0.398508, 0.737516] | 29.84 % | bounded | nein | nein |
| 5 | total | 2.40601 | mol/kg | [2.14381, 2.66822] | 10.90 % | bounded | — | nein |
| 5 | CO2/N2 | 3.23585 | dimensionless | [2.32135, 4.85982] | 39.22 % | bounded | nein | nein |
| 5 | N2/CO2 | 0.309038 | dimensionless | [0.205769, 0.430784] | 36.41 % | bounded | nein | nein |

## Referenzprüfung

Reingasisothermen werden nicht als Gemischreferenz verwendet. Unbekannte Adsorptionsbasis wird nicht als absolut interpretiert.


Ein bisheriger Vergleich von CO₂+N₂-Gesamtbeladung mit reinem CO₂ ist ungültig; daraus abgeleitete Fehlerprozente sind kein Validierungsergebnis.
