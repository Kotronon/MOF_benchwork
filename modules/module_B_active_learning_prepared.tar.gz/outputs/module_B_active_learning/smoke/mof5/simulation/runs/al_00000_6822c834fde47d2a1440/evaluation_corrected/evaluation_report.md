# Module B: korrigierte Gemisch-Auswertung

**Pilot ausgewertet; quantitative Referenzvalidierung offen**

Quelle: `outputs/module_B_active_learning/smoke/mof5/simulation/runs/al_00000_6822c834fde47d2a1440/isotherm_summary.json`

Framework-Masse: 6158.936 u. Herkunft: `outputs/module_B_active_learning/smoke/mof5/simulation/runs/al_00000_6822c834fde47d2a1440/data/IRMOF-1.data`.

Komponenten und Gesamtbeladung sind absolute Adsorption; mol/kg = mmol/g. Selektivität ist dimensionslos.
95-%-Intervalle beschreiben die Streuung unabhängiger Seed-Mittelwerte. Komponenten: Student-t; Selektivität: Fieller mit gepaarten Seeds.
Das Präzisionskriterium ist kein Nachweis der Equilibrierung. Unbeschränkte/undefinierte Intervalle erfüllen es nicht.

Präzisionsziel: relative Intervallhalbbreite ≤ 20 %, mindestens 3 Seeds.

| Druck / bar | Größe | Wert | Einheit | 95-%-Intervall | relative Halbbreite | Intervallstatus | Präzisionsziel (Größe) | Präzisionsziel (Punkt) |
|---:|:---|---:|:---|:---|---:|:---|:---|:---|
| 0.1 | CO2 | 0.00803791 | mol/kg | [0.00404413, 0.0120317] | 49.69 % | bounded | nein | nein |
| 0.1 | N2 | 0.0187551 | mol/kg | [0.0104414, 0.0270688] | 44.33 % | bounded | nein | nein |
| 0.1 | total | 0.026793 | mol/kg | [0.0145918, 0.0389942] | 45.54 % | bounded | — | nein |
| 0.1 | CO2/N2 | 3.85714 | dimensionless | [3.16943, 4.39974] | 15.95 % | bounded | ja | nein |
| 0.1 | N2/CO2 | 0.259259 | dimensionless | [0.227286, 0.315514] | 17.02 % | bounded | ja | nein |

## Referenzprüfung

Reingasisothermen werden nicht als Gemischreferenz verwendet. Unbekannte Adsorptionsbasis wird nicht als absolut interpretiert.


Ein bisheriger Vergleich von CO₂+N₂-Gesamtbeladung mit reinem CO₂ ist ungültig; daraus abgeleitete Fehlerprozente sind kein Validierungsergebnis.
