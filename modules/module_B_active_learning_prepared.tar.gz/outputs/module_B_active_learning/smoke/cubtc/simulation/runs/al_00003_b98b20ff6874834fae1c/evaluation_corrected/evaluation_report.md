# Module B: korrigierte Gemisch-Auswertung

**Pilot ausgewertet; quantitative Referenzvalidierung offen**

Quelle: `outputs/module_B_active_learning/smoke/cubtc/simulation/runs/al_00003_b98b20ff6874834fae1c/isotherm_summary.json`

Framework-Masse: 9677.952 u. Herkunft: `outputs/module_B_active_learning/smoke/cubtc/simulation/runs/al_00003_b98b20ff6874834fae1c/data/Cu-BTC.data`.

Komponenten und Gesamtbeladung sind absolute Adsorption; mol/kg = mmol/g. Selektivität ist dimensionslos.
95-%-Intervalle beschreiben die Streuung unabhängiger Seed-Mittelwerte. Komponenten: Student-t; Selektivität: Fieller mit gepaarten Seeds.
Das Präzisionskriterium ist kein Nachweis der Equilibrierung. Unbeschränkte/undefinierte Intervalle erfüllen es nicht.

Präzisionsziel: relative Intervallhalbbreite ≤ 20 %, mindestens 3 Seeds.

| Druck / bar | Größe | Wert | Einheit | 95-%-Intervall | relative Halbbreite | Intervallstatus | Präzisionsziel (Größe) | Präzisionsziel (Punkt) |
|---:|:---|---:|:---|:---|---:|:---|:---|:---|
| 5 | CO2 | 3.31228 | mol/kg | [1.74066, 4.8839] | 47.45 % | bounded | nein | nein |
| 5 | N2 | 0.616556 | mol/kg | [0.233607, 0.999505] | 62.11 % | bounded | nein | nein |
| 5 | total | 3.92884 | mol/kg | [2.73665, 5.12102] | 30.34 % | bounded | — | nein |
| 5 | CO2/N2 | 5.37223 | dimensionless | [1.74478, 20.8675] | 177.98 % | bounded | nein | nein |
| 5 | N2/CO2 | 0.186142 | dimensionless | [0.0479215, 0.573137] | 141.08 % | bounded | nein | nein |

## Referenzprüfung

Reingasisothermen werden nicht als Gemischreferenz verwendet. Unbekannte Adsorptionsbasis wird nicht als absolut interpretiert.


Ein bisheriger Vergleich von CO₂+N₂-Gesamtbeladung mit reinem CO₂ ist ungültig; daraus abgeleitete Fehlerprozente sind kein Validierungsergebnis.
