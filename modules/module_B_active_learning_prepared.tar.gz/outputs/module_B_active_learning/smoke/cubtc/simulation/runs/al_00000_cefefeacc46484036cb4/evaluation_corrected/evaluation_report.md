# Module B: korrigierte Gemisch-Auswertung

**Pilot ausgewertet; quantitative Referenzvalidierung offen**

Quelle: `outputs/module_B_active_learning/smoke/cubtc/simulation/runs/al_00000_cefefeacc46484036cb4/isotherm_summary.json`

Framework-Masse: 9677.952 u. Herkunft: `outputs/module_B_active_learning/smoke/cubtc/simulation/runs/al_00000_cefefeacc46484036cb4/data/Cu-BTC.data`.

Komponenten und Gesamtbeladung sind absolute Adsorption; mol/kg = mmol/g. Selektivität ist dimensionslos.
95-%-Intervalle beschreiben die Streuung unabhängiger Seed-Mittelwerte. Komponenten: Student-t; Selektivität: Fieller mit gepaarten Seeds.
Das Präzisionskriterium ist kein Nachweis der Equilibrierung. Unbeschränkte/undefinierte Intervalle erfüllen es nicht.

Präzisionsziel: relative Intervallhalbbreite ≤ 20 %, mindestens 3 Seeds.

| Druck / bar | Größe | Wert | Einheit | 95-%-Intervall | relative Halbbreite | Intervallstatus | Präzisionsziel (Größe) | Präzisionsziel (Punkt) |
|---:|:---|---:|:---|:---|---:|:---|:---|:---|
| 0.1 | CO2 | 0.0511523 | mol/kg | [-0.0187761, 0.121081] | 136.71 % | bounded | nein | nein |
| 0.1 | N2 | 0.0572906 | mol/kg | [0.00570189, 0.108879] | 90.05 % | bounded | nein | nein |
| 0.1 | total | 0.108443 | mol/kg | [-0.0127833, 0.229669] | 111.79 % | bounded | — | nein |
| 0.1 | CO2/N2 | 8.03571 | dimensionless | [-28.8765, 10.2721] | 243.59 % | bounded | nein | nein |
| 0.1 | N2/CO2 | 0.124444 | dimensionless | — | — | unbounded | nein | nein |

## Referenzprüfung

Reingasisothermen werden nicht als Gemischreferenz verwendet. Unbekannte Adsorptionsbasis wird nicht als absolut interpretiert.


Ein bisheriger Vergleich von CO₂+N₂-Gesamtbeladung mit reinem CO₂ ist ungültig; daraus abgeleitete Fehlerprozente sind kein Validierungsergebnis.
