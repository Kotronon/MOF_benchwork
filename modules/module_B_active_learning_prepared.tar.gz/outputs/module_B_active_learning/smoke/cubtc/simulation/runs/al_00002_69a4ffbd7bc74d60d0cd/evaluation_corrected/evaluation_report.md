# Module B: korrigierte Gemisch-Auswertung

**Pilot ausgewertet; quantitative Referenzvalidierung offen**

Quelle: `outputs/module_B_active_learning/smoke/cubtc/simulation/runs/al_00002_69a4ffbd7bc74d60d0cd/isotherm_summary.json`

Framework-Masse: 9677.952 u. Herkunft: `outputs/module_B_active_learning/smoke/cubtc/simulation/runs/al_00002_69a4ffbd7bc74d60d0cd/data/Cu-BTC.data`.

Komponenten und Gesamtbeladung sind absolute Adsorption; mol/kg = mmol/g. Selektivität ist dimensionslos.
95-%-Intervalle beschreiben die Streuung unabhängiger Seed-Mittelwerte. Komponenten: Student-t; Selektivität: Fieller mit gepaarten Seeds.
Das Präzisionskriterium ist kein Nachweis der Equilibrierung. Unbeschränkte/undefinierte Intervalle erfüllen es nicht.

Präzisionsziel: relative Intervallhalbbreite ≤ 20 %, mindestens 3 Seeds.

| Druck / bar | Größe | Wert | Einheit | 95-%-Intervall | relative Halbbreite | Intervallstatus | Präzisionsziel (Größe) | Präzisionsziel (Punkt) |
|---:|:---|---:|:---|:---|---:|:---|:---|:---|
| 1 | CO2 | 1.60277 | mol/kg | [0.447098, 2.75845] | 72.10 % | bounded | nein | nein |
| 1 | N2 | 0.0470601 | mol/kg | [0.0272096, 0.0669106] | 42.18 % | bounded | nein | nein |
| 1 | total | 1.64983 | mol/kg | [0.513398, 2.78627] | 68.88 % | bounded | — | nein |
| 1 | CO2/N2 | 3.78422 | dimensionless | [0.748472, 11.1735] | 137.74 % | bounded | nein | nein |
| 1 | N2/CO2 | 0.264255 | dimensionless | [0.0894975, 1.33606] | 235.86 % | bounded | nein | nein |

## Referenzprüfung

Reingasisothermen werden nicht als Gemischreferenz verwendet. Unbekannte Adsorptionsbasis wird nicht als absolut interpretiert.


Ein bisheriger Vergleich von CO₂+N₂-Gesamtbeladung mit reinem CO₂ ist ungültig; daraus abgeleitete Fehlerprozente sind kein Validierungsergebnis.
