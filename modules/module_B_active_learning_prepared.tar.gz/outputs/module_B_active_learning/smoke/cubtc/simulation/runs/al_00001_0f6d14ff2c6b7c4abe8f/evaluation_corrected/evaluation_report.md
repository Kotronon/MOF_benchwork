# Module B: korrigierte Gemisch-Auswertung

**Pilot ausgewertet; quantitative Referenzvalidierung offen**

Quelle: `outputs/module_B_active_learning/smoke/cubtc/simulation/runs/al_00001_0f6d14ff2c6b7c4abe8f/isotherm_summary.json`

Framework-Masse: 9677.952 u. Herkunft: `outputs/module_B_active_learning/smoke/cubtc/simulation/runs/al_00001_0f6d14ff2c6b7c4abe8f/data/Cu-BTC.data`.

Komponenten und Gesamtbeladung sind absolute Adsorption; mol/kg = mmol/g. Selektivität ist dimensionslos.
95-%-Intervalle beschreiben die Streuung unabhängiger Seed-Mittelwerte. Komponenten: Student-t; Selektivität: Fieller mit gepaarten Seeds.
Das Präzisionskriterium ist kein Nachweis der Equilibrierung. Unbeschränkte/undefinierte Intervalle erfüllen es nicht.

Präzisionsziel: relative Intervallhalbbreite ≤ 20 %, mindestens 3 Seeds.

| Druck / bar | Größe | Wert | Einheit | 95-%-Intervall | relative Halbbreite | Intervallstatus | Präzisionsziel (Größe) | Präzisionsziel (Punkt) |
|---:|:---|---:|:---|:---|---:|:---|:---|:---|
| 10 | CO2 | 1.82648 | mol/kg | [0.7491, 2.90386] | 58.99 % | bounded | nein | nein |
| 10 | N2 | 1.79715 | mol/kg | [1.16248, 2.43182] | 35.32 % | bounded | nein | nein |
| 10 | total | 3.62363 | mol/kg | [2.54012, 4.70714] | 29.90 % | bounded | — | nein |
| 10 | CO2/N2 | 9.14687 | dimensionless | [3.30991, 18.8307] | 84.84 % | bounded | nein | nein |
| 10 | N2/CO2 | 0.109327 | dimensionless | [0.0531047, 0.302123] | 113.89 % | bounded | nein | nein |

## Referenzprüfung

Reingasisothermen werden nicht als Gemischreferenz verwendet. Unbekannte Adsorptionsbasis wird nicht als absolut interpretiert.


Ein bisheriger Vergleich von CO₂+N₂-Gesamtbeladung mit reinem CO₂ ist ungültig; daraus abgeleitete Fehlerprozente sind kein Validierungsergebnis.
