# Module B: korrigierte Gemisch-Auswertung

**Pilot ausgewertet; quantitative Referenzvalidierung offen**

Quelle: `outputs/module_B_active_learning/smoke/zif8/simulation/runs/al_00000_cefefeacc46484036cb4/isotherm_summary.json`

Framework-Masse: 21847.296 u. Herkunft: `outputs/module_B_active_learning/smoke/zif8/simulation/runs/al_00000_cefefeacc46484036cb4/data/ZIF-8.data`.

Komponenten und Gesamtbeladung sind absolute Adsorption; mol/kg = mmol/g. Selektivität ist dimensionslos.
95-%-Intervalle beschreiben die Streuung unabhängiger Seed-Mittelwerte. Komponenten: Student-t; Selektivität: Fieller mit gepaarten Seeds.
Das Präzisionskriterium ist kein Nachweis der Equilibrierung. Unbeschränkte/undefinierte Intervalle erfüllen es nicht.

Präzisionsziel: relative Intervallhalbbreite ≤ 20 %, mindestens 3 Seeds.

| Druck / bar | Größe | Wert | Einheit | 95-%-Intervall | relative Halbbreite | Intervallstatus | Präzisionsziel (Größe) | Präzisionsziel (Punkt) |
|---:|:---|---:|:---|:---|---:|:---|:---|:---|
| 0.1 | CO2 | 0.0108766 | mol/kg | [0.00125706, 0.0204961] | 88.44 % | bounded | nein | nein |
| 0.1 | N2 | 0.0252276 | mol/kg | [0.0179022, 0.032553] | 29.04 % | bounded | nein | nein |
| 0.1 | total | 0.0361042 | mol/kg | [0.0284405, 0.0437679] | 21.23 % | bounded | — | nein |
| 0.1 | CO2/N2 | 3.88024 | dimensionless | [0.379082, 9.44674] | 116.84 % | bounded | nein | nein |
| 0.1 | N2/CO2 | 0.257716 | dimensionless | [0.105857, 2.63795] | 491.26 % | bounded | nein | nein |

## Referenzprüfung

Reingasisothermen werden nicht als Gemischreferenz verwendet. Unbekannte Adsorptionsbasis wird nicht als absolut interpretiert.


Ein bisheriger Vergleich von CO₂+N₂-Gesamtbeladung mit reinem CO₂ ist ungültig; daraus abgeleitete Fehlerprozente sind kein Validierungsergebnis.
