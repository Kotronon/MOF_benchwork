# Module B: korrigierte Gemisch-Auswertung

**Pilot ausgewertet; quantitative Referenzvalidierung offen**

Quelle: `outputs/module_B_active_learning/smoke/zif8/simulation/runs/al_00003_b98b20ff6874834fae1c/isotherm_summary.json`

Framework-Masse: 21847.296 u. Herkunft: `outputs/module_B_active_learning/smoke/zif8/simulation/runs/al_00003_b98b20ff6874834fae1c/data/ZIF-8.data`.

Komponenten und Gesamtbeladung sind absolute Adsorption; mol/kg = mmol/g. Selektivität ist dimensionslos.
95-%-Intervalle beschreiben die Streuung unabhängiger Seed-Mittelwerte. Komponenten: Student-t; Selektivität: Fieller mit gepaarten Seeds.
Das Präzisionskriterium ist kein Nachweis der Equilibrierung. Unbeschränkte/undefinierte Intervalle erfüllen es nicht.

Präzisionsziel: relative Intervallhalbbreite ≤ 20 %, mindestens 3 Seeds.

| Druck / bar | Größe | Wert | Einheit | 95-%-Intervall | relative Halbbreite | Intervallstatus | Präzisionsziel (Größe) | Präzisionsziel (Punkt) |
|---:|:---|---:|:---|:---|---:|:---|:---|:---|
| 5 | CO2 | 1.57544 | mol/kg | [1.45098, 1.6999] | 7.90 % | bounded | ja | ja |
| 5 | N2 | 0.550022 | mol/kg | [0.499655, 0.60039] | 9.16 % | bounded | ja | ja |
| 5 | total | 2.12546 | mol/kg | [1.95528, 2.29565] | 8.01 % | bounded | — | ja |
| 5 | CO2/N2 | 2.86432 | dimensionless | [2.74134, 2.9993] | 4.50 % | bounded | ja | ja |
| 5 | N2/CO2 | 0.349123 | dimensionless | [0.333411, 0.364785] | 4.49 % | bounded | ja | ja |

## Referenzprüfung

Reingasisothermen werden nicht als Gemischreferenz verwendet. Unbekannte Adsorptionsbasis wird nicht als absolut interpretiert.


Ein bisheriger Vergleich von CO₂+N₂-Gesamtbeladung mit reinem CO₂ ist ungültig; daraus abgeleitete Fehlerprozente sind kein Validierungsergebnis.
