# Module B: korrigierte Gemisch-Auswertung

**Pilot ausgewertet; quantitative Referenzvalidierung offen**

Quelle: `outputs/module_B_active_learning/smoke/zif8/simulation/runs/al_00001_0f6d14ff2c6b7c4abe8f/isotherm_summary.json`

Framework-Masse: 21847.296 u. Herkunft: `outputs/module_B_active_learning/smoke/zif8/simulation/runs/al_00001_0f6d14ff2c6b7c4abe8f/data/ZIF-8.data`.

Komponenten und Gesamtbeladung sind absolute Adsorption; mol/kg = mmol/g. Selektivität ist dimensionslos.
95-%-Intervalle beschreiben die Streuung unabhängiger Seed-Mittelwerte. Komponenten: Student-t; Selektivität: Fieller mit gepaarten Seeds.
Das Präzisionskriterium ist kein Nachweis der Equilibrierung. Unbeschränkte/undefinierte Intervalle erfüllen es nicht.

Präzisionsziel: relative Intervallhalbbreite ≤ 20 %, mindestens 3 Seeds.

| Druck / bar | Größe | Wert | Einheit | 95-%-Intervall | relative Halbbreite | Intervallstatus | Präzisionsziel (Größe) | Präzisionsziel (Punkt) |
|---:|:---|---:|:---|:---|---:|:---|:---|:---|
| 10 | CO2 | 1.09597 | mol/kg | [0.615247, 1.57669] | 43.86 % | bounded | nein | nein |
| 10 | N2 | 1.37649 | mol/kg | [1.06797, 1.68502] | 22.41 % | bounded | nein | nein |
| 10 | total | 2.47246 | mol/kg | [2.24116, 2.70375] | 9.35 % | bounded | — | nein |
| 10 | CO2/N2 | 7.16583 | dimensionless | [3.32598, 13.128] | 68.39 % | bounded | nein | nein |
| 10 | N2/CO2 | 0.139551 | dimensionless | [0.0761731, 0.300663] | 80.43 % | bounded | nein | nein |

## Referenzprüfung

Reingasisothermen werden nicht als Gemischreferenz verwendet. Unbekannte Adsorptionsbasis wird nicht als absolut interpretiert.


Ein bisheriger Vergleich von CO₂+N₂-Gesamtbeladung mit reinem CO₂ ist ungültig; daraus abgeleitete Fehlerprozente sind kein Validierungsergebnis.
