# Module B: korrigierte Gemisch-Auswertung

**Pilot ausgewertet; quantitative Referenzvalidierung offen**

Quelle: `outputs/module_B_active_learning/smoke/zif8/simulation/runs/al_00002_69a4ffbd7bc74d60d0cd/isotherm_summary.json`

Framework-Masse: 21847.296 u. Herkunft: `outputs/module_B_active_learning/smoke/zif8/simulation/runs/al_00002_69a4ffbd7bc74d60d0cd/data/ZIF-8.data`.

Komponenten und Gesamtbeladung sind absolute Adsorption; mol/kg = mmol/g. Selektivität ist dimensionslos.
95-%-Intervalle beschreiben die Streuung unabhängiger Seed-Mittelwerte. Komponenten: Student-t; Selektivität: Fieller mit gepaarten Seeds.
Das Präzisionskriterium ist kein Nachweis der Equilibrierung. Unbeschränkte/undefinierte Intervalle erfüllen es nicht.

Präzisionsziel: relative Intervallhalbbreite ≤ 20 %, mindestens 3 Seeds.

| Druck / bar | Größe | Wert | Einheit | 95-%-Intervall | relative Halbbreite | Intervallstatus | Präzisionsziel (Größe) | Präzisionsziel (Punkt) |
|---:|:---|---:|:---|:---|---:|:---|:---|:---|
| 1 | CO2 | 1.15458 | mol/kg | [0.375504, 1.93365] | 67.48 % | bounded | nein | nein |
| 1 | N2 | 0.0216021 | mol/kg | [0.0179829, 0.0252213] | 16.75 % | bounded | ja | nein |
| 1 | total | 1.17618 | mol/kg | [0.397478, 1.95488] | 66.21 % | bounded | — | nein |
| 1 | CO2/N2 | 5.93862 | dimensionless | [1.88609, 10.479] | 72.35 % | bounded | nein | nein |
| 1 | N2/CO2 | 0.168389 | dimensionless | [0.0954292, 0.530196] | 129.10 % | bounded | nein | nein |

## Referenzprüfung

Reingasisothermen werden nicht als Gemischreferenz verwendet. Unbekannte Adsorptionsbasis wird nicht als absolut interpretiert.


Ein bisheriger Vergleich von CO₂+N₂-Gesamtbeladung mit reinem CO₂ ist ungültig; daraus abgeleitete Fehlerprozente sind kein Validierungsergebnis.
