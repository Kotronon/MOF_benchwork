# Module B: korrigierte Gemisch-Auswertung

**Pilot ausgewertet; quantitative Referenzvalidierung offen**

Quelle: `outputs/module_B_mixture_selectivity/runs/mof5_co2_n2_validation_pilot_2_longer/isotherm_summary.json`

Framework-Masse: 6158.936 u. Herkunft: `outputs/module_B_mixture_selectivity/runs/mof5_co2_n2_validation_pilot_2_longer/data/IRMOF-1.data`.

Komponenten und Gesamtbeladung sind absolute Adsorption; mol/kg = mmol/g. Selektivität ist dimensionslos.
95-%-Intervalle beschreiben die Streuung unabhängiger Seed-Mittelwerte. Komponenten: Student-t; Selektivität: Fieller mit gepaarten Seeds.
Das Präzisionskriterium ist kein Nachweis der Equilibrierung. Unbeschränkte/undefinierte Intervalle erfüllen es nicht.

Präzisionsziel: relative Intervallhalbbreite ≤ 20 %, mindestens 3 Seeds.

| Druck / bar | Größe | Wert | Einheit | 95-%-Intervall | relative Halbbreite | Intervallstatus | Präzisionsziel (Größe) | Präzisionsziel (Punkt) |
|---:|:---|---:|:---|:---|---:|:---|:---|:---|
| 0.1 | CO2 | 0.0125312 | mol/kg | [0.00917919, 0.0158833] | 26.75 % | bounded | nein | nein |
| 0.1 | N2 | 0.0165282 | mol/kg | [0.0165282, 0.0165282] | 0.00 % | bounded | ja | nein |
| 0.1 | total | 0.0290595 | mol/kg | [0.0257074, 0.0324115] | 11.54 % | bounded | — | nein |
| 0.1 | CO2/N2 | 4.2963 | dimensionless | [3.14706, 5.44553] | 26.75 % | bounded | nein | nein |
| 0.1 | N2/CO2 | 0.232759 | dimensionless | [0.183637, 0.317757] | 28.81 % | bounded | nein | nein |
| 1 | CO2 | 0.131794 | mol/kg | [0.105925, 0.157663] | 19.63 % | bounded | ja | ja |
| 1 | N2 | 0.183431 | mol/kg | [0.16852, 0.198342] | 8.13 % | bounded | ja | ja |
| 1 | total | 0.315225 | mol/kg | [0.276609, 0.353841] | 12.25 % | bounded | — | ja |
| 1 | CO2/N2 | 4.07146 | dimensionless | [3.46475, 4.63067] | 14.32 % | bounded | ja | ja |
| 1 | N2/CO2 | 0.245612 | dimensionless | [0.215951, 0.288621] | 14.79 % | bounded | ja | ja |
| 5 | CO2 | 0.658429 | mol/kg | [0.616988, 0.699871] | 6.29 % | bounded | ja | ja |
| 5 | N2 | 0.904408 | mol/kg | [0.852128, 0.956688] | 5.78 % | bounded | ja | ja |
| 5 | total | 1.56284 | mol/kg | [1.50779, 1.61788] | 3.52 % | bounded | — | ja |
| 5 | CO2/N2 | 4.12546 | dimensionless | [3.73705, 4.55141] | 9.87 % | bounded | ja | ja |
| 5 | N2/CO2 | 0.242397 | dimensionless | [0.219712, 0.267591] | 9.88 % | bounded | ja | ja |
| 10 | CO2 | 1.34991 | mol/kg | [1.31239, 1.38744] | 2.78 % | bounded | ja | ja |
| 10 | N2 | 1.73417 | mol/kg | [1.68106, 1.78728] | 3.06 % | bounded | ja | ja |
| 10 | total | 3.08408 | mol/kg | [3.0082, 3.15996] | 2.46 % | bounded | — | ja |
| 10 | CO2/N2 | 4.41106 | dimensionless | [4.27022, 4.55728] | 3.25 % | bounded | ja | ja |
| 10 | N2/CO2 | 0.226703 | dimensionless | [0.219429, 0.23418] | 3.25 % | bounded | ja | ja |

## Referenzprüfung

Reingasisothermen werden nicht als Gemischreferenz verwendet. Unbekannte Adsorptionsbasis wird nicht als absolut interpretiert.

- 0.1 bar, `DDEC_IRMOF-1_UFF_CO2_298.csv`: pure_component_or_missing_mixture_metadata
- 0.1 bar, `DDEC_IRMOF-1_UFF_N2_298.csv`: pure_component_or_missing_mixture_metadata
- 0.1 bar, `10.1016j.seppur.2018.01.013.Isotherm4.json`: adsorption_basis_unknown, composition_mismatch_or_missing_component_data
- 0.1 bar, `10.1039b807470d.Isotherm14.json`: composition_mismatch_or_missing_component_data, excess_reference_requires_mixture_conversion
- 1 bar, `DDEC_IRMOF-1_UFF_CO2_298.csv`: pure_component_or_missing_mixture_metadata
- 1 bar, `DDEC_IRMOF-1_UFF_N2_298.csv`: pure_component_or_missing_mixture_metadata
- 1 bar, `10.1016j.seppur.2018.01.013.Isotherm4.json`: adsorption_basis_unknown, composition_mismatch_or_missing_component_data
- 1 bar, `10.1039b807470d.Isotherm14.json`: composition_mismatch_or_missing_component_data, excess_reference_requires_mixture_conversion
- 5 bar, `DDEC_IRMOF-1_UFF_CO2_298.csv`: pure_component_or_missing_mixture_metadata
- 5 bar, `DDEC_IRMOF-1_UFF_N2_298.csv`: pure_component_or_missing_mixture_metadata
- 5 bar, `10.1016j.seppur.2018.01.013.Isotherm4.json`: adsorption_basis_unknown, composition_mismatch_or_missing_component_data
- 5 bar, `10.1039b807470d.Isotherm14.json`: composition_mismatch_or_missing_component_data, excess_reference_requires_mixture_conversion
- 10 bar, `DDEC_IRMOF-1_UFF_CO2_298.csv`: pure_component_or_missing_mixture_metadata
- 10 bar, `DDEC_IRMOF-1_UFF_N2_298.csv`: pure_component_or_missing_mixture_metadata
- 10 bar, `10.1016j.seppur.2018.01.013.Isotherm4.json`: adsorption_basis_unknown, composition_mismatch_or_missing_component_data
- 10 bar, `10.1039b807470d.Isotherm14.json`: composition_mismatch_or_missing_component_data, excess_reference_requires_mixture_conversion

Ein bisheriger Vergleich von CO₂+N₂-Gesamtbeladung mit reinem CO₂ ist ungültig; daraus abgeleitete Fehlerprozente sind kein Validierungsergebnis.
