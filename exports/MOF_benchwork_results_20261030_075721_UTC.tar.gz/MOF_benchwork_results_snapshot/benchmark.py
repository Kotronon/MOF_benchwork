from __future__ import annotations

import argparse
import json
from pathlib import Path

from pipeline.config import (
    DEFAULT_PRESSURES_BAR,
    data_to_dict,
    load_benchmark_data,
    normalize_config,
    save_benchmark_data,
)
from pipeline.eos import fugacity_coeff_coolprop
from pipeline.evaluate import evaluate_all_references, evaluate_run_directory
from pipeline.lammps_inputs import gcmc_input_builder
from pipeline.materialization import materialize_benchmark
from pipeline.nist_isodb_parser import find_nist_isotherm_candidates, load_nist_isotherm
from pipeline.planning import build_run_plan, resolve_benchmark, select_module
from pipeline.prepare import prepare, prepare_benchmark, timestamp_run_id
from pipeline.registry_generation import write_generated_registries
from pipeline.runners import run_benchmark, run_isotherm
from pipeline.variants import build_variant_plans, run_variant_benchmark
from modules.module_c_mlips.workflow import run_potential_benchmark
from modules.module_b_selectivity import (
    initialize_campaign_state,
    initialize_campaign_state_from_isotherm,
)
from modules.module_c_mlips.dependencies import (
    ensure_mlip_mc_dependencies,
    ensure_torch_dftd,
)
from modules.module_c_mlips.mlip_mc_workflow import run_mlip_mc_benchmark
from modules.module_c_mlips.model_assets import ensure_model_asset
from modules.module_c_mlips.datasets import ensure_golddac_dataset
from modules.module_c_mlips.potential_backends.calculators import build_ase_calculator
from modules.module_c_mlips.campaign import (
    analyze_module_c_campaign,
    cross_check_campaign_engine,
    run_module_c_campaign,
    setup_module_c,
)
from modules.module_c_mlips.strategy_comparison import run_strategy_comparison

def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Plan a MOF benchmark run from benchmark.json.")
    parser.add_argument("config", nargs="?", default="benchmark.json", help="Path to benchmark JSON input.")
    parser.add_argument("--dry-run", action="store_true", help="Print the resolved run plan without running LAMMPS.")
    parser.add_argument("--prepare", action="store_true", help="Prepare the benchmark environment.")
    parser.add_argument("--run-test", action="store_true", help="Run a test GCMC simulation after preparation.")
    parser.add_argument("--run-isotherm", action="store_true", help="Run the full isotherm after preparation.")
    parser.add_argument("--evaluate", action="store_true", help="Evaluate an existing run directory without running LAMMPS.")
    parser.add_argument("--evaluate-all", action="store_true", help="Evaluate an existing run against all references.")
    parser.add_argument("--run-id", help="Write outputs to outputs/<module>/runs/<run-id>.")
    parser.add_argument("--kspace-style", choices=["pppm", "ewald"], help="Override simulation.kspace_style.")
    parser.add_argument("--kspace-accuracy", type=float, help="Override simulation.kspace_accuracy.")
    parser.add_argument(
        "--potentials",
        "--run-potentials",
        dest="run_potentials",
        action="store_true",
        help="Run the Module C potential comparison.",
    )
    parser.add_argument(
        "--run-mlip-mc",
        action="store_true",
        help="Run the configured Module C MLIP-MC Widom or GCMC workflow.",
    )
    parser.add_argument(
        "--setup-mlip-mc",
        action="store_true",
        help="Install and verify the configured MLIP-MC backend, then exit.",
    )
    parser.add_argument(
        "--setup-golddac",
        action="store_true",
        help="Download and verify GoldDAC plus configured static MACE assets, then exit.",
    )
    parser.add_argument(
        "--install-missing",
        action="store_true",
        help="Install missing pinned MLIP-MC dependencies in the active Python environment.",
    )
    parser.add_argument(
        "--setup-module-c",
        action="store_true",
        help="Verify or install dependencies for a Module C campaign.",
    )
    parser.add_argument(
        "--assess-module-c",
        action="store_true",
        help="Print the property-based Module C applicability assessment.",
    )
    parser.add_argument(
        "--run-module-c",
        action="store_true",
        help="Run one stage of the extensible Module C campaign.",
    )
    parser.add_argument(
        "--init-module-b-campaign",
        action="store_true",
        help="Create a Module B active-learning campaign state from an existing mixture run.",
    )
    parser.add_argument(
        "--compare-strategies",
        action="store_true",
        help="Compare CP2K-local and CP2K-free pretrained Module C strategies.",
    )
    parser.add_argument(
        "--stage",
        choices=[
            "screening",
            "active-learning",
            "widom",
            "gcmc-pilot",
            "gcmc-production",
        ],
        default="screening",
        help="Module C campaign stage.",
    )
    parser.add_argument(
        "--submit",
        action="store_true",
        help="Submit scheduled CP2K jobs or execute local CP2K jobs on the current host.",
    )
    parser.add_argument(
        "--train",
        action="store_true",
        help="Execute prepared MACE training on the current CUDA-capable host.",
    )
    parser.add_argument(
        "--systems",
        nargs="+",
        default=[],
        help="Limit a Module C campaign to named systems.",
    )
    parser.add_argument(
        "--models",
        nargs="+",
        default=[],
        help="Limit a Module C campaign to named potential models.",
    )
    parser.add_argument(
        "--cross-check-engine",
        choices=["mlip_mc", "flames", "lammps"],
        help="Run the primary engine and a second engine on the same campaign task.",
    )
    parser.add_argument(
        "--analyze-module-c",
        action="store_true",
        help="Aggregate existing Module C campaign result files.",
    )
    parser.add_argument(
        "--run-variants",
        "--run-variant",
        dest="run_variants",
        action="store_true",
        help="Run benchmark variants instead of the base plan.",
    )
    parser.add_argument(
        "--registry-output-dir",
        default="data/generated",
        help="Directory for continuously generated capability registries.",
    )
    parser.add_argument(
        "--skip-registry-update",
        action="store_true",
        help="Do not refresh generated capability registries before planning.",
    )
    parser.add_argument("--new-run", action="store_true", help="Write outputs to a timestamped run directory.")
    overwrite_group = parser.add_mutually_exclusive_group()
    overwrite_group.add_argument(
        "--overwrite",
        action="store_true",
        help="Replace an existing run directory before starting.",
    )
    overwrite_group.add_argument(
        "--no-overwrite",
        action="store_true",
        help="Fail if the target working directory already exists.",
    )
    parser.add_argument("--resume", action="store_true", help="Reuse completed pressure-point results in an existing run directory.")
    parser.add_argument("--jobs", type=int, default=1, help="Number of pressure-point LAMMPS jobs to run in parallel.")
    parser.add_argument(
        "--allow-unsupported",
        action="store_true",
        help="Run cases marked outside the current validated module capability without an interactive prompt.",
    )
    args = parser.parse_args(argv)
    if args.train and (
        not args.run_module_c or args.stage != "active-learning"
    ):
        parser.error(
            "--train requires --run-module-c --stage active-learning."
        )

    config = load_benchmark_data(args.config)
    if args.new_run:
        config.setdefault("output", {})["run_id"] = timestamp_run_id()
    if args.run_id:
        config.setdefault("output", {})["run_id"] = args.run_id
    if args.kspace_style:
        config.setdefault("simulation", {})["kspace_style"] = args.kspace_style
    if args.kspace_accuracy is not None:
        config.setdefault("simulation", {})["kspace_accuracy"] = args.kspace_accuracy
    if args.overwrite:
        config.setdefault("output", {})["overwrite"] = True
    elif args.no_overwrite:
        config.setdefault("output", {})["overwrite"] = False
    if args.resume:
        config.setdefault("output", {})["resume"] = True
    if not args.skip_registry_update:
        write_generated_registries(args.registry_output_dir)
    run_plan = build_run_plan(config)
    if args.init_module_b_campaign:
        result = _initialize_module_b_campaign(run_plan)
        print(json.dumps(result, indent=2))
        return 0
    if any(
        (
            args.setup_module_c,
            args.assess_module_c,
            args.run_module_c,
            args.compare_strategies,
            args.cross_check_engine,
            args.analyze_module_c,
        )
    ):
        _require_module_c_campaign(run_plan)
    if args.setup_module_c:
        result = setup_module_c(
            run_plan,
            install_missing=args.install_missing,
        )
        print(json.dumps(result, indent=2))
        return 0
    if args.assess_module_c:
        print(
            json.dumps(
                run_plan["benchmark"]["applicability"],
                indent=2,
            )
        )
        return 0
    if args.run_module_c:
        result = run_module_c_campaign(
            config,
            stage=args.stage,
            selected_systems=args.systems,
            selected_models=args.models,
            jobs=args.jobs,
            submit=args.submit,
            train=args.train,
            resume=args.resume,
        )
        print(json.dumps(result, indent=2))
        return 0
    if args.compare_strategies:
        result = run_strategy_comparison(
            run_plan,
            download_missing=args.install_missing,
        )
        print(json.dumps(result, indent=2))
        return 0
    if args.cross_check_engine:
        result = cross_check_campaign_engine(
            config,
            cross_check_engine=args.cross_check_engine,
            stage=args.stage,
            selected_systems=args.systems,
            selected_models=args.models,
        )
        print(json.dumps(result, indent=2))
        return 0
    if args.analyze_module_c:
        result = analyze_module_c_campaign(run_plan)
        print(json.dumps(result, indent=2))
        return 0
    if args.setup_golddac:
        result = _setup_golddac_benchmark(run_plan)
        print(json.dumps(result, indent=2))
        return 0
    if args.setup_mlip_mc:
        backend = _configured_mlip_mc_backend(run_plan)
        status = ensure_mlip_mc_dependencies(
            backend,
            install_missing=True,
        )
        model = _configured_mlip_mc_model(run_plan)
        model_asset = (
            ensure_model_asset(model, download_missing=True)
            if status.backend == "nequip"
            or isinstance(model.get("asset"), dict)
            else None
        )
        build_ase_calculator(model)
        print(
            json.dumps(
                {
                    "status": "ready",
                    **status.to_dict(),
                    "model": model.get("name", model.get("model")),
                    "model_ready": True,
                    "model_asset": model_asset,
                },
                indent=2,
            )
        )
        return 0
    if args.dry_run:
        if args.run_variants:
            variant_plans = build_variant_plans(config)
            result = {
                "status": "planned",
                "variant_count": len(variant_plans),
                "variants": variant_plans,
            }
        else:
            result = run_plan
        print(json.dumps(result, indent=2))
        return 0
    if args.prepare:
        prepare_plan = prepare_benchmark(run_plan)
        result = materialize_benchmark(prepare_plan)
        print(json.dumps(result, indent=2))
        return 0
    if args.run_test:
        _confirm_supported_capability(run_plan, allow_unsupported=args.allow_unsupported)
        prepare_plan = prepare_benchmark(run_plan)
        materialized_plan = materialize_benchmark(prepare_plan)
        result = run_benchmark(materialized_plan)
        print(json.dumps(result, indent=2))
        return 0
    if args.run_isotherm:
        _confirm_supported_capability(run_plan, allow_unsupported=args.allow_unsupported)
        prepare_plan = prepare_benchmark(run_plan)
        materialized_plan = materialize_benchmark(prepare_plan)
        result = run_isotherm(materialized_plan, jobs=args.jobs)
        print(json.dumps(result, indent=2))
        return 0
    if args.evaluate:
        prepare_plan = prepare_benchmark(run_plan)
        result = evaluate_run_directory(
            prepare_plan["working_directory"],
            evaluation_config=run_plan.get("evaluation"),
        )
        print(json.dumps(result, indent=2))
        return 0
    if args.evaluate_all:
        prepare_plan = prepare_benchmark(run_plan)
        result = evaluate_all_references(
            prepare_plan["working_directory"],
            references=run_plan["resources"]["references"],
            evaluation_config=run_plan.get("evaluation"),
        )
        print(json.dumps(result, indent=2))
        return 0
    if args.run_variants:
        _confirm_supported_capability(run_plan, allow_unsupported=args.allow_unsupported)
        result = run_variant_benchmark(config, jobs=args.jobs)
        print(json.dumps(result, indent=2))
        return 0
    if args.run_potentials:
        _confirm_supported_capability(
            run_plan,
            allow_unsupported=args.allow_unsupported,
        )
        if run_plan["module"]["id"] != "C":
            raise ValueError(
                "--potentials requires benchmark.task='potential_benchmark'."
            )
        workflow = str(
            run_plan["benchmark"].get("potential_benchmark", {}).get(
                "workflow",
                "static",
            )
        ).strip().casefold()
        if workflow != "static":
            raise ValueError(
                "--potentials runs only the static comparison. Use "
                "--run-mlip-mc for an MLIP-MC workflow."
            )
        result = run_potential_benchmark(run_plan)
        print(
            json.dumps(
                {
                    "status": result["status"],
                    "working_directory": result["working_directory"],
                    "output_path": result["output_path"],
                    "baseline_backend": result["baseline_backend"],
                    "backends": result["backends"],
                    "configuration_count": result["configuration_count"],
                    "runtime_seconds": result["runtime_seconds"],
                    "shared_framework_cache": result[
                        "shared_framework_cache"
                    ],
                    "analysis": result["analysis"],
                },
                indent=2,
            )
        )
        return 0
    if args.run_mlip_mc:
        _confirm_supported_capability(
            run_plan,
            allow_unsupported=args.allow_unsupported,
        )
        result = run_mlip_mc_benchmark(
            run_plan,
            install_missing=args.install_missing,
        )
        print(json.dumps(result, indent=2))
        return 0
    print(json.dumps(run_plan, indent=2))
    return 0


def _confirm_supported_capability(run_plan: dict, *, allow_unsupported: bool = False) -> None:
    applicability = run_plan.get("benchmark", {}).get("applicability", {})
    if applicability.get("can_attempt_simulation") is False:
        module = run_plan.get("module", {})
        reason = applicability.get("reason") or "This benchmark case cannot be simulated by the current pipeline."
        raise RuntimeError(
            f"Cannot run Module {module.get('id', '?')} with the current executable pipeline. "
            f"{reason}"
        )
    if not applicability.get("requires_user_confirmation"):
        return
    if allow_unsupported:
        return

    module = run_plan.get("module", {})
    material = run_plan.get("material", {})
    reason = applicability.get("reason") or "This case is outside the current validated module capability."
    message = (
        f"\nWARNING: {material.get('material_id', 'unknown material')} is marked as "
        f"{applicability.get('current_module_capability', 'outside_validated_scope')} for "
        f"Module {module.get('id', '?')}.\n"
        f"{reason}\n"
        "Continue with the simulation anyway? [y/N]: "
    )
    try:
        answer = input(message)
    except EOFError as exc:
        raise RuntimeError(
            "Simulation requires explicit confirmation because the benchmark case is outside "
            "the current validated module capability. Re-run interactively or pass "
            "--allow-unsupported if this is intentional."
        ) from exc

    if answer.strip().casefold() not in {"y", "yes"}:
        raise RuntimeError("Simulation cancelled by user.")


def _require_module_c_campaign(run_plan: dict) -> None:
    if run_plan.get("module", {}).get("id") != "C":
        raise ValueError(
            "This command requires benchmark.task='potential_benchmark'."
        )
    workflow = (
        run_plan.get("benchmark", {})
        .get("potential_benchmark", {})
        .get("workflow")
    )
    if str(workflow).strip().casefold() != "campaign":
        raise ValueError(
            "This command requires "
            "benchmark.potential_benchmark.workflow='campaign'."
        )


def _initialize_module_b_campaign(run_plan: dict) -> dict:
    if run_plan.get("module", {}).get("id") != "B":
        raise ValueError("--init-module-b-campaign requires a Module B mixture configuration.")
    prepare_plan = prepare_benchmark(run_plan)
    working_directory = Path(prepare_plan["working_directory"])
    output_path = working_directory / "module_b_campaign_state.json"
    summary_path = working_directory / "isotherm_summary.json"
    pressures = [0.1, 1.0, 5.0, 10.0, 20.0, 35.0]
    fractions = [0.05, 0.15, 0.5, 0.85]
    if summary_path.is_file():
        state = initialize_campaign_state_from_isotherm(
            summary_path,
            output_path,
            pressures_bar=pressures,
            co2_mole_fractions=fractions,
        )
    else:
        state = initialize_campaign_state(
            output_path,
            pressures_bar=pressures,
            co2_mole_fractions=fractions,
        )
    return {
        "status": "initialized",
        "output_path": str(output_path),
        "source_isotherm_summary": str(summary_path) if summary_path.is_file() else None,
        "candidate_count": len(state["candidates"]),
        "completed_count": len(state["results"]),
        "initial_candidate_ids": state["initial_candidate_ids"],
    }


def _configured_mlip_mc_backend(run_plan: dict) -> str:
    return str(_configured_mlip_mc_model(run_plan).get("backend", "mace-torch"))


def _configured_mlip_mc_model(run_plan: dict) -> dict:
    settings = run_plan.get("benchmark", {}).get("potential_benchmark", {})
    mlip_mc = settings.get("mlip_mc", {}) if isinstance(settings, dict) else {}
    model = mlip_mc.get("model", {}) if isinstance(mlip_mc, dict) else {}
    if not isinstance(model, dict):
        raise TypeError("'benchmark.potential_benchmark.mlip_mc.model' must be an object.")
    return model


def _setup_golddac_benchmark(run_plan: dict) -> dict:
    settings = run_plan.get("benchmark", {}).get("potential_benchmark", {})
    if not isinstance(settings, dict) or str(
        settings.get("configuration_set", "")
    ).casefold() != "golddac":
        raise ValueError(
            "--setup-golddac requires a Module C configuration with "
            "configuration_set='golddac'."
        )
    dataset = settings.get("dataset", {})
    if not isinstance(dataset, dict):
        raise TypeError("'benchmark.potential_benchmark.dataset' must be an object.")
    dataset_root = dataset.get("path") or dataset.get(
        "root",
        "external/datasets/golddac",
    )
    dataset_status = ensure_golddac_dataset(
        dataset_root,
        download_missing=True,
    )

    model_assets = []
    dependency_status = None
    dispersion_status = None
    for specification in settings.get("backends", []):
        if not isinstance(specification, dict):
            continue
        backend_type = str(specification.get("type", "")).casefold()
        if backend_type == "mace_mp":
            if dependency_status is None:
                dependency_status = ensure_mlip_mc_dependencies(
                    "mace-torch",
                    install_missing=True,
                ).to_dict()
            if (
                bool(specification.get("dispersion", False))
                and dispersion_status is None
            ):
                dispersion_status = ensure_torch_dftd(install_missing=True)
            if isinstance(specification.get("asset"), dict):
                model_assets.append(
                    ensure_model_asset(specification, download_missing=True)
                )
            build_ase_calculator(specification)

    return {
        "status": "ready",
        "dataset": dataset_status,
        "dependencies": dependency_status,
        "dispersion_dependency": dispersion_status,
        "model_assets": model_assets,
    }


if __name__ == "__main__":
    raise SystemExit(main())
