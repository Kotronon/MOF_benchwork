from __future__ import annotations

import sys
import unittest
from unittest.mock import Mock, patch

from modules.module_c_mlips.dependencies import (
    DependencyStatus,
    ensure_mlip_mc_dependencies,
    ensure_mace_polar_dependencies,
    ensure_torch_dftd,
    inspect_mlip_mc_dependencies,
    normalize_mlip_backend,
)


class MlipMcDependencyTests(unittest.TestCase):
    def test_polar_rejects_incompatible_electrostatics_without_installing(self) -> None:
        with patch("modules.module_c_mlips.dependencies._module_available", return_value=True), patch(
            "modules.module_c_mlips.dependencies._distribution_version", return_value="0.4.4"
        ), patch("modules.module_c_mlips.dependencies.subprocess.run") as run:
            with self.assertRaisesRegex(ImportError, "graph_longrange==0.4.0"):
                ensure_mace_polar_dependencies()
        run.assert_not_called()

    def test_polar_setup_installs_compatible_electrostatics(self) -> None:
        with patch("modules.module_c_mlips.dependencies._module_available", return_value=True), patch(
            "modules.module_c_mlips.dependencies._distribution_version", side_effect=["0.4.4", "0.4.0"]
        ), patch("modules.module_c_mlips.dependencies.subprocess.run", return_value=Mock(returncode=0)) as run:
            ensure_mace_polar_dependencies(install_missing=True)
        self.assertEqual(run.call_args.args[0], [sys.executable, "-m", "pip", "install", "graph_longrange==0.4.0"])

    def test_backend_aliases_are_normalized(self) -> None:
        self.assertEqual(normalize_mlip_backend("mace_mp"), "mace-torch")
        self.assertEqual(normalize_mlip_backend("ORB"), "orb-models")
        self.assertEqual(normalize_mlip_backend("ODAC"), "fairchem")
        self.assertEqual(normalize_mlip_backend("NequIP-Legacy"), "nequip")

    def test_missing_dependency_does_not_install_without_opt_in(self) -> None:
        missing = _status(ready=False)
        with patch(
            "modules.module_c_mlips.dependencies.inspect_mlip_mc_dependencies",
            return_value=missing,
        ), patch("modules.module_c_mlips.dependencies.subprocess.run") as run:
            with self.assertRaisesRegex(ImportError, "--install-missing"):
                ensure_mlip_mc_dependencies("mace-torch")
        run.assert_not_called()

    def test_auto_install_uses_active_python_and_pinned_package(self) -> None:
        missing = _status(ready=False)
        ready = _status(ready=True, installed_version="0.1.3")
        completed = Mock(returncode=0, stdout="", stderr="")
        with patch(
            "modules.module_c_mlips.dependencies.inspect_mlip_mc_dependencies",
            side_effect=[missing, ready],
        ), patch(
            "modules.module_c_mlips.dependencies.subprocess.run",
            return_value=completed,
        ) as run:
            result = ensure_mlip_mc_dependencies(
                "mace-torch",
                install_missing=True,
            )

        self.assertTrue(result.ready)
        command = run.call_args.args[0]
        self.assertEqual(command[:4], [sys.executable, "-m", "pip", "install"])
        self.assertEqual(command[-1], "mlip-mc==0.1.3")

    def test_nequip_install_is_pinned_to_legacy_loader_release(self) -> None:
        with patch(
            "modules.module_c_mlips.dependencies._distribution_version",
            return_value=None,
        ), patch(
            "modules.module_c_mlips.dependencies._module_available",
            return_value=False,
        ):
            status = inspect_mlip_mc_dependencies("nequip")

        self.assertEqual(status.backend_required_version, "0.6.2")
        self.assertIn("nequip==0.6.2", status.install_specification)

    def test_d3_dependency_installs_in_active_environment(self) -> None:
        completed = Mock(returncode=0, stdout="", stderr="")
        with patch(
            "modules.module_c_mlips.dependencies._module_available",
            side_effect=[False, True],
        ), patch(
            "modules.module_c_mlips.dependencies.subprocess.run",
            return_value=completed,
        ) as run:
            status = ensure_torch_dftd(install_missing=True)

        self.assertTrue(status["available"])
        self.assertEqual(
            run.call_args.args[0],
            [sys.executable, "-m", "pip", "install", "torch-dftd"],
        )


def _status(
    *,
    ready: bool,
    installed_version: str | None = None,
) -> DependencyStatus:
    return DependencyStatus(
        backend="mace-torch",
        python_executable=sys.executable,
        mlip_mc_required_version="0.1.3",
        mlip_mc_installed_version=installed_version,
        backend_module="mace",
        mlip_mc_available=ready,
        backend_available=True,
        ready=ready,
        install_specification="mlip-mc==0.1.3",
    )


if __name__ == "__main__":
    unittest.main()
