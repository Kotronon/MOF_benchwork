# MOF-5: AL versus random selection

Shared holdouts: 4/20; status: incomplete_or_imprecise_holdouts.
The same completed labels evaluate every checkpoint. No labels are imported into live training campaigns.
Random selection reuses the shared initial design. Strategy comparison begins only after it is complete.
Primary metrics: component RMSE and selectivity MAE. The 20% relative-error target is diagnostic, not proof of scientific validity.
Costs include precision retries and are sums of seed runtimes; elapsed time must be measured separately.
One random trajectory is a pilot comparison, not statistical evidence of superiority.
Previously inspected holdouts are not a fresh final test set. External physical validation remains open.

al: 7 training states; 6 initial states remaining; 0 adaptive/random-acquired states.
random: 5 training states; 8 initial states remaining; 0 adaptive/random-acquired states.
