# Module B: korrigierte Gemisch-Auswertung

**Pilot ausgewertet; quantitative Referenzvalidierung offen**

Quelle: `outputs/module_B_mof5_al_comparison/holdouts/production/mof5/simulation/runs/al_00001_d7c5be52c2167b174484/isotherm_summary.json`

Framework-Masse: 6158.936 u. Herkunft: `outputs/module_B_mof5_al_comparison/holdouts/production/mof5/simulation/runs/al_00001_d7c5be52c2167b174484/data/IRMOF-1.data`.

Komponenten und Gesamtbeladung sind absolute Adsorption; mol/kg = mmol/g. Selektivität ist dimensionslos.
95-%-Intervalle beschreiben die Streuung unabhängiger Seed-Mittelwerte. Komponenten: Student-t; Selektivität: Fieller mit gepaarten Seeds.
Das Präzisionskriterium ist kein Nachweis der Equilibrierung. Unbeschränkte/undefinierte Intervalle erfüllen es nicht.

Präzisionsziel: relative Intervallhalbbreite ≤ 20 %, mindestens 3 Seeds.

| Druck / bar | Größe | Wert | Einheit | 95-%-Intervall | relative Halbbreite | Intervallstatus | Präzisionsziel (Größe) | Präzisionsziel (Punkt) |
|---:|:---|---:|:---|:---|---:|:---|:---|:---|
| 12 | CO2 | 1.62528 | mol/kg | [1.55376, 1.6968] | 4.40 % | bounded | ja | ja |
| 12 | N2 | 2.06193 | mol/kg | [1.98416, 2.13969] | 3.77 % | bounded | ja | ja |
| 12 | total | 3.6872 | mol/kg | [3.64722, 3.72719] | 1.08 % | bounded | — | ja |
| 12 | CO2/N2 | 4.46665 | dimensionless | [4.12685, 4.83195] | 7.89 % | bounded | ja | ja |
| 12 | N2/CO2 | 0.223881 | dimensionless | [0.206956, 0.242316] | 7.90 % | bounded | ja | ja |

## Referenzprüfung

Reingasisothermen werden nicht als Gemischreferenz verwendet. Unbekannte Adsorptionsbasis wird nicht als absolut interpretiert.


Ein bisheriger Vergleich von CO₂+N₂-Gesamtbeladung mit reinem CO₂ ist ungültig; daraus abgeleitete Fehlerprozente sind kein Validierungsergebnis.
