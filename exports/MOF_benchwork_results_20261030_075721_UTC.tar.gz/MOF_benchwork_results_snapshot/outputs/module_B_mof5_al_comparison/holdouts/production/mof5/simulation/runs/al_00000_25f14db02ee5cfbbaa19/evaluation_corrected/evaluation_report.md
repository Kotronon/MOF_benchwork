# Module B: korrigierte Gemisch-Auswertung

**Pilot ausgewertet; quantitative Referenzvalidierung offen**

Quelle: `outputs/module_B_mof5_al_comparison/holdouts/production/mof5/simulation/runs/al_00000_25f14db02ee5cfbbaa19/isotherm_summary.json`

Framework-Masse: 6158.936 u. Herkunft: `outputs/module_B_mof5_al_comparison/holdouts/production/mof5/simulation/runs/al_00000_25f14db02ee5cfbbaa19/data/IRMOF-1.data`.

Komponenten und Gesamtbeladung sind absolute Adsorption; mol/kg = mmol/g. Selektivität ist dimensionslos.
95-%-Intervalle beschreiben die Streuung unabhängiger Seed-Mittelwerte. Komponenten: Student-t; Selektivität: Fieller mit gepaarten Seeds.
Das Präzisionskriterium ist kein Nachweis der Equilibrierung. Unbeschränkte/undefinierte Intervalle erfüllen es nicht.

Präzisionsziel: relative Intervallhalbbreite ≤ 20 %, mindestens 3 Seeds.

| Druck / bar | Größe | Wert | Einheit | 95-%-Intervall | relative Halbbreite | Intervallstatus | Präzisionsziel (Größe) | Präzisionsziel (Punkt) |
|---:|:---|---:|:---|:---|---:|:---|:---|:---|
| 12 | CO2 | 6.97168 | mol/kg | [6.89105, 7.05231] | 1.16 % | bounded | ja | ja |
| 12 | N2 | 1.16054 | mol/kg | [1.12996, 1.19113] | 2.64 % | bounded | ja | ja |
| 12 | total | 8.13222 | mol/kg | [8.02776, 8.23668] | 1.28 % | bounded | — | ja |
| 12 | CO2/N2 | 6.00726 | dimensionless | [5.89011, 6.13018] | 2.00 % | bounded | ja | ja |
| 12 | N2/CO2 | 0.166465 | dimensionless | [0.163127, 0.169776] | 2.00 % | bounded | ja | ja |

## Referenzprüfung

Reingasisothermen werden nicht als Gemischreferenz verwendet. Unbekannte Adsorptionsbasis wird nicht als absolut interpretiert.


Ein bisheriger Vergleich von CO₂+N₂-Gesamtbeladung mit reinem CO₂ ist ungültig; daraus abgeleitete Fehlerprozente sind kein Validierungsergebnis.
