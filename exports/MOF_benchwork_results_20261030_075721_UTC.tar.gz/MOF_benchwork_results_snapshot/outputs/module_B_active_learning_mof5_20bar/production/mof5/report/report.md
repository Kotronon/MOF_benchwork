# Module B campaign

Training states: 7; independent holdouts: 2.

Quantitative external reference validation remains open.

Seed intervals measure statistical precision, not proof of equilibrium. GP bands describe latent surrogate uncertainty.

Higher-dimensional figures are projections, not complete adsorption surfaces.

See observations.csv, surrogate_predictions.csv and validation_report.json for reproducible values.

Pressure bounds / bar: [0.1, 20.0].
Acquisition progress: {'initial_design_completed': 7, 'initial_design_remaining': 6, 'adaptive_observations': 0, 'precision_recalculations': 3, 'next_phase': 'initial_design'}.
Previously inspected holdouts: 2; these are not a fresh final test set.
Archived source reports are provenance only; this learning curve starts at the extended domain.
overall: 2 holdouts; available.
previous_domain: 2 holdouts; available.
extended_domain: 0 holdouts; missing_holdout_data.

Campaign kind: production.

Conservative raw-log intervals add between-seed and autocorrelation batch variances and may double-count sampling noise. They do not establish equilibrium. Classic seed intervals are retained in uncertainties.csv and campaign.json.

Pure-gas boundaries have undefined selectivity; only present-component precision is tested there. Constant traces at positive fugacity fail precision and use a documented 0.05 molecule GP noise floor.

Holdouts failing precision: 1/2. Holdout labels never influence training, acquisition or stopping.
