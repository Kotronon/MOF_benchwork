# Module B: korrigierte Gemisch-Auswertung

**Pilot ausgewertet; quantitative Referenzvalidierung offen**

Quelle: `outputs/module_B_active_learning_mof5_20bar/production/mof5/simulation/runs/al_00010_be90bc0409da058d2963/isotherm_summary.json`

Framework-Masse: 6158.936 u. Herkunft: `outputs/module_B_active_learning_mof5_20bar/production/mof5/simulation/runs/al_00010_be90bc0409da058d2963/data/IRMOF-1.data`.

Komponenten und Gesamtbeladung sind absolute Adsorption; mol/kg = mmol/g. Selektivität ist dimensionslos.
95-%-Intervalle beschreiben die Streuung unabhängiger Seed-Mittelwerte. Komponenten: Student-t; Selektivität: Fieller mit gepaarten Seeds.
Das Präzisionskriterium ist kein Nachweis der Equilibrierung. Unbeschränkte/undefinierte Intervalle erfüllen es nicht.

Präzisionsziel: relative Intervallhalbbreite ≤ 20 %, mindestens 3 Seeds.

| Druck / bar | Größe | Wert | Einheit | 95-%-Intervall | relative Halbbreite | Intervallstatus | Präzisionsziel (Größe) | Präzisionsziel (Punkt) |
|---:|:---|---:|:---|:---|---:|:---|:---|:---|
| 9.8518 | CO2 | 9.53518 | mol/kg | [9.09519, 9.97516] | 4.61 % | bounded | ja | ja |
| 9.8518 | N2 | 0.494983 | mol/kg | [0.484292, 0.505675] | 2.16 % | bounded | ja | ja |
| 9.8518 | total | 10.0302 | mol/kg | [9.59548, 10.4648] | 4.33 % | bounded | — | ja |
| 9.8518 | CO2/N2 | 6.62904 | dimensionless | [6.2374, 7.03355] | 6.01 % | bounded | ja | ja |
| 9.8518 | N2/CO2 | 0.150851 | dimensionless | [0.142176, 0.160323] | 6.02 % | bounded | ja | ja |

## Referenzprüfung

Reingasisothermen werden nicht als Gemischreferenz verwendet. Unbekannte Adsorptionsbasis wird nicht als absolut interpretiert.


Ein bisheriger Vergleich von CO₂+N₂-Gesamtbeladung mit reinem CO₂ ist ungültig; daraus abgeleitete Fehlerprozente sind kein Validierungsergebnis.
