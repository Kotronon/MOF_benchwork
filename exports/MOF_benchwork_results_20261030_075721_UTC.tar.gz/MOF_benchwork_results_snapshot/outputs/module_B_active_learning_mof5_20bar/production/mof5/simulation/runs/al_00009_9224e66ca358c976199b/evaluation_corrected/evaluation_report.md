# Module B: korrigierte Gemisch-Auswertung

**Pilot ausgewertet; quantitative Referenzvalidierung offen**

Quelle: `outputs/module_B_active_learning_mof5_20bar/production/mof5/simulation/runs/al_00009_9224e66ca358c976199b/isotherm_summary.json`

Framework-Masse: 6158.936 u. Herkunft: `outputs/module_B_active_learning_mof5_20bar/production/mof5/simulation/runs/al_00009_9224e66ca358c976199b/data/IRMOF-1.data`.

Komponenten und Gesamtbeladung sind absolute Adsorption; mol/kg = mmol/g. Selektivität ist dimensionslos.
95-%-Intervalle beschreiben die Streuung unabhängiger Seed-Mittelwerte. Komponenten: Student-t; Selektivität: Fieller mit gepaarten Seeds.
Das Präzisionskriterium ist kein Nachweis der Equilibrierung. Unbeschränkte/undefinierte Intervalle erfüllen es nicht.

Präzisionsziel: relative Intervallhalbbreite ≤ 20 %, mindestens 3 Seeds.

| Druck / bar | Größe | Wert | Einheit | 95-%-Intervall | relative Halbbreite | Intervallstatus | Präzisionsziel (Größe) | Präzisionsziel (Punkt) |
|---:|:---|---:|:---|:---|---:|:---|:---|:---|
| 20 | CO2 | 2.79846 | mol/kg | [2.62763, 2.96929] | 6.10 % | bounded | ja | ja |
| 20 | N2 | 3.21577 | mol/kg | [3.15923, 3.27231] | 1.76 % | bounded | ja | ja |
| 20 | total | 6.01423 | mol/kg | [5.88314, 6.14532] | 2.18 % | bounded | — | ja |
| 20 | CO2/N2 | 4.9313 | dimensionless | [4.5638, 5.31019] | 7.57 % | bounded | ja | ja |
| 20 | N2/CO2 | 0.202786 | dimensionless | [0.188317, 0.219116] | 7.59 % | bounded | ja | ja |

## Referenzprüfung

Reingasisothermen werden nicht als Gemischreferenz verwendet. Unbekannte Adsorptionsbasis wird nicht als absolut interpretiert.


Ein bisheriger Vergleich von CO₂+N₂-Gesamtbeladung mit reinem CO₂ ist ungültig; daraus abgeleitete Fehlerprozente sind kein Validierungsergebnis.
