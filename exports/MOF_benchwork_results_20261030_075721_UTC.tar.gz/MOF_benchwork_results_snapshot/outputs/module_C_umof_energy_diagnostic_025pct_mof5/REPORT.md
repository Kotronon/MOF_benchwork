# MOF-5 / CO2 energy diagnostic

Compared 20 identical single-guest poses. Fine-tuning is more attractive at 18 poses, unchanged at 1, less attractive at 1 (tolerance 1e-06 eV). Mean change: -1.417 kJ/mol; range: -3.184 to 0.128 kJ/mol.

See summary.json for separate host, gas, atomic-reference and additivity checks; paired_energies.csv for every subtraction term; model_0.json and model_1.json for raw model outputs. Geometries are archived in extxyz files. inputs.json records model and snapshot checksums.

- No DFT or experimental accuracy ranking from model-to-model differences.
- Raw isolated-system energy differences alone do not establish incorrect energy references.
- Balanced but correlated, model-selected single-guest poses; no Henry coefficient or isotherm estimator.
- Additional loading-dependent guest-guest effects are outside this diagnostic.

## Interpretation of this run

The matched-pose comparison finds stronger binding at 18 positions, unchanged binding at one position, and weaker binding at one position (1e-6 eV tolerance). The mean interaction-energy change is -1.417 kJ/mol. This is consistent with a tendency toward higher adsorption, but does not quantify the finite-loading isotherm change.

The isolated CO2 reference increases by 3.004 kJ/mol under fine-tuning. The corresponding mean change in E(host+guest)-E(host) is 1.587 kJ/mol; subtracting the model's own molecular reference gives the net -1.417 kJ/mol. These terms alone do not identify an incorrect molecular energy. Atomic reference-energy sums are identical in both models.

The disconnected-fragment residual is below 1e-8 eV in both models, and isolated-guest energies vary by less than 1e-6 eV across placements. There is also one naturally separated periodic pose (minimum host-guest distance 6.318 A, beyond the 6 A local cutoff) with interaction energy numerically zero in both models. The position dependence and cancellation controls give no indication of a simple subtraction or elemental-reference mismatch.

Recomputed host/gas energies reproduce the existing GCMC logs within 2e-6 eV, with tiny geometry serialization differences; see gcmc_reference_crosscheck.json. No DFT jobs or additional GCMC trajectories were run. The next accuracy check is a matched-geometry adsorption-energy comparison to suitable DFT references, using a consistent reference level for combined, host and gas systems.
