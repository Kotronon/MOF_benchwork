# Isotherm Evaluation

Source: `outputs/module_B_mixture_selectivity/runs/mof5_co2_n2_validation_pilot/isotherm_summary.json`

## Summary

- Pressure points: 4
- Mean comparison error: 3.4222 mol/kg
- Mean comparison relative error: 68.2363 %

## Isotherm Table

| pressure / bar | CO2 / cell | absolute / mol kg^-1 | excess / mol kg^-1 | reference / mol kg^-1 | compared as | rel. error / % |
|---:|---:|---:|---:|---:|:---|---:|
| 0.1 | 0.172471 | 0.0280034 |  | 0.0828926 | absolute | -66.2173 |
| 1 | 1.92206 | 0.312076 |  | 0.830387 | absolute | -62.418 |
| 5 | 9.59038 | 1.55715 |  | 4.95047 | absolute | -68.5454 |
| 10 | 19.1542 | 3.10999 |  | 12.8323 | absolute | -75.7643 |

## Notes

- Loading is absolute adsorption from the GCMC molecule count.
- Excess loading is calculated as absolute loading minus bulk gas density times pore volume.
- mol/kg and mmol/g have the same numeric value.
- Reference values are matched exactly where possible and otherwise linearly interpolated.
- Excess references are compared against excess loading; unknown-basis references are reported and treated as absolute for comparison.
