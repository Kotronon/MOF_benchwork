# Module B: korrigierte Gemisch-Auswertung

**Pilot ausgewertet; quantitative Referenzvalidierung offen**

Quelle: `outputs/module_B_mixture_selectivity/runs/mof5_co2_n2_validation_10_90_nist_matched_3seeds/isotherm_summary.json`

Framework-Masse: 6158.936 u. Herkunft: `outputs/module_B_mixture_selectivity/runs/mof5_co2_n2_validation_10_90_nist_matched_3seeds/data/IRMOF-1.data`.

Komponenten und Gesamtbeladung sind absolute Adsorption; mol/kg = mmol/g. Selektivität ist dimensionslos.
95-%-Intervalle beschreiben die Streuung unabhängiger Seed-Mittelwerte. Komponenten: Student-t; Selektivität: Fieller mit gepaarten Seeds.
Das Präzisionskriterium ist kein Nachweis der Equilibrierung. Unbeschränkte/undefinierte Intervalle erfüllen es nicht.

Präzisionsziel: relative Intervallhalbbreite ≤ 20 %, mindestens 3 Seeds.

| Druck / bar | Größe | Wert | Einheit | 95-%-Intervall | relative Halbbreite | Intervallstatus | Präzisionsziel (Größe) | Präzisionsziel (Punkt) |
|---:|:---|---:|:---|:---|---:|:---|:---|:---|
| 0.995979 | CO2 | 0.0909594 | mol/kg | [0.0879112, 0.0940075] | 3.35 % | bounded | ja | ja |
| 0.995979 | N2 | 0.192289 | mol/kg | [0.165655, 0.218924] | 13.85 % | bounded | ja | ja |
| 0.995979 | total | 0.283249 | mol/kg | [0.258762, 0.307736] | 8.65 % | bounded | — | ja |
| 0.995979 | CO2/N2 | 4.2573 | dimensionless | [3.64073, 5.06998] | 16.79 % | bounded | ja | ja |
| 0.995979 | N2/CO2 | 0.23489 | dimensionless | [0.19724, 0.27467] | 16.48 % | bounded | ja | ja |
| 3.03459 | CO2 | 0.267801 | mol/kg | [0.253663, 0.281938] | 5.28 % | bounded | ja | ja |
| 3.03459 | N2 | 0.579785 | mol/kg | [0.573497, 0.586073] | 1.08 % | bounded | ja | ja |
| 3.03459 | total | 0.847586 | mol/kg | [0.832218, 0.862954] | 1.81 % | bounded | — | ja |
| 3.03459 | CO2/N2 | 4.15707 | dimensionless | [3.93274, 4.38246] | 5.41 % | bounded | ja | ja |
| 3.03459 | N2/CO2 | 0.240554 | dimensionless | [0.228182, 0.254275] | 5.42 % | bounded | ja | ja |
| 4.95678 | CO2 | 0.431139 | mol/kg | [0.416955, 0.445322] | 3.29 % | bounded | ja | ja |
| 4.95678 | N2 | 0.938653 | mol/kg | [0.921435, 0.955871] | 1.83 % | bounded | ja | ja |
| 4.95678 | total | 1.36979 | mol/kg | [1.33919, 1.40039] | 2.23 % | bounded | — | ja |
| 4.95678 | CO2/N2 | 4.13385 | dimensionless | [4.05734, 4.20866] | 1.83 % | bounded | ja | ja |
| 4.95678 | N2/CO2 | 0.241905 | dimensionless | [0.237605, 0.246467] | 1.83 % | bounded | ja | ja |
| 9.97999 | CO2 | 0.874701 | mol/kg | [0.853082, 0.89632] | 2.47 % | bounded | ja | ja |
| 9.97999 | N2 | 1.79769 | mol/kg | [1.75244, 1.84294] | 2.52 % | bounded | ja | ja |
| 9.97999 | total | 2.67239 | mol/kg | [2.62758, 2.7172] | 1.68 % | bounded | — | ja |
| 9.97999 | CO2/N2 | 4.37912 | dimensionless | [4.20915, 4.55606] | 3.96 % | bounded | ja | ja |
| 9.97999 | N2/CO2 | 0.228356 | dimensionless | [0.219488, 0.237578] | 3.96 % | bounded | ja | ja |
| 20.0129 | CO2 | 1.75156 | mol/kg | [1.71929, 1.78383] | 1.84 % | bounded | ja | ja |
| 20.0129 | N2 | 3.42664 | mol/kg | [3.34415, 3.50913] | 2.41 % | bounded | ja | ja |
| 20.0129 | total | 5.1782 | mol/kg | [5.06586, 5.29055] | 2.17 % | bounded | — | ja |
| 20.0129 | CO2/N2 | 4.60044 | dimensionless | [4.55019, 4.65237] | 1.11 % | bounded | ja | ja |
| 20.0129 | N2/CO2 | 0.21737 | dimensionless | [0.214944, 0.219771] | 1.11 % | bounded | ja | ja |

## Referenzprüfung

Reingasisothermen werden nicht als Gemischreferenz verwendet. Unbekannte Adsorptionsbasis wird nicht als absolut interpretiert.

- 0.995979 bar, `DDEC_IRMOF-1_UFF_CO2_298.csv`: pure_component_or_missing_mixture_metadata
- 0.995979 bar, `DDEC_IRMOF-1_UFF_N2_298.csv`: pure_component_or_missing_mixture_metadata
- 0.995979 bar, `10.1016j.seppur.2018.01.013.Isotherm4.json`: adsorption_basis_unknown, composition_mismatch_or_missing_component_data
- 0.995979 bar, `10.1039b807470d.Isotherm14.json`: excess_reference_requires_mixture_conversion
- 3.03459 bar, `DDEC_IRMOF-1_UFF_CO2_298.csv`: pure_component_or_missing_mixture_metadata
- 3.03459 bar, `DDEC_IRMOF-1_UFF_N2_298.csv`: pure_component_or_missing_mixture_metadata
- 3.03459 bar, `10.1016j.seppur.2018.01.013.Isotherm4.json`: adsorption_basis_unknown, composition_mismatch_or_missing_component_data
- 3.03459 bar, `10.1039b807470d.Isotherm14.json`: excess_reference_requires_mixture_conversion
- 4.95678 bar, `DDEC_IRMOF-1_UFF_CO2_298.csv`: pure_component_or_missing_mixture_metadata
- 4.95678 bar, `DDEC_IRMOF-1_UFF_N2_298.csv`: pure_component_or_missing_mixture_metadata
- 4.95678 bar, `10.1016j.seppur.2018.01.013.Isotherm4.json`: adsorption_basis_unknown, composition_mismatch_or_missing_component_data
- 4.95678 bar, `10.1039b807470d.Isotherm14.json`: excess_reference_requires_mixture_conversion
- 9.97999 bar, `DDEC_IRMOF-1_UFF_CO2_298.csv`: pure_component_or_missing_mixture_metadata
- 9.97999 bar, `DDEC_IRMOF-1_UFF_N2_298.csv`: pure_component_or_missing_mixture_metadata
- 9.97999 bar, `10.1016j.seppur.2018.01.013.Isotherm4.json`: adsorption_basis_unknown, composition_mismatch_or_missing_component_data
- 9.97999 bar, `10.1039b807470d.Isotherm14.json`: excess_reference_requires_mixture_conversion
- 20.0129 bar, `DDEC_IRMOF-1_UFF_CO2_298.csv`: pure_component_or_missing_mixture_metadata
- 20.0129 bar, `DDEC_IRMOF-1_UFF_N2_298.csv`: pure_component_or_missing_mixture_metadata
- 20.0129 bar, `10.1016j.seppur.2018.01.013.Isotherm4.json`: adsorption_basis_unknown, composition_mismatch_or_missing_component_data
- 20.0129 bar, `10.1039b807470d.Isotherm14.json`: excess_reference_requires_mixture_conversion

Ein bisheriger Vergleich von CO₂+N₂-Gesamtbeladung mit reinem CO₂ ist ungültig; daraus abgeleitete Fehlerprozente sind kein Validierungsergebnis.
