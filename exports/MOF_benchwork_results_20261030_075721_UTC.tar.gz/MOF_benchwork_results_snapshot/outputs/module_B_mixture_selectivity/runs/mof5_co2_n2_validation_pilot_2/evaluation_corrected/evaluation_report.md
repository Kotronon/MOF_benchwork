# Module B: korrigierte Gemisch-Auswertung

**Pilot ausgewertet; quantitative Referenzvalidierung offen**

Quelle: `outputs/module_B_mixture_selectivity/runs/mof5_co2_n2_validation_pilot_2/isotherm_summary.json`

Framework-Masse: 6158.936 u. Herkunft: `outputs/module_B_mixture_selectivity/runs/mof5_co2_n2_validation_pilot_2/data/IRMOF-1.data`.

Komponenten und Gesamtbeladung sind absolute Adsorption; mol/kg = mmol/g. Selektivität ist dimensionslos.
95-%-Intervalle beschreiben die Streuung unabhängiger Seed-Mittelwerte. Komponenten: Student-t; Selektivität: Fieller mit gepaarten Seeds.
Das Präzisionskriterium ist kein Nachweis der Equilibrierung. Unbeschränkte/undefinierte Intervalle erfüllen es nicht.

Präzisionsziel: relative Intervallhalbbreite ≤ 20 %, mindestens 3 Seeds.

| Druck / bar | Größe | Wert | Einheit | 95-%-Intervall | relative Halbbreite | Intervallstatus | Präzisionsziel (Größe) | Präzisionsziel (Punkt) |
|---:|:---|---:|:---|:---|---:|:---|:---|:---|
| 0.1 | CO2 | 0.0137324 | mol/kg | [0.00570513, 0.0217597] | 58.46 % | bounded | nein | nein |
| 0.1 | N2 | 0.0148095 | mol/kg | [0.0106319, 0.018987] | 28.21 % | bounded | nein | nein |
| 0.1 | total | 0.0285419 | mol/kg | [0.0227487, 0.0343351] | 20.30 % | bounded | — | nein |
| 0.1 | CO2/N2 | 5.25455 | dimensionless | [1.7993, 10.9749] | 87.31 % | bounded | nein | nein |
| 0.1 | N2/CO2 | 0.190311 | dimensionless | [0.0911167, 0.555772] | 122.08 % | bounded | nein | nein |
| 1 | CO2 | 0.133824 | mol/kg | [0.0755798, 0.192068] | 43.52 % | bounded | nein | nein |
| 1 | N2 | 0.18633 | mol/kg | [0.176431, 0.19623] | 5.31 % | bounded | ja | nein |
| 1 | total | 0.320154 | mol/kg | [0.262466, 0.377842] | 18.02 % | bounded | — | nein |
| 1 | CO2/N2 | 4.06985 | dimensionless | [2.27748, 5.91184] | 44.65 % | bounded | nein | nein |
| 1 | N2/CO2 | 0.24571 | dimensionless | [0.169152, 0.439082] | 54.93 % | bounded | nein | nein |
| 5 | CO2 | 0.660233 | mol/kg | [0.606, 0.714467] | 8.21 % | bounded | ja | ja |
| 5 | N2 | 0.903378 | mol/kg | [0.826009, 0.980747] | 8.56 % | bounded | ja | ja |
| 5 | total | 1.56361 | mol/kg | [1.43559, 1.69163] | 8.19 % | bounded | — | ja |
| 5 | CO2/N2 | 4.14148 | dimensionless | [3.98108, 4.31089] | 3.98 % | bounded | ja | ja |
| 5 | N2/CO2 | 0.24146 | dimensionless | [0.23197, 0.251188] | 3.98 % | bounded | ja | ja |
| 10 | CO2 | 1.35682 | mol/kg | [1.3307, 1.38293] | 1.92 % | bounded | ja | ja |
| 10 | N2 | 1.71951 | mol/kg | [1.67436, 1.76467] | 2.63 % | bounded | ja | ja |
| 10 | total | 3.07633 | mol/kg | [3.03558, 3.11708] | 1.32 % | bounded | — | ja |
| 10 | CO2/N2 | 4.4714 | dimensionless | [4.30137, 4.64963] | 3.89 % | bounded | ja | ja |
| 10 | N2/CO2 | 0.223644 | dimensionless | [0.215071, 0.232484] | 3.89 % | bounded | ja | ja |

## Referenzprüfung

Reingasisothermen werden nicht als Gemischreferenz verwendet. Unbekannte Adsorptionsbasis wird nicht als absolut interpretiert.

- 0.1 bar, `DDEC_IRMOF-1_UFF_CO2_298.csv`: pure_component_or_missing_mixture_metadata
- 0.1 bar, `DDEC_IRMOF-1_UFF_N2_298.csv`: pure_component_or_missing_mixture_metadata
- 0.1 bar, `10.1016j.seppur.2018.01.013.Isotherm4.json`: adsorption_basis_unknown, composition_mismatch_or_missing_component_data
- 0.1 bar, `10.1039b807470d.Isotherm14.json`: composition_mismatch_or_missing_component_data, excess_reference_requires_mixture_conversion
- 1 bar, `DDEC_IRMOF-1_UFF_CO2_298.csv`: pure_component_or_missing_mixture_metadata
- 1 bar, `DDEC_IRMOF-1_UFF_N2_298.csv`: pure_component_or_missing_mixture_metadata
- 1 bar, `10.1016j.seppur.2018.01.013.Isotherm4.json`: adsorption_basis_unknown, composition_mismatch_or_missing_component_data
- 1 bar, `10.1039b807470d.Isotherm14.json`: composition_mismatch_or_missing_component_data, excess_reference_requires_mixture_conversion
- 5 bar, `DDEC_IRMOF-1_UFF_CO2_298.csv`: pure_component_or_missing_mixture_metadata
- 5 bar, `DDEC_IRMOF-1_UFF_N2_298.csv`: pure_component_or_missing_mixture_metadata
- 5 bar, `10.1016j.seppur.2018.01.013.Isotherm4.json`: adsorption_basis_unknown, composition_mismatch_or_missing_component_data
- 5 bar, `10.1039b807470d.Isotherm14.json`: composition_mismatch_or_missing_component_data, excess_reference_requires_mixture_conversion
- 10 bar, `DDEC_IRMOF-1_UFF_CO2_298.csv`: pure_component_or_missing_mixture_metadata
- 10 bar, `DDEC_IRMOF-1_UFF_N2_298.csv`: pure_component_or_missing_mixture_metadata
- 10 bar, `10.1016j.seppur.2018.01.013.Isotherm4.json`: adsorption_basis_unknown, composition_mismatch_or_missing_component_data
- 10 bar, `10.1039b807470d.Isotherm14.json`: composition_mismatch_or_missing_component_data, excess_reference_requires_mixture_conversion

Ein bisheriger Vergleich von CO₂+N₂-Gesamtbeladung mit reinem CO₂ ist ungültig; daraus abgeleitete Fehlerprozente sind kein Validierungsergebnis.
