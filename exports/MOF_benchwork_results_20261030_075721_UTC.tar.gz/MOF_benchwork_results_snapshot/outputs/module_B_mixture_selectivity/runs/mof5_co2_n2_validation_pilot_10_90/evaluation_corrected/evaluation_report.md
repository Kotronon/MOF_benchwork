# Module B: korrigierte Gemisch-Auswertung

**Pilot ausgewertet; quantitative Referenzvalidierung offen**

Quelle: `outputs/module_B_mixture_selectivity/runs/mof5_co2_n2_validation_pilot_10_90/isotherm_summary.json`

Framework-Masse: 6158.936 u. Herkunft: `outputs/module_B_mixture_selectivity/runs/mof5_co2_n2_validation_pilot_10_90/data/IRMOF-1.data`.

Komponenten und Gesamtbeladung sind absolute Adsorption; mol/kg = mmol/g. Selektivität ist dimensionslos.
95-%-Intervalle beschreiben die Streuung unabhängiger Seed-Mittelwerte. Komponenten: Student-t; Selektivität: Fieller mit gepaarten Seeds.
Das Präzisionskriterium ist kein Nachweis der Equilibrierung. Unbeschränkte/undefinierte Intervalle erfüllen es nicht.

Präzisionsziel: relative Intervallhalbbreite ≤ 20 %, mindestens 3 Seeds.

| Druck / bar | Größe | Wert | Einheit | 95-%-Intervall | relative Halbbreite | Intervallstatus | Präzisionsziel (Größe) | Präzisionsziel (Punkt) |
|---:|:---|---:|:---|:---|---:|:---|:---|:---|
| 1 | CO2 | 0.0829653 | mol/kg | — | — | insufficient_replicates | nein | nein |
| 1 | N2 | 0.190561 | mol/kg | — | — | insufficient_replicates | nein | nein |
| 1 | total | 0.273526 | mol/kg | — | — | insufficient_replicates | — | nein |
| 1 | CO2/N2 | 3.91837 | dimensionless | — | — | insufficient_replicates | nein | nein |
| 1 | N2/CO2 | 0.255208 | dimensionless | — | — | insufficient_replicates | nein | nein |
| 5 | CO2 | 0.42066 | mol/kg | — | — | insufficient_replicates | nein | nein |
| 5 | N2 | 0.972574 | mol/kg | — | — | insufficient_replicates | nein | nein |
| 5 | total | 1.39323 | mol/kg | — | — | insufficient_replicates | — | nein |
| 5 | CO2/N2 | 3.8927 | dimensionless | — | — | insufficient_replicates | nein | nein |
| 5 | N2/CO2 | 0.256891 | dimensionless | — | — | insufficient_replicates | nein | nein |
| 10 | CO2 | 0.886368 | mol/kg | — | — | insufficient_replicates | nein | nein |
| 10 | N2 | 1.86251 | mol/kg | — | — | insufficient_replicates | nein | nein |
| 10 | total | 2.74887 | mol/kg | — | — | insufficient_replicates | — | nein |
| 10 | CO2/N2 | 4.2831 | dimensionless | — | — | insufficient_replicates | nein | nein |
| 10 | N2/CO2 | 0.233476 | dimensionless | — | — | insufficient_replicates | nein | nein |
| 20 | CO2 | 1.75426 | mol/kg | — | — | insufficient_replicates | nein | nein |
| 20 | N2 | 3.45343 | mol/kg | — | — | insufficient_replicates | nein | nein |
| 20 | total | 5.20769 | mol/kg | — | — | insufficient_replicates | — | nein |
| 20 | CO2/N2 | 4.57179 | dimensionless | — | — | insufficient_replicates | nein | nein |
| 20 | N2/CO2 | 0.218733 | dimensionless | — | — | insufficient_replicates | nein | nein |

## Referenzprüfung

Reingasisothermen werden nicht als Gemischreferenz verwendet. Unbekannte Adsorptionsbasis wird nicht als absolut interpretiert.

- 1 bar, `DDEC_IRMOF-1_UFF_CO2_298.csv`: pure_component_or_missing_mixture_metadata
- 1 bar, `DDEC_IRMOF-1_UFF_N2_298.csv`: pure_component_or_missing_mixture_metadata
- 1 bar, `10.1016j.seppur.2018.01.013.Isotherm4.json`: adsorption_basis_unknown, composition_mismatch_or_missing_component_data
- 1 bar, `10.1039b807470d.Isotherm14.json`: excess_reference_requires_mixture_conversion
- 5 bar, `DDEC_IRMOF-1_UFF_CO2_298.csv`: pure_component_or_missing_mixture_metadata
- 5 bar, `DDEC_IRMOF-1_UFF_N2_298.csv`: pure_component_or_missing_mixture_metadata
- 5 bar, `10.1016j.seppur.2018.01.013.Isotherm4.json`: adsorption_basis_unknown, composition_mismatch_or_missing_component_data
- 5 bar, `10.1039b807470d.Isotherm14.json`: excess_reference_requires_mixture_conversion
- 10 bar, `DDEC_IRMOF-1_UFF_CO2_298.csv`: pure_component_or_missing_mixture_metadata
- 10 bar, `DDEC_IRMOF-1_UFF_N2_298.csv`: pure_component_or_missing_mixture_metadata
- 10 bar, `10.1016j.seppur.2018.01.013.Isotherm4.json`: adsorption_basis_unknown, composition_mismatch_or_missing_component_data
- 10 bar, `10.1039b807470d.Isotherm14.json`: excess_reference_requires_mixture_conversion
- 20 bar, `DDEC_IRMOF-1_UFF_CO2_298.csv`: pure_component_or_missing_mixture_metadata
- 20 bar, `DDEC_IRMOF-1_UFF_N2_298.csv`: pure_component_or_missing_mixture_metadata
- 20 bar, `10.1016j.seppur.2018.01.013.Isotherm4.json`: adsorption_basis_unknown, composition_mismatch_or_missing_component_data
- 20 bar, `10.1039b807470d.Isotherm14.json`: excess_reference_requires_mixture_conversion

Ein bisheriger Vergleich von CO₂+N₂-Gesamtbeladung mit reinem CO₂ ist ungültig; daraus abgeleitete Fehlerprozente sind kein Validierungsergebnis.
