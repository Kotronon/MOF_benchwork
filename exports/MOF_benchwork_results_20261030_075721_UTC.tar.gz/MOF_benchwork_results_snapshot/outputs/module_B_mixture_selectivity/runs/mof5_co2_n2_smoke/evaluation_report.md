# Isotherm Evaluation

Source: `outputs/module_B_mixture_selectivity/runs/mof5_co2_n2_smoke/isotherm_summary.json`

## Summary

- Pressure points: 1
- Mean comparison error: 0.668021 mol/kg
- Mean comparison relative error: 80.447 %

## Isotherm Table

| pressure / bar | CO2 / cell | absolute / mol kg^-1 | excess / mol kg^-1 | reference / mol kg^-1 | compared as | rel. error / % |
|---:|---:|---:|---:|---:|:---|---:|
| 1 | 1 | 0.162366 |  | 0.830387 | absolute | -80.447 |

## Notes

- Loading is absolute adsorption from the GCMC molecule count.
- Excess loading is calculated as absolute loading minus bulk gas density times pore volume.
- mol/kg and mmol/g have the same numeric value.
- Reference values are matched exactly where possible and otherwise linearly interpolated.
- Excess references are compared against excess loading; unknown-basis references are reported and treated as absolute for comparison.
