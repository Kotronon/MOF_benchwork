# Module B: korrigierte Gemisch-Auswertung

**Pilot ausgewertet; quantitative Referenzvalidierung offen**

Quelle: `outputs/module_B_mixture_selectivity/runs/uio66_co2_ch4_nist_303K_50_50_pressure_screen_seed12345/isotherm_summary.json`

Framework-Masse: 52097.088 u. Herkunft: `outputs/module_B_mixture_selectivity/runs/uio66_co2_ch4_nist_303K_50_50_pressure_screen_seed12345/data/UiO-66(Zr).data`.

Komponenten und Gesamtbeladung sind absolute Adsorption; mol/kg = mmol/g. Selektivität ist dimensionslos.
95-%-Intervalle beschreiben die Streuung unabhängiger Seed-Mittelwerte. Komponenten: Student-t; Selektivität: Fieller mit gepaarten Seeds.
Das Präzisionskriterium ist kein Nachweis der Equilibrierung. Unbeschränkte/undefinierte Intervalle erfüllen es nicht.

Präzisionsziel: relative Intervallhalbbreite ≤ 20 %, mindestens 3 Seeds.

| Druck / bar | Größe | Wert | Einheit | 95-%-Intervall | relative Halbbreite | Intervallstatus | Präzisionsziel (Größe) | Präzisionsziel (Punkt) |
|---:|:---|---:|:---|:---|---:|:---|:---|:---|
| 0.5407 | CO2 | 0.865277 | mol/kg | — | — | insufficient_replicates | nein | nein |
| 0.5407 | CH4 | 0.326314 | mol/kg | — | — | insufficient_replicates | nein | nein |
| 0.5407 | total | 1.19159 | mol/kg | — | — | insufficient_replicates | — | nein |
| 0.5407 | CO2/CH4 | 2.65167 | dimensionless | — | — | insufficient_replicates | nein | nein |
| 0.5407 | CH4/CO2 | 0.37712 | dimensionless | — | — | insufficient_replicates | nein | nein |
| 1.2442 | CO2 | 1.50247 | mol/kg | — | — | insufficient_replicates | nein | nein |
| 1.2442 | CH4 | 0.519392 | mol/kg | — | — | insufficient_replicates | nein | nein |
| 1.2442 | total | 2.02187 | mol/kg | — | — | insufficient_replicates | — | nein |
| 1.2442 | CO2/CH4 | 2.89275 | dimensionless | — | — | insufficient_replicates | nein | nein |
| 1.2442 | CH4/CO2 | 0.345691 | dimensionless | — | — | insufficient_replicates | nein | nein |
| 2.1552 | CO2 | 1.89541 | mol/kg | — | — | insufficient_replicates | nein | nein |
| 2.1552 | CH4 | 0.741451 | mol/kg | — | — | insufficient_replicates | nein | nein |
| 2.1552 | total | 2.63686 | mol/kg | — | — | insufficient_replicates | — | nein |
| 2.1552 | CO2/CH4 | 2.55635 | dimensionless | — | — | insufficient_replicates | nein | nein |
| 2.1552 | CH4/CO2 | 0.391183 | dimensionless | — | — | insufficient_replicates | nein | nein |
| 2.6942 | CO2 | 2.28457 | mol/kg | — | — | insufficient_replicates | nein | nein |
| 2.6942 | CH4 | 0.826511 | mol/kg | — | — | insufficient_replicates | nein | nein |
| 2.6942 | total | 3.11108 | mol/kg | — | — | insufficient_replicates | — | nein |
| 2.6942 | CO2/CH4 | 2.76412 | dimensionless | — | — | insufficient_replicates | nein | nein |
| 2.6942 | CH4/CO2 | 0.361779 | dimensionless | — | — | insufficient_replicates | nein | nein |
| 3.1909 | CO2 | 2.27403 | mol/kg | — | — | insufficient_replicates | nein | nein |
| 3.1909 | CH4 | 0.87431 | mol/kg | — | — | insufficient_replicates | nein | nein |
| 3.1909 | total | 3.14835 | mol/kg | — | — | insufficient_replicates | — | nein |
| 3.1909 | CO2/CH4 | 2.60095 | dimensionless | — | — | insufficient_replicates | nein | nein |
| 3.1909 | CH4/CO2 | 0.384475 | dimensionless | — | — | insufficient_replicates | nein | nein |
| 4.1021 | CO2 | 2.52357 | mol/kg | — | — | insufficient_replicates | nein | nein |
| 4.1021 | CH4 | 0.957865 | mol/kg | — | — | insufficient_replicates | nein | nein |
| 4.1021 | total | 3.48143 | mol/kg | — | — | insufficient_replicates | — | nein |
| 4.1021 | CO2/CH4 | 2.63458 | dimensionless | — | — | insufficient_replicates | nein | nein |
| 4.1021 | CH4/CO2 | 0.379567 | dimensionless | — | — | insufficient_replicates | nein | nein |
| 6.2134 | CO2 | 2.60599 | mol/kg | — | — | insufficient_replicates | nein | nein |
| 6.2134 | CH4 | 1.46333 | mol/kg | — | — | insufficient_replicates | nein | nein |
| 6.2134 | total | 4.06933 | mol/kg | — | — | insufficient_replicates | — | nein |
| 6.2134 | CO2/CH4 | 1.78086 | dimensionless | — | — | insufficient_replicates | nein | nein |
| 6.2134 | CH4/CO2 | 0.561525 | dimensionless | — | — | insufficient_replicates | nein | nein |
| 8.1581 | CO2 | 2.73547 | mol/kg | — | — | insufficient_replicates | nein | nein |
| 8.1581 | CH4 | 1.55667 | mol/kg | — | — | insufficient_replicates | nein | nein |
| 8.1581 | total | 4.29214 | mol/kg | — | — | insufficient_replicates | — | nein |
| 8.1581 | CO2/CH4 | 1.75725 | dimensionless | — | — | insufficient_replicates | nein | nein |
| 8.1581 | CH4/CO2 | 0.56907 | dimensionless | — | — | insufficient_replicates | nein | nein |
| 10.2268 | CO2 | 2.74826 | mol/kg | — | — | insufficient_replicates | nein | nein |
| 10.2268 | CH4 | 1.6263 | mol/kg | — | — | insufficient_replicates | nein | nein |
| 10.2268 | total | 4.37456 | mol/kg | — | — | insufficient_replicates | — | nein |
| 10.2268 | CO2/CH4 | 1.68989 | dimensionless | — | — | insufficient_replicates | nein | nein |
| 10.2268 | CH4/CO2 | 0.591756 | dimensionless | — | — | insufficient_replicates | nein | nein |
| 12.1707 | CO2 | 2.9101 | mol/kg | — | — | insufficient_replicates | nein | nein |
| 12.1707 | CH4 | 1.84046 | mol/kg | — | — | insufficient_replicates | nein | nein |
| 12.1707 | total | 4.75056 | mol/kg | — | — | insufficient_replicates | — | nein |
| 12.1707 | CO2/CH4 | 1.58119 | dimensionless | — | — | insufficient_replicates | nein | nein |
| 12.1707 | CH4/CO2 | 0.632437 | dimensionless | — | — | insufficient_replicates | nein | nein |

## Referenzprüfung

Reingasisothermen werden nicht als Gemischreferenz verwendet. Unbekannte Adsorptionsbasis wird nicht als absolut interpretiert.

- 0.5407 bar, `10.1021jp202633t.Isotherm28.json`: composition_mismatch_or_missing_component_data
- 0.5407 bar, `10.1021jp202633t.Isotherm25.json`: composition_mismatch_or_missing_component_data
- 0.5407 bar, `10.1021jp202633t.Isotherm26.json`: composition_mismatch_or_missing_component_data
- 0.5407 bar, `10.1021jp202633t.Isotherm27.json`: composition_mismatch_or_missing_component_data
- 1.2442 bar, `10.1021jp202633t.Isotherm28.json`: composition_mismatch_or_missing_component_data
- 1.2442 bar, `10.1021jp202633t.Isotherm25.json`: composition_mismatch_or_missing_component_data
- 1.2442 bar, `10.1021jp202633t.Isotherm26.json`: composition_mismatch_or_missing_component_data
- 1.2442 bar, `10.1021jp202633t.Isotherm27.json`: composition_mismatch_or_missing_component_data
- 2.1552 bar, `10.1021jp202633t.Isotherm28.json`: composition_mismatch_or_missing_component_data
- 2.1552 bar, `10.1021jp202633t.Isotherm25.json`: composition_mismatch_or_missing_component_data
- 2.1552 bar, `10.1021jp202633t.Isotherm26.json`: composition_mismatch_or_missing_component_data
- 2.1552 bar, `10.1021jp202633t.Isotherm27.json`: composition_mismatch_or_missing_component_data
- 2.6942 bar, `10.1021jp202633t.Isotherm28.json`: composition_mismatch_or_missing_component_data
- 2.6942 bar, `10.1021jp202633t.Isotherm25.json`: composition_mismatch_or_missing_component_data
- 2.6942 bar, `10.1021jp202633t.Isotherm26.json`: composition_mismatch_or_missing_component_data
- 2.6942 bar, `10.1021jp202633t.Isotherm27.json`: composition_mismatch_or_missing_component_data
- 3.1909 bar, `10.1021jp202633t.Isotherm28.json`: composition_mismatch_or_missing_component_data
- 3.1909 bar, `10.1021jp202633t.Isotherm25.json`: composition_mismatch_or_missing_component_data
- 3.1909 bar, `10.1021jp202633t.Isotherm26.json`: composition_mismatch_or_missing_component_data
- 3.1909 bar, `10.1021jp202633t.Isotherm27.json`: composition_mismatch_or_missing_component_data
- 4.1021 bar, `10.1021jp202633t.Isotherm28.json`: composition_mismatch_or_missing_component_data
- 4.1021 bar, `10.1021jp202633t.Isotherm25.json`: composition_mismatch_or_missing_component_data
- 4.1021 bar, `10.1021jp202633t.Isotherm26.json`: composition_mismatch_or_missing_component_data
- 4.1021 bar, `10.1021jp202633t.Isotherm27.json`: composition_mismatch_or_missing_component_data
- 6.2134 bar, `10.1021jp202633t.Isotherm28.json`: composition_mismatch_or_missing_component_data
- 6.2134 bar, `10.1021jp202633t.Isotherm25.json`: composition_mismatch_or_missing_component_data
- 6.2134 bar, `10.1021jp202633t.Isotherm26.json`: composition_mismatch_or_missing_component_data
- 6.2134 bar, `10.1021jp202633t.Isotherm27.json`: composition_mismatch_or_missing_component_data
- 8.1581 bar, `10.1021jp202633t.Isotherm28.json`: composition_mismatch_or_missing_component_data
- 8.1581 bar, `10.1021jp202633t.Isotherm25.json`: composition_mismatch_or_missing_component_data
- 8.1581 bar, `10.1021jp202633t.Isotherm26.json`: composition_mismatch_or_missing_component_data
- 8.1581 bar, `10.1021jp202633t.Isotherm27.json`: composition_mismatch_or_missing_component_data
- 10.2268 bar, `10.1021jp202633t.Isotherm28.json`: composition_mismatch_or_missing_component_data
- 10.2268 bar, `10.1021jp202633t.Isotherm25.json`: composition_mismatch_or_missing_component_data
- 10.2268 bar, `10.1021jp202633t.Isotherm26.json`: composition_mismatch_or_missing_component_data
- 10.2268 bar, `10.1021jp202633t.Isotherm27.json`: composition_mismatch_or_missing_component_data
- 12.1707 bar, `10.1021jp202633t.Isotherm28.json`: composition_mismatch_or_missing_component_data
- 12.1707 bar, `10.1021jp202633t.Isotherm25.json`: composition_mismatch_or_missing_component_data
- 12.1707 bar, `10.1021jp202633t.Isotherm26.json`: composition_mismatch_or_missing_component_data
- 12.1707 bar, `10.1021jp202633t.Isotherm27.json`: composition_mismatch_or_missing_component_data

Ein bisheriger Vergleich von CO₂+N₂-Gesamtbeladung mit reinem CO₂ ist ungültig; daraus abgeleitete Fehlerprozente sind kein Validierungsergebnis.
