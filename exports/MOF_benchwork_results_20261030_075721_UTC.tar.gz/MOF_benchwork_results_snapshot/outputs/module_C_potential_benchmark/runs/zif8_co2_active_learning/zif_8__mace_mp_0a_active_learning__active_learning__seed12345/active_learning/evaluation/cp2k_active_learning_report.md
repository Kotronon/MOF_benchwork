# Auswertung: ZIF-8/CO2 CP2K und MACE Active Learning

Die Kampagne endete mit `adaptation_not_converged`: Das konfigurierte Daten-/Rundenbudget wurde ausgeschöpft. Alle 152 Referenzjobs sind abgeschlossen. Der Cutoff-Test wählte 1200 Ry. Vier Erweiterungsrunden nach Iteration 0 wurden trainiert und auf denselben 20 zurückgehaltenen Testkonfigurationen bewertet.

| Iteration | Energie-MAE (eV/Konfiguration) | Mittlerer Kraftvektorfehler (eV/Å) | Maximale Energie-Streuung (eV) | Maximale Kraft-Streuung (eV/Å) |
|---|---:|---:|---:|---:|
| 0 | 1.816899 | 0.128129 | 4.486113 | 1.948427 |
| 1 | 0.273597 | 0.065512 | 0.444244 | 1.836831 |
| 2 | 0.152059 | 0.049420 | 0.302956 | 1.362506 |
| 3 | 0.160862 | 0.043491 | 0.286645 | 1.953901 |
| 4 | 0.136041 | 0.037436 | 0.333721 | 1.591884 |

## Bewertung

Von Iteration 0 bis 4 sinkt der Energie-MAE um 92,5 %, der mittlere Kraftvektorfehler um 70,8 %. Iteration 4 liefert die besten mittleren Committee-Fehler dieser Kampagne. Gegenüber Iteration 3 sinken Energie- und Kraftfehler um etwa 15,4 % bzw. 13,9 %.

Das Committee-Mittel der letzten Runde hat einen Energiefehler von 0,1360 eV gegenüber dem Ziel 0,043 eV (3,16-fach). Der Kraftfehler von 0,03744 eV/Å unterschreitet das Ziel 0,1 eV/Å. Die maximalen Committee-Streuungen liegen bei 0,3337 eV und 1,5919 eV/Å, gegenüber den konfigurierten Grenzen 0,043 eV und 0,1 eV/Å. Kein vollständiges Bestehen; zwei aufeinanderfolgende bestandene Runden wurden nicht erreicht.

Einzelmodell mit dem kleinsten gespeicherten kombinierten Testscore: Iteration 4, Mitglied 1 (Seed 23456), Energie-MAE 0,08758 eV, Kraftfehler 0,04575 eV/Å. Diese Auswahl nutzt den Testsatz und ist daher explorativ; eine belastbare Modellauswahl sollte den Validierungssatz verwenden und anschließend auf neuen Testdaten bestätigt werden.

Energiefehler beziehen sich auf gesamte Konfigurationen, nicht pro Atom und nicht direkt auf Adsorptionsenergien. Kraftfehler sind Mittelwerte der Norm des Fehlervektors pro Atom. Committee-Streuung misst Unterschiede zwischen Modellen und ist kein direkt gemessener DFT-Fehler. Die hohen Maxima können einzelne problematische Atome/Konfigurationen betreffen; aggregierte Metriken lokalisieren diese nicht.

Die Resultate belegen Lernen gegenüber der bereits trainierten Iteration 0, nicht gegenüber dem unveränderten Foundation-Modell. Die wiederholte adaptive Nutzung desselben kleinen Testsatzes begrenzt die Aussagekraft für neue Strukturen. Ein bestandener Cutoff-Test belegt zudem nicht allein die absolute physikalische Richtigkeit des gewählten DFT-Verfahrens.

## Nächste Schritte

Keine weiteren unveränderten Runden automatisch anhängen. Zunächst Fehler und Committee-Streuung nach Testkonfiguration, Atomart und Beladung aufschlüsseln, problematische Geometrien und Referenzkonvergenz prüfen sowie Energieoffsets untersuchen. Für Adsorptionsanwendungen zusätzlich Insertions-/Adsorptionsenergien und daraus folgende Observablen testen. Nur gezielt neue DFT-Daten oder Trainingsanpassungen ergänzen. Modelle und Referenzen bleiben für diese Analysen nutzbar, die formale Produktionsvalidierung ist jedoch nicht bestanden.
