# ZIF-8/CO2: CP2K-Referenzvergleich von MACE und uMOF

## Durchführung

20 unveränderte zurückgehaltene Testkonfigurationen der abgeschlossenen Kampagne (4 Framework-, 8 Einzeladsorbat-, 8 Mehrfachadsorbat-Konfigurationen). Sechs Modelle auf denselben Strukturen ausgewertet: Foundation-MACE small, drei nachtrainierte MACE-Modelle aus Iteration 4, uMOF-MH und uMOF-POLAR mit Head `r2scan+d4`. Zusätzlich arithmetisches Mittel der drei nachtrainierten Modelle. CP2K-Referenz: PBE-D3(BJ), gewählter Cutoff 1200 Ry. Auswertung in float64 auf CUDA-Gerät 0, vier CPU-Threads, ohne zusätzlich aktivierte D3-Korrektur für die Modelle. Keine neue DFT-Berechnung, kein Nachtraining.

Alle Modelle wurden auf allen 20 Konfigurationen erfolgreich ausgewertet. Die neu berechneten Committee-Fehler stimmen numerisch mit den gespeicherten Validierungsergebnissen der Iteration 4 überein. Vorhersagen einschließlich Kräfte und Rechenzeiten sind je Modell in JSON gespeichert.

## Kraftvergleich

Die Metrik ist der Mittelwert der Norm des Kraftfehlervektors über alle Atome des Testsatzes (kein komponentenweiser RMSE).

| Modell | Mittlerer Kraftvektorfehler (eV/Å) | Maximaler Atom-Kraftfehler (eV/Å) | Median Energie+Kräfte (s/Konfiguration) |
|---|---:|---:|---:|
| MACE ohne Nachtraining | 0.495823 | 38.4520 | 0.131 |
| uMOF-MH | 0.304140 | 14.5727 | 0.528 |
| uMOF-POLAR | 0.318661 | 8.9027 | 1.036 |
| MACE nachtrainiert, Seed 23456 | 0.045748 | 6.5530 | 0.088 |
| MACE nachtrainiert, Committee | 0.037436 | 5.3570 | 0.263 |

Das nachtrainierte Committee reduziert den mittleren Kraftfehler gegenüber Foundation-MACE um 92,5 %, gegenüber uMOF-MH um 87,7 % und gegenüber uMOF-POLAR um 88,3 %. uMOF-MH und uMOF-POLAR sind ohne dieses lokale Nachtraining verfügbar. Der Vergleich bewertet Übereinstimmung mit der gewählten lokalen DFT-Referenz; deren tatsächliche physikalische Genauigkeit wird dadurch nicht bestimmt.

## Gesamtenergien: keine direkte Qualitätsrangliste

Die rohen Gesamtenergie-MAE betragen etwa 50.283 eV (Foundation-MACE), 50.036 eV (uMOF-MH), 50.035 eV (uMOF-POLAR), gegenüber 0,1360 eV für das nachtrainierte Committee. Für das Einzelmodell Seed 23456 sind es 0,08758 eV. Die enormen Unterschiede der vortrainierten Modelle werden durch unterschiedliche Energienullpunkte und Referenzverfahren überlagert; sie sind keine Adsorptionsenergiefehler. Ein Vergleich relativer Energien/Adsorptionsenergien erfordert konsistent berechnete Referenzen. Eine nachträgliche Anpassung von Offsets auf dem Testsatz wäre keine unabhängige Validierung.

## Grenzen und Empfehlung

uMOF wurde auf r2SCAN-D4 trainiert, die lokalen Labels verwenden PBE-D3(BJ). Unterschiede der Kräfte enthalten daher auch die Differenz dieser Referenzmethoden. Der Vorteil des nachtrainierten Modells ist die lokale Anpassung an PBE-D3(BJ), nicht der Nachweis genereller Überlegenheit über uMOF.

Der Testsatz wurde für die Berichterstattung und explorative Auswahl des Einzelmodells Seed 23456 wiederholt betrachtet; diesen Vorteil auf frischen unabhängigen Daten bestätigen. Ein Gesamtmittel kann Fehler an wenigen Atomen oder Adsorbatkonfigurationen verdecken. Die maximalen Kraftfehler bleiben auch bei nachtrainierten Modellen groß. Kategorieauswertung und Einzelkonfigurationen liegen als zusätzliche CSV-Dateien vor.

Rechenzeiten sind orientierende Messungen einer einzelnen GPU-Auswertung inklusive möglicher Initialisierungseffekte; Median wird berichtet, Laden ausgeschlossen. Committee-Zeit ist die Summe der drei Mitgliedslaufzeiten. Bei uMOF-POLAR traten vom CUDA-Allocator abgefangene Speicherengpässe auf; alle Vorhersagen wurden dennoch fertiggestellt. Keine belastbare allgemeine Geschwindigkeitsrangliste aus diesen Einzelmessungen ableiten.

Die komplette ursprüngliche Validierung bleibt nicht bestanden: Energie-MAE und maximale Committee-Streuungen überschreiten die Grenzwerte. Der vorliegende Vergleich ersetzt keine Validierung der Adsorptionsisothermen, Henry-Konstanten oder Selektivitäten.

## Formulierung für die Präsentation

„Auf 20 zurückgehaltenen ZIF-8/CO2-Konfigurationen senkte das lokale CP2K-basierte Nachtraining den mittleren Kraftfehler gegenüber dem unveränderten MACE-Modell von 0,496 auf 0,037 eV/Å. Vortrainierte uMOF-Modelle erreichten ohne lokales Nachtraining etwa 0,30–0,32 eV/Å. Das zeigt eine deutlich bessere Anpassung an unsere PBE-D3(BJ)-Referenz; wegen unterschiedlicher DFT-Referenzmethoden und fehlender Adsorptionsvalidierung ist daraus keine allgemeine physikalische Überlegenheit abzuleiten.“

Reproduktion: `python scripts/compare_zif8_cp2k_umof.py --device cuda:0`. Ergebnisse sind zwischengespeichert; für einen vollständigen Neulauf die modellweisen `*_predictions.json` in einen anderen Ordner verschieben.
