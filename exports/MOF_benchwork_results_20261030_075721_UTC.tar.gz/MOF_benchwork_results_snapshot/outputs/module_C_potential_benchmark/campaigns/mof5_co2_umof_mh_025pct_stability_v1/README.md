# Bounded MOF-5/CO2 comparison against CRAFTED

This campaign continues the existing one-seed trajectories of pretrained
UMOF-MH and the selected 25% fine-tuned model at 298 K and 0.1, 1 and 10 bar.
It does not start DFT jobs or training. The original trajectories are preserved;
point directories contain separate copies of their restart files and accepted-
transition histories. A separate six-step GPU restart test verified that the
existing history is preserved exactly during continuation.

The 10-bar original UMOF point passes the initial operational screen and is
reused. The other five points may each add at most 20,000 MC moves, in chunks
of 10,000, with re-assessment after each chunk. Total additional work is capped
at 100,000 moves for these inputs. The hard configured per-point limit remains
20,000 even if a trajectory fails the stability screen. The campaign ends
with an explicitly unresolved assessment instead of extending indefinitely.

The two high-pressure points are scheduled first; available GPUs then process
other points. The launcher uses physical GPUs 0,3,1,2, one worker per GPU.
The source seed schedule is 104729 / 104730 / 104731 by pressure. A continued
trajectory is one chain, not another replicate. Since MLIP-MC 0.1.3 does not
save random-generator state, each chunk is reseeded with source point seed
plus completed MC steps. This does not claim bitwise agreement with an
uninterrupted simulation.

The final evaluation uses at most the last 20,000 samples after the original
equilibration period. Operational criteria are:

- at least 20,000 samples;
- estimated statistical inefficiency from an initial positive, monotonized
  autocorrelation-pair sum, and at least 20 estimated effective samples;
- batches of max(500, ceil(2*inefficiency)) steps, with at least eight batches;
- approximate 95% Student-t batch-mean interval half-width at most
  max(15% of the mean, 0.02 mmol/g);
- first/second half means differ by no more than that same tolerance.

These are predeclared pragmatic screening checks, not a rigorous proof of
stationarity or equilibration. Constant/frozen histories cannot pass. With one
seed there is no independent-replicate confidence interval. No seed is added
without changing the declared scope.

After six points finish, the runner automatically generates:

- comparison/RESULT.md: plain-language result and MAE/RMSE table;
- comparison/isotherm_comparison.png/.svg and reference_deviations.png/.svg;
- comparison/loading_histories.png/.svg: binned histories and running means;
- comparison/final_assessment.json: descriptive RMSE ordering, explicitly
  inconclusive when any point fails the operational screen;
- comparison/sampling_details.json and runtime_details.csv: diagnostics and
  source/additional runtime accounting.

Reference: CRAFTED DDEC_IRMOF-1_UFF_CO2_298.csv, matched absolute mol/kg (=mmol/g).
Both models retain the same structure, temperature, fugacity convention,
float64 precision and their own correct inference heads. Model/source hashes
are pinned in manifest.json. MAE/RMSE give equal weight to the three pressures.
This is a MOF-5 case study, not a claim about other MOFs or all MLIPs.

From an activated MOF_sim environment:

```bash
bash scripts/run_umof_isotherm_stability.sh status
```

run.log and per-model/pressure logs show activity. To resume the same bounded
campaign after an interruption (when no launcher is active):

```bash
bash scripts/run_umof_isotherm_stability.sh run --gpus 0,3,1,2
```

The existing original comparison campaigns and DFT stop state are unchanged.
