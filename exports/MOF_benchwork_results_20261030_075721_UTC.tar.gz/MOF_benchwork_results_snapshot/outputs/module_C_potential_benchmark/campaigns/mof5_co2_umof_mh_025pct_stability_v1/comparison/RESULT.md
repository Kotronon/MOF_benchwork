# MOF-5 / CO2: UMOF versus 25% fine-tuning

298 K; 0.1, 1 and 10 bar; one continued trajectory per model/pressure.

Reference: CRAFTED UFF/DDEC, absolute loading. No DFT calculations are used.

Assessment: inconclusive_sampling

| Model | MAE (mmol/g) | RMSE (mmol/g) |
|---|---:|---:|
| umof_mh_pretrained | 2.4133 | 3.9926 |
| umof_mh_finetuned_025pct | 4.1690 | 7.0795 |

The lowest descriptive RMSE belongs to umof_mh_pretrained.

Sampling remains unresolved at 4 point(s); a definitive ranking is withheld.

The screen uses a 20,000-step final evaluation window, correlation estimates, at least eight batch means, an effective-sample estimate of at least 20, and drift/precision tolerances of max(15% of loading, 0.02 mmol/g). It is a heuristic check, not proof of equilibrium. Full source and continuation histories are preserved.

See sampling_details.json and loading_histories.png for drift and uncertainty diagnostics. runtime_details.csv reports observed trajectory cost, including source runs and additional work; it is not a controlled timing test on identical loaded configurations. Neither training cost nor DFT runtime is included in those timings.
