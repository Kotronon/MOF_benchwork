# Module C isotherm comparison

IRMOF-1/CO2, 298 K; 2 models.

`isotherm_comparison.png` and `.svg`: model means ± sample standard deviation across independent seed runs, with linear and logarithmic pressure axes. `isotherm_seed_comparison.png` and `.svg`: individual seed curves; each panel has its own loading scale. CSV files retain aggregate and per-seed observations.

Within-run loading fluctuations are not used as error bars on a mean. Neither seed agreement nor completion proves equilibration or convergence. Runtime ranking is omitted because result-file runtimes may reflect reused runs.

The dashed black curve is CRAFTED UFF/DDEC (simulation) at matching conditions. It is a classical simulation baseline, not experimental ground truth. See https://www.nature.com/articles/s41597-023-02116-z . Reference pressures are converted from Pa to bar; loading is absolute in mol/kg. Metrics compare seed means with equal weight per matched pressure, use linear interpolation only where needed, and never extrapolate. Matching methods and SHA-256 provenance are archived. The source error column is retained but not plotted or treated as a confidence interval.
