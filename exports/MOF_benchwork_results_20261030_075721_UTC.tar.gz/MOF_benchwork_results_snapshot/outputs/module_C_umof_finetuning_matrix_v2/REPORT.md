# uMOF fine-tuning transfer test

Purpose: **production**. Completed runs: 0/4.

See matrix_summary.csv, learning_curves.csv and per-run results/metrics.csv. Gas groups describe whole configurations, not isolated guest force errors. Nominal and actual data fractions differ because each occupied stratum is retained.

Mixture validation and flexible-framework validation remain **open**. Energy/force transfer errors do not establish adsorption accuracy or independence from foundation pretraining.
