# uMOF v2 verification and handover

Verified on 2026-10-23. Status: **passed**. Production training has not started.

- Module-C suite: 196 tests, 187 passed, 9 skipped, no failures. Eight skips require unavailable classical LAMMPS integration dependencies; one is the opt-in generic MACE integration test. The requested real uMOF CPU integration test was run separately and passed.
- Focused uMOF regressions: 26 tests, all passed after the final lifecycle checks.
- Real-data CPU smoke: 9 adsorption training, 3 validation, 3 test; 8 replay training, 2 replay validation. Three completed zero-based epochs [0, 1, 2], split across two invocations (2 epochs, then resume to 3). SWA start remains 1 in both smoke invocations; production SWA start remains 40.
- Shared model weights changed; both pt_head and Default were preserved; 61 logged loss values were finite. Strict checkpoint identity/hash verification passed. Both Stage-1 and Stage-2 exports were recorded. Final validation selected Stage 1. Baseline comparison and Module-C backend loading passed, including float64 verification.
- MACE process time including its built-in export/evaluation: 164.06 seconds. This is a small technical check and is not a production runtime estimate.
- Four prepared runs: 109, 211, 398, 774 training frames; shared 46 validation and 38 test frames. Selections remain identical to the previous pure-gas preparation and are nested. Replay consists of 1100 distinct configurations split 1000/100; all fractions share exactly the same selection.
- Directory transfer, read-only archived inputs and disabled network access passed. Source and prepared file checksums verified. Lock contention and checkpoint tampering were rejected in regression tests. Test-label changes do not enter training identity or validation selection.
- PNG parity and learning-curve figures were visually inspected; PNG/SVG and English CSV/JSON outputs are available in the separate smoke campaign. Prepared matrix reports contain no invented training metrics.
- Shell syntax and git whitespace checks passed.

The production campaign includes its own foundation checkpoint and replay selection under assets/. Transfer the repository implementation together with the complete campaign directory. Use the root MODULE_C_UMOF_FINETUNING.md guide and START.txt for cluster commands. No production model was replaced.

Current data contain CO2, N2 and CH4 pure-gas configurations only. Real mixture validation and validated framework flexibility remain open. Distinct source cells are evidence of sampled structural variation, not validation of a Module-D deformation pathway.
