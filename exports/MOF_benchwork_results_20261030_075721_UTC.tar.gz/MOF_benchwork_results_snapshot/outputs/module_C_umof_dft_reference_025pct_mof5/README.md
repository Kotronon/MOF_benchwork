# Targeted MOF-5/CO2 r2SCAN+D4 reference

Selected four single-guest geometries from the previous paired-model energy
diagnostic: zero-based sample IDs 4, 3, 17, 11 (plot positions 5, 4, 18, 12).
Per source trajectory, selection covers the largest and a median model
interaction-energy discrepancy among baseline-bound poses. This is a targeted
diagnostic, not an unbiased test benchmark or a full adsorption validation.

Each geometry is frozen. Periodic single-point energies use CP2K 2026.1,
r2SCAN via LibXC, TZV2P-MOLOPT-SCAN-GTH basis sets, SCAN-optimized GTH
pseudopotentials (Zn q12), gamma point, neutral singlets, cutoff 1200 Ry,
relative cutoff 100 Ry and EPS_SCF 1e-8 Hartree. D4 is added using the separate
project-local dftd4 3.7.0 reference library, r2scan parameters and the ATM term,
with the same periodic geometry and neutral charge. CP2K has no built-in D4
support in this environment; no D3 substitution is made.

Twenty single-point calculations cover:

- one common empty host;
- four combined structures, four corresponding isolated guest geometries;
- two ghost-basis fragment calculations per pose for counterpoise/BSSE checks;
- host, guest and combined system for the first pose at 1600 Ry to check an
  adsorption-energy difference, rather than per-atom absolute energy convergence.

For each pose, both uncorrected and counterpoise-corrected r2SCAN+D4 adsorption
energies are reported. D4 terms use physical atoms only, never ghost centers.
The initial grid-difference target is 0.5 kJ/mol; a failure must qualify the
comparison rather than be ignored. CP2K energies are only collected after
normal program termination and explicit final SCF convergence. Input, basis,
potential and source-data SHA-256 values are archived in manifest.json.

This is an independent CP2K/GTH reference, not an exact reproduction of uMOF's
VASP 6.4.2/PAW settings. Matching XC/dispersion does not remove pseudopotential,
basis and numerical differences. Raw absolute energies must not be compared
between CP2K and the MLIPs. A stable ordering across BSSE treatments is more
informative than a tiny difference between models. No result here alone
validates the finite-loading isotherm or experimental accuracy.

From an activated MOF_sim environment:

```bash
bash scripts/run_umof_dft_reference.sh status
bash scripts/run_umof_dft_reference.sh collect
```

`status` reports per-job states without blocking the active runner. After the runner stops, `collect` refreshes progress and generates the
final comparison only when every required reference is complete. The running
launcher writes run.log, run_status.json and progress.json here. Each jobs/*
directory contains cp2k.inp, cp2k.out, launcher.log, geometry.extxyz, status.json
and, after success, energy.json.

The background runner automatically produces comparison.csv, comparison.json,
comparison.png/.svg and REPORT.md after all jobs finish. Already completed,
converged jobs can be reused with:

```bash
bash scripts/run_umof_dft_reference.sh run --parallel 2 --threads 8
```

Do not launch a second runner while one owns the campaign lock.

Method sources:

- https://arxiv.org/html/2608.28100v1#S2.SS1.SSS1
- https://manual.cp2k.org/cp2k-2026_1-branch/CP2K_INPUT/FORCE_EVAL/DFT/XC/VDW_POTENTIAL/PAIR_POTENTIAL.html
- https://dftd4.readthedocs.io/en/latest/reference/python.html
