# Module B: korrigierte Gemisch-Auswertung

**Pilot ausgewertet; quantitative Referenzvalidierung offen**

Quelle: `outputs/module_B_active_learning/production/mof5/simulation/runs/al_00006_79dfd9919466420f53af/isotherm_summary.json`

Framework-Masse: 6158.936 u. Herkunft: `outputs/module_B_active_learning/production/mof5/simulation/runs/al_00006_79dfd9919466420f53af/data/IRMOF-1.data`.

Komponenten und Gesamtbeladung sind absolute Adsorption; mol/kg = mmol/g. Selektivität ist dimensionslos.
95-%-Intervalle beschreiben die Streuung unabhängiger Seed-Mittelwerte. Komponenten: Student-t; Selektivität: Fieller mit gepaarten Seeds.
Das Präzisionskriterium ist kein Nachweis der Equilibrierung. Unbeschränkte/undefinierte Intervalle erfüllen es nicht.

Präzisionsziel: relative Intervallhalbbreite ≤ 20 %, mindestens 3 Seeds.

| Druck / bar | Größe | Wert | Einheit | 95-%-Intervall | relative Halbbreite | Intervallstatus | Präzisionsziel (Größe) | Präzisionsziel (Punkt) |
|---:|:---|---:|:---|:---|---:|:---|:---|:---|
| 0.351562 | CO2 | 0.321275 | mol/kg | [0.300585, 0.341964] | 6.44 % | bounded | ja | nein |
| 0.351562 | N2 | 0.000324083 | mol/kg | [-0.000481049, 0.00112922] | 248.43 % | bounded | nein | nein |
| 0.351562 | total | 0.321599 | mol/kg | [0.30161, 0.341587] | 6.22 % | bounded | — | nein |
| 0.351562 | CO2/N2 | 0.942481 | dimensionless | — | — | unbounded | nein | nein |
| 0.351562 | N2/CO2 | 1.06103 | dimensionless | [-1.49126, 3.92066] | 255.03 % | bounded | nein | nein |

## Referenzprüfung

Reingasisothermen werden nicht als Gemischreferenz verwendet. Unbekannte Adsorptionsbasis wird nicht als absolut interpretiert.


Ein bisheriger Vergleich von CO₂+N₂-Gesamtbeladung mit reinem CO₂ ist ungültig; daraus abgeleitete Fehlerprozente sind kein Validierungsergebnis.
