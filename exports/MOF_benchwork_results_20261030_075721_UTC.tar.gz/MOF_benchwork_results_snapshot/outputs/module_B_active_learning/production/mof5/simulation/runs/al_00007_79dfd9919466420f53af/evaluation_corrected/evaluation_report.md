# Module B: korrigierte Gemisch-Auswertung

**Pilot ausgewertet; quantitative Referenzvalidierung offen**

Quelle: `outputs/module_B_active_learning/production/mof5/simulation/runs/al_00007_79dfd9919466420f53af/isotherm_summary.json`

Framework-Masse: 6158.936 u. Herkunft: `outputs/module_B_active_learning/production/mof5/simulation/runs/al_00007_79dfd9919466420f53af/data/IRMOF-1.data`.

Komponenten und Gesamtbeladung sind absolute Adsorption; mol/kg = mmol/g. Selektivität ist dimensionslos.
95-%-Intervalle beschreiben die Streuung unabhängiger Seed-Mittelwerte. Komponenten: Student-t; Selektivität: Fieller mit gepaarten Seeds.
Das Präzisionskriterium ist kein Nachweis der Equilibrierung. Unbeschränkte/undefinierte Intervalle erfüllen es nicht.

Präzisionsziel: relative Intervallhalbbreite ≤ 20 %, mindestens 3 Seeds.

| Druck / bar | Größe | Wert | Einheit | 95-%-Intervall | relative Halbbreite | Intervallstatus | Präzisionsziel (Größe) | Präzisionsziel (Punkt) |
|---:|:---|---:|:---|:---|---:|:---|:---|:---|
| 0.351562 | CO2 | 0.318646 | mol/kg | [0.298226, 0.339066] | 6.41 % | bounded | ja | nein |
| 0.351562 | N2 | 8.11423e-05 | mol/kg | [-0.000120443, 0.000282727] | 248.43 % | bounded | nein | nein |
| 0.351562 | total | 0.318727 | mol/kg | [0.29846, 0.338994] | 6.36 % | bounded | — | nein |
| 0.351562 | CO2/N2 | 3.73348 | dimensionless | — | — | unbounded | nein | nein |
| 0.351562 | N2/CO2 | 0.267847 | dimensionless | [-0.379292, 0.98229] | 254.17 % | bounded | nein | nein |

## Referenzprüfung

Reingasisothermen werden nicht als Gemischreferenz verwendet. Unbekannte Adsorptionsbasis wird nicht als absolut interpretiert.


Ein bisheriger Vergleich von CO₂+N₂-Gesamtbeladung mit reinem CO₂ ist ungültig; daraus abgeleitete Fehlerprozente sind kein Validierungsergebnis.
