# Module B: korrigierte Gemisch-Auswertung

**Pilot ausgewertet; quantitative Referenzvalidierung offen**

Quelle: `outputs/module_B_active_learning/production/mof5/simulation/runs/al_00004_bd30a0e49bab67016bdf/isotherm_summary.json`

Framework-Masse: 6158.936 u. Herkunft: `outputs/module_B_active_learning/production/mof5/simulation/runs/al_00004_bd30a0e49bab67016bdf/data/IRMOF-1.data`.

Komponenten und Gesamtbeladung sind absolute Adsorption; mol/kg = mmol/g. Selektivität ist dimensionslos.
95-%-Intervalle beschreiben die Streuung unabhängiger Seed-Mittelwerte. Komponenten: Student-t; Selektivität: Fieller mit gepaarten Seeds.
Das Präzisionskriterium ist kein Nachweis der Equilibrierung. Unbeschränkte/undefinierte Intervalle erfüllen es nicht.

Präzisionsziel: relative Intervallhalbbreite ≤ 20 %, mindestens 3 Seeds.

| Druck / bar | Größe | Wert | Einheit | 95-%-Intervall | relative Halbbreite | Intervallstatus | Präzisionsziel (Größe) | Präzisionsziel (Punkt) |
|---:|:---|---:|:---|:---|---:|:---|:---|:---|
| 0.505461 | CO2 | 0.135143 | mol/kg | [0.130882, 0.139403] | 3.15 % | bounded | ja | ja |
| 0.505461 | N2 | 0.0859901 | mol/kg | [0.0698005, 0.10218] | 18.83 % | bounded | ja | ja |
| 0.505461 | total | 0.221133 | mol/kg | [0.201242, 0.241024] | 8.99 % | bounded | — | ja |
| 0.505461 | CO2/N2 | 3.54242 | dimensionless | [3.0565, 4.25224] | 16.88 % | bounded | ja | ja |
| 0.505461 | N2/CO2 | 0.282293 | dimensionless | [0.23517, 0.327171] | 16.30 % | bounded | ja | ja |

## Referenzprüfung

Reingasisothermen werden nicht als Gemischreferenz verwendet. Unbekannte Adsorptionsbasis wird nicht als absolut interpretiert.


Ein bisheriger Vergleich von CO₂+N₂-Gesamtbeladung mit reinem CO₂ ist ungültig; daraus abgeleitete Fehlerprozente sind kein Validierungsergebnis.
