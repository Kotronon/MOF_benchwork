# Module B: korrigierte Gemisch-Auswertung

**Pilot ausgewertet; quantitative Referenzvalidierung offen**

Quelle: `outputs/module_B_active_learning/production/mof5/simulation/runs/al_00005_dfcc15b47deb76312043/isotherm_summary.json`

Framework-Masse: 6158.936 u. Herkunft: `outputs/module_B_active_learning/production/mof5/simulation/runs/al_00005_dfcc15b47deb76312043/data/IRMOF-1.data`.

Komponenten und Gesamtbeladung sind absolute Adsorption; mol/kg = mmol/g. Selektivität ist dimensionslos.
95-%-Intervalle beschreiben die Streuung unabhängiger Seed-Mittelwerte. Komponenten: Student-t; Selektivität: Fieller mit gepaarten Seeds.
Das Präzisionskriterium ist kein Nachweis der Equilibrierung. Unbeschränkte/undefinierte Intervalle erfüllen es nicht.

Präzisionsziel: relative Intervallhalbbreite ≤ 20 %, mindestens 3 Seeds.

| Druck / bar | Größe | Wert | Einheit | 95-%-Intervall | relative Halbbreite | Intervallstatus | Präzisionsziel (Größe) | Präzisionsziel (Punkt) |
|---:|:---|---:|:---|:---|---:|:---|:---|:---|
| 6.37527 | CO2 | 0.717628 | mol/kg | [0.677847, 0.75741] | 5.54 % | bounded | ja | ja |
| 6.37527 | N2 | 1.16389 | mol/kg | [1.12089, 1.20689] | 3.69 % | bounded | ja | ja |
| 6.37527 | total | 1.88152 | mol/kg | [1.85518, 1.90786] | 1.40 % | bounded | — | ja |
| 6.37527 | CO2/N2 | 4.41693 | dimensionless | [4.04174, 4.81869] | 8.80 % | bounded | ja | ja |
| 6.37527 | N2/CO2 | 0.226402 | dimensionless | [0.207525, 0.247418] | 8.81 % | bounded | ja | ja |

## Referenzprüfung

Reingasisothermen werden nicht als Gemischreferenz verwendet. Unbekannte Adsorptionsbasis wird nicht als absolut interpretiert.


Ein bisheriger Vergleich von CO₂+N₂-Gesamtbeladung mit reinem CO₂ ist ungültig; daraus abgeleitete Fehlerprozente sind kein Validierungsergebnis.
