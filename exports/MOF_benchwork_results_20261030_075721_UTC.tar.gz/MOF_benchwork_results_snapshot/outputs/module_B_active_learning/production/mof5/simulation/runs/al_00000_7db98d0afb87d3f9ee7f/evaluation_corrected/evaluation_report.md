# Module B: korrigierte Gemisch-Auswertung

**Pilot ausgewertet; quantitative Referenzvalidierung offen**

Quelle: `outputs/module_B_active_learning/production/mof5/simulation/runs/al_00000_7db98d0afb87d3f9ee7f/isotherm_summary.json`

Framework-Masse: 6158.936 u. Herkunft: `outputs/module_B_active_learning/production/mof5/simulation/runs/al_00000_7db98d0afb87d3f9ee7f/data/IRMOF-1.data`.

Komponenten und Gesamtbeladung sind absolute Adsorption; mol/kg = mmol/g. Selektivität ist dimensionslos.
95-%-Intervalle beschreiben die Streuung unabhängiger Seed-Mittelwerte. Komponenten: Student-t; Selektivität: Fieller mit gepaarten Seeds.
Das Präzisionskriterium ist kein Nachweis der Equilibrierung. Unbeschränkte/undefinierte Intervalle erfüllen es nicht.

Präzisionsziel: relative Intervallhalbbreite ≤ 20 %, mindestens 3 Seeds.

| Druck / bar | Größe | Wert | Einheit | 95-%-Intervall | relative Halbbreite | Intervallstatus | Präzisionsziel (Größe) | Präzisionsziel (Punkt) |
|---:|:---|---:|:---|:---|---:|:---|:---|:---|
| 0.1 | CO2 | 0.0129287 | mol/kg | [0.0112142, 0.0146431] | 13.26 % | bounded | ja | ja |
| 0.1 | N2 | 0.0179865 | mol/kg | [0.0164735, 0.0194995] | 8.41 % | bounded | ja | ja |
| 0.1 | total | 0.0309152 | mol/kg | [0.0282714, 0.033559] | 8.55 % | bounded | — | ja |
| 0.1 | CO2/N2 | 4.07318 | dimensionless | [3.55215, 4.6212] | 13.12 % | bounded | ja | ja |
| 0.1 | N2/CO2 | 0.245508 | dimensionless | [0.216394, 0.281519] | 13.26 % | bounded | ja | ja |

## Referenzprüfung

Reingasisothermen werden nicht als Gemischreferenz verwendet. Unbekannte Adsorptionsbasis wird nicht als absolut interpretiert.


Ein bisheriger Vergleich von CO₂+N₂-Gesamtbeladung mit reinem CO₂ ist ungültig; daraus abgeleitete Fehlerprozente sind kein Validierungsergebnis.
