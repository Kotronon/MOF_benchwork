# Module B campaign

Training states: 0; independent holdouts: 0.

Quantitative external reference validation remains open.

Seed intervals measure statistical precision, not proof of equilibrium. GP bands describe latent surrogate uncertainty.

Higher-dimensional figures are projections, not complete adsorption surfaces.

See observations.csv, surrogate_predictions.csv and validation_report.json for reproducible values.

Campaign kind: production.

Conservative raw-log intervals add between-seed and autocorrelation batch variances and may double-count sampling noise. They do not establish equilibrium. Classic seed intervals are retained in uncertainties.csv and campaign.json.

Pure-gas boundaries have undefined selectivity; only present-component precision is tested there. Constant traces at positive fugacity fail precision and use a documented 0.05 molecule GP noise floor.

Holdouts failing precision: 0/0. Holdout labels never influence training, acquisition or stopping.
