# Module B: korrigierte Gemisch-Auswertung

**Pilot ausgewertet; quantitative Referenzvalidierung offen**

Quelle: `outputs/module_B_active_learning/production/zif8/simulation/runs/al_00000_b68232eb77a9e17a085e/isotherm_summary.json`

Framework-Masse: 21847.296000000002 u. Herkunft: `outputs/module_B_active_learning/production/zif8/simulation/runs/al_00000_b68232eb77a9e17a085e/data/ZIF-8.data`.

Komponenten und Gesamtbeladung sind absolute Adsorption; mol/kg = mmol/g. Selektivität ist dimensionslos.
95-%-Intervalle beschreiben die Streuung unabhängiger Seed-Mittelwerte. Komponenten: Student-t; Selektivität: Fieller mit gepaarten Seeds.
Das Präzisionskriterium ist kein Nachweis der Equilibrierung. Unbeschränkte/undefinierte Intervalle erfüllen es nicht.

Präzisionsziel: relative Intervallhalbbreite ≤ 20 %, mindestens 3 Seeds.

| Druck / bar | Größe | Wert | Einheit | 95-%-Intervall | relative Halbbreite | Intervallstatus | Präzisionsziel (Größe) | Präzisionsziel (Punkt) |
|---:|:---|---:|:---|:---|---:|:---|:---|:---|
| 0.1 | CO2 | 0 | mol/kg | [0, 0] | — | bounded | nein | ja |
| 0.1 | N2 | 0.0252768 | mol/kg | [0.0225499, 0.0280036] | 10.79 % | bounded | ja | ja |
| 0.1 | total | 0.0252768 | mol/kg | [0.0225499, 0.0280036] | 10.79 % | bounded | — | ja |
| 0.1 | CO2/N2 | — | dimensionless | — | — | undefined_gas_fraction | nein | ja |
| 0.1 | N2/CO2 | — | dimensionless | — | — | undefined_gas_fraction | nein | ja |

## Referenzprüfung

Reingasisothermen werden nicht als Gemischreferenz verwendet. Unbekannte Adsorptionsbasis wird nicht als absolut interpretiert.


Ein bisheriger Vergleich von CO₂+N₂-Gesamtbeladung mit reinem CO₂ ist ungültig; daraus abgeleitete Fehlerprozente sind kein Validierungsergebnis.
