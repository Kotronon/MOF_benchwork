"""MACE fine-tuning preparation and validation helpers."""

from __future__ import annotations

import json
import math
import logging
import re
import threading
import time
import zipfile
from pathlib import Path
import subprocess
from typing import Any, Sequence

import numpy as np

from modules.module_c_mlips.potential_backends.calculators import build_ase_calculator
from pipeline.config import save_benchmark_data


def split_multisystem_labels(
    labels: Sequence[dict[str, Any]],
    *,
    unseen_materials: set[str],
    unseen_gas_compositions: set[str],
    validation_materials: set[str] | None = None,
    validation_gas_compositions: set[str] | None = None,
) -> dict[str, list[str]]:
    """Split labeled configurations by framework and normalized gas mixture.

    ``gas_composition`` may be a species string or a species-to-fraction
    mapping. Mixture fractions are normalized, so equivalent ratios have the
    same key. Train, validation, and test IDs are disjoint; the two additional
    test lists preserve the unseen-framework and unseen-mixture slices, which
    may overlap each other.
    """
    validation_materials = validation_materials or set()
    validation_gas_compositions = validation_gas_compositions or set()
    overlap_materials = unseen_materials & validation_materials
    overlap_compositions = unseen_gas_compositions & validation_gas_compositions
    if overlap_materials or overlap_compositions:
        raise ValueError(
            "Validation and test holdouts must be disjoint: "
            f"materials={sorted(overlap_materials)}, "
            f"gas_compositions={sorted(overlap_compositions)}"
        )

    unseen_mof_ids: list[str] = []
    unseen_mixture_ids: list[str] = []
    validation_ids: list[str] = []
    training_ids: list[str] = []
    seen_ids: set[str] = set()
    for label in labels:
        candidate_id = str(label["candidate_id"])
        if candidate_id in seen_ids:
            raise ValueError(f"Duplicate multi-system label ID: {candidate_id}.")
        seen_ids.add(candidate_id)
        material = str(label.get("material", label.get("material_id", ""))).strip()
        if not material:
            raise ValueError(f"Label {candidate_id} is missing material metadata.")
        composition = _gas_composition_key(
            label.get("gas_composition", label.get("mixture", label.get("adsorbate"))),
            candidate_id,
        )
        is_unseen_material = material in unseen_materials
        is_unseen_mixture = composition in unseen_gas_compositions
        if is_unseen_material:
            unseen_mof_ids.append(candidate_id)
        if is_unseen_mixture:
            unseen_mixture_ids.append(candidate_id)
        if is_unseen_material or is_unseen_mixture:
            continue
        if (
            material in validation_materials
            or composition in validation_gas_compositions
        ):
            validation_ids.append(candidate_id)
        else:
            training_ids.append(candidate_id)

    if not training_ids or not validation_ids:
        raise ValueError(
            "Multi-system grouped splitting requires non-empty training and "
            "validation sets."
        )
    if unseen_materials and not unseen_mof_ids:
        raise ValueError("No labels found for the requested unseen materials.")
    if unseen_gas_compositions and not unseen_mixture_ids:
        raise ValueError("No labels found for the requested unseen gas compositions.")
    test_ids = sorted(set(unseen_mof_ids) | set(unseen_mixture_ids))
    if not test_ids:
        raise ValueError("At least one unseen material or gas composition is required.")
    return {
        "train": sorted(training_ids),
        "validation": sorted(validation_ids),
        "test": test_ids,
        "test_unseen_materials": sorted(unseen_mof_ids),
        "test_unseen_gas_compositions": sorted(unseen_mixture_ids),
    }


def _gas_composition_key(value: Any, candidate_id: str) -> str:
    if isinstance(value, str):
        composition = {value.strip().upper(): 1.0}
    elif isinstance(value, dict):
        composition = {
            str(species).strip().upper(): float(fraction)
            for species, fraction in value.items()
        }
    else:
        raise ValueError(f"Label {candidate_id} is missing gas-composition metadata.")
    if not composition or any(
        not species or not math.isfinite(fraction) or fraction <= 0.0
        for species, fraction in composition.items()
    ):
        raise ValueError(f"Label {candidate_id} has an invalid gas composition.")
    total = sum(composition.values())
    normalized = {
        species: fraction / total for species, fraction in composition.items()
    }
    return json.dumps(normalized, sort_keys=True, separators=(",", ":"))


def write_mace_datasets(
    labels: Sequence[dict[str, Any]],
    *,
    training_ids: set[str],
    validation_ids: set[str],
    test_ids: set[str],
    output_directory: str | Path,
) -> dict[str, str]:
    """Write disjoint MACE extxyz datasets from parsed CP2K labels."""
    overlaps = {
        "training/validation": training_ids & validation_ids,
        "training/test": training_ids & test_ids,
        "validation/test": validation_ids & test_ids,
    }
    invalid = {
        name: sorted(values) for name, values in overlaps.items() if values
    }
    if invalid:
        raise ValueError(
            "Active-learning dataset IDs overlap: " + repr(invalid)
        )
    try:
        from ase.io import read, write
    except ImportError as exc:
        raise ImportError("ASE is required to build MACE datasets.") from exc
    output = Path(output_directory)
    output.mkdir(parents=True, exist_ok=True)
    paths = {
        "train": output / "train.extxyz",
        "valid": output / "valid.extxyz",
        "test": output / "test.extxyz",
    }
    grouped = {"train": [], "valid": [], "test": []}
    for label in labels:
        candidate_id = str(label["candidate_id"])
        split = (
            "train"
            if candidate_id in training_ids
            else "valid"
            if candidate_id in validation_ids
            else "test"
            if candidate_id in test_ids
            else None
        )
        if split is None:
            continue
        atoms = read(str(label["structure_path"]))
        forces = np.asarray(label["forces_ev_per_A"], dtype=float)
        if forces.shape != (len(atoms), 3):
            raise ValueError(f"Force shape does not match {candidate_id}.")
        atoms.info["REF_energy"] = float(label["energy_ev"])
        atoms.info["candidate_id"] = candidate_id
        atoms.new_array("REF_forces", forces)
        stress = label.get("stress_GPa")
        if stress is not None:
            atoms.info["REF_stress_GPa"] = stress
        grouped[split].append(atoms)
    if any(not grouped[split] for split in ("train", "valid", "test")):
        raise ValueError(
            "Active-learning train, validation, and test datasets must all "
            "be non-empty."
        )
    for split, atoms_list in grouped.items():
        write(paths[split], atoms_list, format="extxyz")
    manifest = {
        "train": str(paths["train"]),
        "valid": str(paths["valid"]),
        "test": str(paths["test"]),
        "training_ids": sorted(training_ids),
        "validation_ids": sorted(validation_ids),
        "test_ids": sorted(test_ids),
    }
    save_benchmark_data(output / "dataset_manifest.json", manifest)
    return {key: str(value) for key, value in paths.items()}


def build_mace_finetune_commands(
    datasets: dict[str, str],
    output_directory: str | Path,
    *,
    committee_size: int,
    base_model: str,
    device: str,
    seeds: Sequence[int] | None = None,
) -> list[dict[str, Any]]:
    """Build explicit MACE commands for a reproducible committee."""
    output = Path(output_directory)
    output.mkdir(parents=True, exist_ok=True)
    effective_seeds = list(seeds or (12345, 23456, 34567))
    if len(effective_seeds) < committee_size:
        raise ValueError("Not enough unique seeds for the MACE committee.")
    commands = []
    foundation = "small" if base_model == "mace_mp_0a_small" else base_model
    for index in range(committee_size):
        name = f"mace_adsorption_committee_{index}"
        member_dir = output / name
        model_dir = member_dir / "models"
        command = [
            "mace_run_train",
            "--name", name,
            "--train_file", datasets["train"],
            "--valid_file", datasets["valid"],
            "--foundation_model", foundation,
            "--restart_latest",
            "--save_all_checkpoints",
            "--eval_interval", "1",
            "--multiheads_finetuning", "False",
            "--batch_size", "1",
            "--valid_batch_size", "1",
            "--energy_key", "REF_energy",
            "--forces_key", "REF_forces",
            "--E0s", "average",
            "--default_dtype", "float64",
            "--device", device,
            "--seed", str(effective_seeds[index]),
            "--model_dir", str(model_dir),
            "--checkpoints_dir", str(member_dir / "checkpoints"),
            "--results_dir", str(member_dir / "results"),
            "--log_dir", str(member_dir / "logs"),
        ]
        commands.append(
            {
                "member": index,
                "seed": effective_seeds[index],
                "command": command,
                "working_directory": str(member_dir),
                "model_directory": str(model_dir),
                "status": "prepared",
            }
        )
    save_benchmark_data(output / "training_commands.json", {"commands": commands})
    return commands


def prune_mace_checkpoints(directory: str | Path, *, keep: int = 3) -> int:
    """Keep recent restart states and best validation states, per run and stage."""
    if keep < 2:
        raise ValueError("Keep at least two restart checkpoints.")
    directory = Path(directory)
    groups: dict[tuple[str, str], list[tuple[int, Path]]] = {}
    for path in directory.glob("*.pt"):
        match = re.fullmatch(r"(.+)_epoch-(\d+)(_swa)?\.pt", path.name)
        if match:
            groups.setdefault((match[1], match[3] or ""), []).append((int(match[2]), path))
    removed = 0
    for (tag, stage), checkpoints in groups.items():
        checkpoints.sort(reverse=True)
        if len(checkpoints) <= keep:
            continue
        # Only prune behind several complete, settled files. Never delete a file
        # while MACE is writing it, or remove fallback states behind a corrupt save.
        recent = [(epoch, path) for epoch, path in checkpoints
                  if time.time() - path.stat().st_mtime >= 60][:keep]
        if len(recent) < keep:
            continue
        try:
            for _, path in recent:
                if time.time() - path.stat().st_mtime < 60:
                    break
                with zipfile.ZipFile(path) as archive:
                    if archive.testzip() is not None:
                        break
            else:
                preserved = {path for _, path in recent}
                log = directory.parent / "logs" / f"{tag}.log"
                if not log.exists():
                    continue  # Cannot identify the best validation state safely.
                losses = []
                for line in log.read_text(errors="replace").splitlines():
                    match = re.search(r"Epoch (\d+):.*loss=([\d.eE+-]+)", line)
                    if match:
                        losses.append((float(match[2]), int(match[1])))
                available = {epoch: path for epoch, path in checkpoints}
                best = [(loss, epoch) for loss, epoch in losses if epoch in available]
                if best:
                    preserved.add(available[min(best)[1]])
                for _, path in checkpoints:
                    if path not in preserved and time.time() - path.stat().st_mtime >= 60:
                        path.unlink()
                        removed += 1
        except (OSError, zipfile.BadZipFile):
            logging.exception("Checkpoint cleanup skipped for %s", directory)
    return removed


def _checkpoint_cleanup_loop(directory: Path, stopped: threading.Event) -> None:
    while not stopped.is_set():
        try:
            prune_mace_checkpoints(directory)
        except Exception:
            logging.exception("Checkpoint cleanup failed for %s", directory)
        stopped.wait(60)


def execute_mace_commands(commands: Sequence[dict[str, Any]]) -> list[dict[str, Any]]:
    results = []
    for entry in commands:
        current = dict(entry)
        # Older prepared manifests must resume checkpoints too.
        current["command"] = list(entry["command"])
        for flag in ("--restart_latest", "--save_all_checkpoints"):
            if flag not in current["command"]:
                current["command"].append(flag)
        if "--eval_interval" in current["command"]:
            current["command"][current["command"].index("--eval_interval") + 1] = "1"
        else:
            current["command"].extend(["--eval_interval", "1"])
        workdir = Path(current["working_directory"])
        workdir.mkdir(parents=True, exist_ok=True)
        stopped = threading.Event()
        checkpoint_directory = workdir / "checkpoints"
        if "--checkpoints_dir" in current["command"]:
            checkpoint_directory = Path(current["command"][current["command"].index("--checkpoints_dir") + 1])
        cleaner = threading.Thread(
            target=_checkpoint_cleanup_loop, args=(checkpoint_directory, stopped), daemon=True,
        )
        cleaner.start()
        try:
            completed = subprocess.run(current["command"], capture_output=True, text=True)
        finally:
            stopped.set()
            cleaner.join()
            prune_mace_checkpoints(checkpoint_directory)
        current["returncode"] = completed.returncode
        current["status"] = "completed" if completed.returncode == 0 else "failed"
        log_path = workdir / "training.log"
        log_path.write_text(completed.stdout + "\n" + completed.stderr, encoding="utf-8")
        current["log_path"] = str(log_path)
        models = sorted(Path(current["model_directory"]).glob("*.model"))
        current["model_path"] = str(models[-1]) if models else None
        if completed.returncode != 0 or not models:
            raise RuntimeError(f"MACE fine-tuning failed; see {log_path}.")
        results.append(current)
    return results


def classify_validation_metrics(
    metrics: dict[str, float],
    settings: Any,
) -> dict[str, Any]:
    energy = float(metrics["energy_mae_ev"])
    force = float(metrics["force_mae_ev_per_A"])
    disagreement_energy = float(metrics.get("maximum_committee_energy_std_ev", 0.0))
    disagreement_force = float(metrics.get("maximum_committee_force_std_ev_per_A", 0.0))
    passed = (
        energy <= settings.energy_pass_mae_ev
        and force <= settings.force_pass_mae_ev_per_A
        and disagreement_energy <= settings.energy_pass_mae_ev
        and disagreement_force <= settings.force_pass_mae_ev_per_A
    )
    warning = (
        energy <= settings.energy_warning_mae_ev
        and force <= settings.force_warning_mae_ev_per_A
    )
    return {
        "status": "passed" if passed else "warning" if warning else "failed",
        "metrics": metrics,
        "thresholds": {
            "energy_pass_mae_ev": settings.energy_pass_mae_ev,
            "force_pass_mae_ev_per_A": settings.force_pass_mae_ev_per_A,
            "energy_warning_mae_ev": settings.energy_warning_mae_ev,
            "force_warning_mae_ev_per_A": settings.force_warning_mae_ev_per_A,
        },
    }


def evaluate_mace_committee(
    model_paths: Sequence[str],
    labels: Sequence[dict[str, Any]],
    *,
    test_ids: set[str],
    device: str = "cpu",
) -> dict[str, Any]:
    """Evaluate a MACE committee on the permanently held-out DFT split."""
    if not model_paths:
        raise ValueError("No committee models were provided.")
    try:
        from ase.io import read
    except ImportError as exc:
        raise ImportError("ASE is required for committee validation.") from exc

    calculators = [
        build_ase_calculator(
            {
                "backend": "mace-torch",
                "model": str(path),
                "device": device,
                "default_dtype": "float64",
                "dispersion": False,
            }
        )
        for path in model_paths
    ]
    energy_errors = []
    force_errors = []
    energy_stds = []
    force_stds = []
    member_energy_errors: list[list[float]] = [
        [] for _ in calculators
    ]
    member_force_errors: list[list[float]] = [
        [] for _ in calculators
    ]
    evaluated = 0
    for label in labels:
        if str(label["candidate_id"]) not in test_ids:
            continue
        atoms = read(str(label["structure_path"]))
        energies = []
        forces = []
        for calculator in calculators:
            current = atoms.copy()
            current.calc = calculator
            energies.append(float(current.get_potential_energy()))
            forces.append(np.asarray(current.get_forces(), dtype=float))
        reference_forces = np.asarray(label["forces_ev_per_A"], dtype=float)
        mean_forces = np.mean(np.asarray(forces), axis=0)
        energy_errors.append(abs(float(np.mean(energies)) - float(label["energy_ev"])))
        force_errors.extend(np.linalg.norm(mean_forces - reference_forces, axis=1).tolist())
        for index, (energy, predicted_forces) in enumerate(
            zip(energies, forces, strict=True)
        ):
            member_energy_errors[index].append(
                abs(float(energy) - float(label["energy_ev"]))
            )
            member_force_errors[index].extend(
                np.linalg.norm(
                    predicted_forces - reference_forces,
                    axis=1,
                ).tolist()
            )
        energy_stds.append(float(np.std(energies, ddof=0)))
        force_stds.append(
            float(np.max(np.linalg.norm(np.std(np.asarray(forces), axis=0), axis=1)))
        )
        evaluated += 1
    if evaluated != len(test_ids):
        raise ValueError(
            f"Committee validation found {evaluated} of {len(test_ids)} test labels."
        )
    members = [
        {
            "member": index,
            "model_path": str(model_paths[index]),
            "energy_mae_ev": float(np.mean(member_energy_errors[index])),
            "force_mae_ev_per_A": float(np.mean(member_force_errors[index])),
        }
        for index in range(len(model_paths))
    ]
    best = min(
        members,
        key=lambda item: (
            item["energy_mae_ev"] / 0.043
            + item["force_mae_ev_per_A"] / 0.10
        ),
    )
    return {
        "test_configuration_count": float(evaluated),
        "energy_mae_ev": float(np.mean(energy_errors)),
        "force_mae_ev_per_A": float(np.mean(force_errors)),
        "maximum_committee_energy_std_ev": float(max(energy_stds, default=0.0)),
        "maximum_committee_force_std_ev_per_A": float(max(force_stds, default=0.0)),
        "committee_members": members,
        "best_model_index": int(best["member"]),
    }


def select_committee_candidates(
    candidates: Sequence[dict[str, Any]],
    model_paths: Sequence[str],
    *,
    count: int,
    device: str = "cpu",
) -> list[dict[str, Any]]:
    """Select uncertain and structurally diverse candidates for DFT labeling."""
    if count <= 0 or count > len(candidates):
        raise ValueError("Candidate selection count is outside the available pool.")
    try:
        from ase.io import read
    except ImportError as exc:
        raise ImportError("ASE is required for committee selection.") from exc
    calculators = [
        build_ase_calculator(
            {
                "backend": "mace-torch",
                "model": str(path),
                "device": device,
                "default_dtype": "float64",
                "dispersion": False,
            }
        )
        for path in model_paths
    ]
    scored = []
    for candidate in candidates:
        atoms = read(str(candidate["structure_path"]))
        energies = []
        forces = []
        for calculator in calculators:
            current = atoms.copy()
            current.calc = calculator
            energies.append(float(current.get_potential_energy()))
            forces.append(np.asarray(current.get_forces(), dtype=float))
        energy_std = float(np.std(energies, ddof=0))
        force_std = float(
            np.max(np.linalg.norm(np.std(np.asarray(forces), axis=0), axis=1))
        )
        descriptor = _selection_descriptor(atoms)
        scored.append((candidate, energy_std, force_std, descriptor))

    uncertainties = np.asarray(
        [energy + force for _, energy, force, _ in scored], dtype=float
    )
    scale = float(np.ptp(uncertainties))
    normalized = (
        np.ones_like(uncertainties)
        if scale <= 1.0e-15
        else (uncertainties - float(np.min(uncertainties))) / scale
    )
    selected: list[int] = [int(np.argmax(normalized))]
    descriptors = np.asarray([item[3] for item in scored], dtype=float)
    while len(selected) < count:
        distances = np.min(
            np.linalg.norm(descriptors[:, None, :] - descriptors[selected][None, :, :], axis=2),
            axis=1,
        )
        distance_scale = float(np.max(distances))
        if distance_scale > 0.0:
            distances /= distance_scale
        objective = 0.7 * normalized + 0.3 * distances
        objective[selected] = -1.0
        selected.append(int(np.argmax(objective)))

    result = []
    for index in selected:
        candidate, energy_std, force_std, _ = scored[index]
        result.append(
            {
                **candidate,
                "selection": {
                    "committee_energy_std_ev": energy_std,
                    "committee_force_std_ev_per_A": force_std,
                    "strategy": "committee_disagreement_plus_diversity",
                },
            }
        )
    return result


def load_labels(label_root: str | Path) -> list[dict[str, Any]]:
    labels = []
    for path in sorted(Path(label_root).glob("iteration_*/cp2k/*/label.json")):
        labels.append(json.loads(path.read_text(encoding="utf-8")))
    return labels


def _selection_descriptor(atoms: Any) -> np.ndarray:
    distances = atoms.get_all_distances(mic=True)
    upper = distances[np.triu_indices(len(atoms), 1)]
    histogram, _ = np.histogram(upper, bins=24, range=(0.0, 12.0))
    descriptor = histogram.astype(float)
    if descriptor.sum() > 0:
        descriptor /= descriptor.sum()
    return np.concatenate(
        [descriptor, [len(atoms) / 1000.0, atoms.get_volume() / max(len(atoms), 1)]]
    )
