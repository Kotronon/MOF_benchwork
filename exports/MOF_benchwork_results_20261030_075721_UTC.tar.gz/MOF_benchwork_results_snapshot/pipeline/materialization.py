from __future__ import annotations

from dataclasses import replace
import hashlib
import math
from pathlib import Path
from typing import Any

from converter.cif_to_lammps_data import convert_cif_to_lammps_data, load_framework_structure
from converter.forcefield_to_lammps import (
    build_lammps_forcefield,
    load_forcefield_parameters,
    write_lammps_forcefield_include,
)
from converter.molecule_to_lammps_template import build_molecule_template, parse_crafted_molecule_def
from pipeline.config import save_benchmark_data
from pipeline.eos import fugacity_coeff_coolprop, mixture_fugacities
from pipeline.lammps_inputs import gcmc_input_builder, render_run0_input
from pipeline.utils import unique


def materialize_benchmark(prepare_plan: dict[str, Any]) -> dict[str, Any]:
    """Materialize a prepare plan into generated benchmark files on disk."""
    working_dir = Path(prepare_plan["working_directory"])
    resume = bool(prepare_plan.get("resume", False))
    if working_dir.exists() and not prepare_plan.get("overwrite", True) and not resume:
        raise FileExistsError(
            f"Working directory already exists: {working_dir}. "
            "Use a new output.run_id, enable output.overwrite, or run with --resume."
        )
    existing_summary = working_dir / "prepare_summary.json"
    if resume and existing_summary.exists():
        import json
        previous = json.loads(existing_summary.read_text())
        old = previous["prepare_plan"]
        if old["parameters"] != prepare_plan["parameters"] or old["inputs"] != prepare_plan["inputs"]:
            raise ValueError("Cannot resume with a changed physical setup or sampling parameters; use a new run_id.")
        def verify_sources(original, archived):
            if isinstance(original, dict) and isinstance(archived, dict):
                for key in original.keys() & archived.keys():
                    verify_sources(original[key], archived[key])
            elif isinstance(original, list) and isinstance(archived, list):
                for left,right in zip(original,archived):
                    verify_sources(left,right)
            elif isinstance(original, str) and isinstance(archived, str) and Path(archived).is_file():
                if not Path(original).is_file() or Path(original).read_bytes() != Path(archived).read_bytes():
                    raise ValueError("Cannot resume: original input assets changed.")
        archived_sources = previous.get("result", {}).get("files", {}).get("source_files", {})
        verify_sources(prepare_plan["inputs"], archived_sources)
        verify_sources(prepare_plan["parameters"].get("guest_models", {}), archived_sources.get("guest_models", {}))
        for asset, digest in previous.get("result", {}).get("files", {}).get("source_sha256", {}).items():
            if not Path(asset).is_file() or hashlib.sha256(Path(asset).read_bytes()).hexdigest() != digest:
                raise ValueError("Cannot resume: archived inputs changed.")
    working_dir.mkdir(parents=True, exist_ok=True)

    for directory in [
        "data",
        "forcefield",
        "inputs",
        "logs",
        "molecules",
        "source",
        "source/forcefield",
        "source/molecules",
        "source/references",
        "dumps",
        "restarts",
    ]:
        (working_dir / directory).mkdir(parents=True, exist_ok=True)

    source_files = _copy_prepare_sources(prepare_plan, working_dir / "source")
    forcefield_config = prepare_plan["planned_files"]["forcefield_include"]["forcefield_config"]
    parameters = load_forcefield_parameters(forcefield_config)
    framework_structure = load_framework_structure(
        prepare_plan["inputs"]["framework_cif"],
        cell_representation=prepare_plan["parameters"].get("cell_representation", "source"),
        unit_cells=prepare_plan["parameters"].get("unit_cells", [1, 1, 1]),
        cutoff_A=prepare_plan["parameters"].get("cutoff_A"),
        minimum_image_policy=prepare_plan["parameters"].get("minimum_image_policy", "error"),
    )
    framework_symbols = unique(framework_structure.symbols)

    molecule_definitions = prepare_plan["inputs"]["adsorbate_definitions"]
    molecules = {
        component: parse_crafted_molecule_def(molecule_def_path)
        for component, molecule_def_path in molecule_definitions.items()
    }
    guest_models = prepare_plan["parameters"].get("guest_models", {})
    if guest_models:
        from engines.flexible_guest_runner import load_models
        checked_models = load_models(guest_models, prepare_plan["parameters"]["temperature_K"])
        if set(guest_models) - set(molecules):
            raise ValueError("Guest model names do not match configured components.")
        for c, model in checked_models.items():
            if len(model["growth_parents"]) != len(molecules[c].atoms):
                raise ValueError("Guest topology atom count differs from molecule definition.")
    if any(not molecule.rigid and len(molecule.atoms) > 1 and c not in guest_models for c,molecule in molecules.items()):
        raise ValueError("Flexible .def files need an explicit CBMC guest model; rigid-template conversion would discard their topology.")
    # Isolate component types even when two gases use identical LJ pseudoatoms.
    type_maps = {c: {a.atom_type: (f"{c}__{a.atom_type}" if len(molecules) > 1 else a.atom_type)
                    for a in m.atoms} for c, m in molecules.items()}
    for c, mapping in type_maps.items():
        for original, label in mapping.items():
            parameters.lj_parameters[label] = replace(parameters.lj_parameters[original], name=label)
            parameters.pseudo_atoms[label] = replace(parameters.pseudo_atoms[original], name=label)
    original_molecules = molecules
    molecules = {c: replace(m, atoms=tuple(replace(a, atom_type=type_maps[c][a.atom_type]) for a in m.atoms))
                 for c, m in molecules.items()}
    adsorbate_atom_types = [
        atom.atom_type
        for molecule in molecules.values()
        for atom in molecule.atoms
    ]
    forcefield = build_lammps_forcefield(
        framework_symbols=framework_symbols,
        adsorbate_atom_types=adsorbate_atom_types,
        parameters=parameters,
        pair_style=(
            f"{prepare_plan['parameters'].get('pair_style', 'lj/cut/coul/long')} "
            f"{float(prepare_plan['parameters'].get('cutoff_A', 12.0)):g}"
        ),
        kspace_style=(
            f"{prepare_plan['parameters'].get('kspace_style', 'pppm')} "
            f"{float(prepare_plan['parameters'].get('kspace_accuracy', 1e-5)):g}"
        ),
        pair_modify_shift=bool(prepare_plan["parameters"].get("pair_modify_shift", False)),
    )
    framework_atom_type_ids = [
        atom_type.type_id
        for atom_type in forcefield.atom_types
        if atom_type.source == "framework"
    ]
    adsorbate_atom_type_ids = [
        atom_type.type_id
        for atom_type in forcefield.atom_types
        if atom_type.source == "adsorbate"
    ]
    extra_atom_masses = {
        atom_type.label: atom_type.mass
        for atom_type in forcefield.atom_types
        if atom_type.source == "adsorbate" and atom_type.mass is not None
    }
    atom_type_ids = {atom_type.label: atom_type.type_id for atom_type in forcefield.atom_types}
    component_adsorbate_atom_type_ids = {
        component: [
            atom_type_ids[atom_type]
            for atom_type in unique(atom.atom_type for atom in molecule.atoms)
        ]
        for component, molecule in molecules.items()
    }
    component_atoms_per_molecule = {
        component: len(molecule.atoms)
        for component, molecule in molecules.items()
    }
    atom_charges = {
        atom_type.label: atom_type.charge
        for atom_type in forcefield.atom_types
        if atom_type.source == "adsorbate" and atom_type.charge is not None
    }
    extra_bond_types = _count_unique_bond_types(molecules.values())
    extra_special_per_atom = _max_special_neighbors(molecules.values())

    framework_data_path = Path(prepare_plan["planned_files"]["framework_data"]["output_data"])
    convert_cif_to_lammps_data(
        prepare_plan["inputs"]["framework_cif"],
        framework_data_path,
        atom_style=prepare_plan["planned_files"]["framework_data"].get("atom_style", "full"),
        extra_atom_types=extra_atom_masses,
        extra_bond_types=extra_bond_types,
        cell_representation=prepare_plan["parameters"].get("cell_representation", "source"),
        unit_cells=prepare_plan["parameters"].get("unit_cells", [1, 1, 1]),
        cutoff_A=prepare_plan["parameters"].get("cutoff_A"),
        minimum_image_policy=prepare_plan["parameters"].get("minimum_image_policy", "error"),
    )

    molecule_template_paths = {}
    for component, molecule_plan in prepare_plan["planned_files"]["molecule_templates"].items():
        template_path = Path(molecule_plan["output_template"])
        build_molecule_template(
            molecule_plan["input_definition"],
            template_path,
            atom_type_ids={a: atom_type_ids[b] for a,b in type_maps[component].items()},
            atom_charges={a: atom_charges[b] for a,b in type_maps[component].items()},
        )
        molecule_template_paths[component] = str(template_path)

    forcefield_path = Path(prepare_plan["planned_files"]["forcefield_include"]["output_file"])
    write_lammps_forcefield_include(forcefield, forcefield_path)
    if (not any(framework_structure.charges)
            and prepare_plan["parameters"].get("kspace_style", "pppm") == "pppm"):
        # Empty, uncharged frameworks cannot supply PPPM's automatic error
        # estimate. Keep electrostatics enabled for subsequently inserted guests.
        accuracy = float(prepare_plan["parameters"].get("kspace_accuracy", 1e-5))
        cutoff = float(prepare_plan["parameters"].get("cutoff_A", 12.0))
        scale = math.sqrt(-math.log(min(accuracy, 0.1)))
        alpha = scale / cutoff
        settings = f"kspace_modify gewald {alpha:.12g}"
        # Resolve reciprocal modes beyond the Gaussian damping scale;
        # powers of two provide efficient FFT grids even for dilute guests.
        # This initial grid still requires convergence checks at finite loading.
        mesh = [2 ** max(2, math.ceil(math.log2(2 * length * alpha * scale / math.pi)))
                for length in framework_structure.cell_lengths]
        settings += " mesh " + " ".join(map(str, mesh))
        with forcefield_path.open("a") as handle:
            handle.write("\n# Explicit initialization for an uncharged framework.\n" + settings + "\n")

    run0_path = Path(prepare_plan["planned_files"]["run0_input"]["path"])
    run0_path.parent.mkdir(parents=True, exist_ok=True)
    run0_path.write_text(
        render_run0_input(
            framework_data_path=framework_data_path,
            molecule_templates=molecule_template_paths,
            forcefield_path=forcefield_path,
            extra_special_per_atom=extra_special_per_atom,
            has_bonds=extra_bond_types > 0,
        ),
        encoding="utf-8",
    )

    component = next(iter(molecule_template_paths))
    gcmc_test_path = Path(prepare_plan["planned_files"]["gcmc_test_input"]["path"])
    gcmc_test_path.parent.mkdir(parents=True, exist_ok=True)
    gcmc_test_path.write_text(
        '# Flexible guests require the Python CBMC driver: benchmark.py --run-test.\nquit 1\n' if guest_models else gcmc_input_builder(
            _gcmc_builder_inputs(
                prepare_plan=prepare_plan,
                framework_data_path=framework_data_path,
                molecule_template_paths=molecule_template_paths,
                forcefield_path=forcefield_path,
                framework_atom_type_ids=framework_atom_type_ids,
                adsorbate_atom_type_ids=adsorbate_atom_type_ids,
                component_adsorbate_atom_type_ids=component_adsorbate_atom_type_ids,
                component_atoms_per_molecule=component_atoms_per_molecule,
                component=component,
                pressure_bar=prepare_plan["parameters"]["pressures_bar"][0],
                extra_special_per_atom=extra_special_per_atom,
                seed=prepare_plan["parameters"]["seeds"][0],
            )
        ),
        encoding="utf-8",
    )

    for input_script in prepare_plan["planned_files"]["input_scripts"]:
        pressure_bar = input_script["pressure_bar"]
        if prepare_plan["parameters"].get("mixture"):
            reservoir = prepare_plan["parameters"].get("reservoir", {})
            eos = mixture_fugacities(
                prepare_plan["parameters"]["temperature_K"], pressure_bar,
                prepare_plan["parameters"]["mixture"],
                {c: m.to_dict() for c,m in molecules.items()},
                binary_interactions=reservoir.get("binary_interactions"),
                root=reservoir.get("root", "vapor"),
                fugacities_bar=reservoir.get("fugacities_bar"))
            fugacity_coefficients = eos["coefficients"]
            input_script["reservoir"] = eos
            fugacity_coeff = 1.0
        else:
            fugacity_coefficients = None
            fugacity_coeff = fugacity_coeff_coolprop(
                component=component,
                temperature_K=prepare_plan["parameters"]["temperature_K"],
                pressure_bar=pressure_bar,
                backend="PR",
            )
        gcmc_input_path = Path(input_script["path"])
        gcmc_input_path.parent.mkdir(parents=True, exist_ok=True)
        builder_inputs = _gcmc_builder_inputs(
            prepare_plan=prepare_plan,
            framework_data_path=framework_data_path,
            molecule_template_paths=molecule_template_paths,
            forcefield_path=forcefield_path,
            framework_atom_type_ids=framework_atom_type_ids,
            adsorbate_atom_type_ids=adsorbate_atom_type_ids,
            component_adsorbate_atom_type_ids=component_adsorbate_atom_type_ids,
            component_atoms_per_molecule=component_atoms_per_molecule,
            component=component,
            pressure_bar=pressure_bar,
            extra_special_per_atom=extra_special_per_atom,
            seed=input_script["seed"],
            fugacity_coeff=fugacity_coeff,
            fugacity_coefficients=fugacity_coefficients,
            dump_file=input_script.get("dump"),
            dump_every_steps=prepare_plan["parameters"].get("dump_every_steps", 1000),
            restart_file=input_script.get("restart"),
            restart_every_steps=prepare_plan["parameters"].get("restart_every_steps", 50000),
        )
        input_script.update(builder_inputs)
        if guest_models:
            input_script.update(sampler="cbmc", guest_models=guest_models, resume=resume,
                cbmc_trials=int(prepare_plan["parameters"].get("sampling", {}).get("trials", 8)),
                hmc=prepare_plan["parameters"].get("sampling", {}).get("hmc", {}),
                guest_atoms={c: [{"type":atom_type_ids[a.atom_type], "charge":atom_charges[a.atom_type],
                                  "position":[a.x,a.y,a.z]} for a in m.atoms] for c,m in molecules.items()})
        gcmc_input_path.write_text(
            '# Flexible guests require the Python CBMC driver: benchmark.py --run-isotherm.\nquit 1\n' if guest_models else gcmc_input_builder(builder_inputs),
            encoding="utf-8",
        )

    result = {
        "status": "materialized",
        "working_directory": str(working_dir),
        "parameters": {
            **prepare_plan["parameters"],
            "framework_atom_count": framework_structure.atom_count,
            "framework_cell_lengths_A": list(framework_structure.cell_lengths),
            "framework_cell_angles_deg": list(framework_structure.cell_angles),
            "adsorbate_atoms_per_molecule": len(molecules[component].atoms),
            "component_atoms_per_molecule": component_atoms_per_molecule,
            "mixture": prepare_plan["parameters"].get("mixture"),
        },
        "evaluation": prepare_plan.get("evaluation", {}),
        "applicability": prepare_plan.get("applicability", {}),
        "convergence": prepare_plan.get("convergence", {}),
        "resume": resume,
        "files": {
            "framework_data": str(framework_data_path),
            "forcefield_include": str(forcefield_path),
            "molecule_templates": molecule_template_paths,
            "run0_input": str(run0_path),
            "gcmc_test_input": str(gcmc_test_path),
            "summary": prepare_plan["planned_files"]["summary"],
            "source_files": source_files,
            "source_sha256": {str(p): hashlib.sha256(p.read_bytes()).hexdigest() for p in (working_dir / "source").rglob("*") if p.is_file()},
            "gcmc_inputs": [script["path"] for script in prepare_plan["planned_files"]["input_scripts"]],
            "gcmc_runs": prepare_plan["planned_files"]["input_scripts"],
            "dump_files": [
                script["dump"]
                for script in prepare_plan["planned_files"]["input_scripts"]
                if script.get("dump") is not None
            ],
            "restart_files": [
                script["restart"]
                for script in prepare_plan["planned_files"]["input_scripts"]
                if script.get("restart") is not None
            ],
        },
    }
    save_benchmark_data(prepare_plan["planned_files"]["summary"], {"prepare_plan": prepare_plan, "result": result})
    return result


def _gcmc_builder_inputs(
    *,
    prepare_plan: dict[str, Any],
    framework_data_path: Path,
    molecule_template_paths: dict[str, str],
    forcefield_path: Path,
    framework_atom_type_ids: list[int],
    adsorbate_atom_type_ids: list[int],
    component_adsorbate_atom_type_ids: dict[str, list[int]],
    component_atoms_per_molecule: dict[str, int],
    component: str,
    pressure_bar: float,
    extra_special_per_atom: int,
    seed: int,
    fugacity_coeff: float = 1.0,
    fugacity_coefficients: dict[str, float] | None = None,
    dump_file: str | None = None,
    dump_every_steps: int = 1000,
    restart_file: str | None = None,
    restart_every_steps: int = 0,
    read_restart_file: str | None = None,
) -> dict[str, Any]:
    return {
        "framework_data": str(framework_data_path),
        "molecule_templates": molecule_template_paths,
        "forcefield_include": str(forcefield_path),
        "framework_atom_types": framework_atom_type_ids,
        "adsorbate_atom_types": adsorbate_atom_type_ids,
        "component_adsorbate_atom_types": component_adsorbate_atom_type_ids,
        "component_atoms_per_molecule": component_atoms_per_molecule,
        "components": prepare_plan["parameters"]["components"],
        "mixture": prepare_plan["parameters"].get("mixture"),
        "component": component,
        "temperature_K": prepare_plan["parameters"]["temperature_K"],
        "pressure_bar": pressure_bar,
        "chemical_potential_kcal_mol": 0.0,
        "displacement_A": 1.0,
        "run_steps": prepare_plan["parameters"].get("run_steps", 10000),
        "thermo_every_steps": prepare_plan["parameters"].get("thermo_every_steps", 100),
        "gcmc_every_steps": 1,
        "exchange_attempts": 10,
        "move_attempts": 10,
        "seed": seed,
        "extra_bond_per_atom": extra_special_per_atom,
        "extra_special_per_atom": extra_special_per_atom,
        "fugacity_coeff": fugacity_coeff,
        "fugacity_coefficients": fugacity_coefficients or {},
        "dump_file": dump_file,
        "dump_every_steps": dump_every_steps,
        "restart_file": restart_file,
        "restart_every_steps": restart_every_steps,
        "read_restart_file": read_restart_file,
    }


def _copy_prepare_sources(prepare_plan: dict[str, Any], source_dir: Path) -> dict[str, Any]:
    copied: dict[str, Any] = {}
    copied["framework_cif"] = str(_copy_file(Path(prepare_plan["inputs"]["framework_cif"]), source_dir))
    copied["forcefield_files"] = {
        name: str(_copy_file(Path(path), source_dir / "forcefield"))
        for name, path in prepare_plan["inputs"]["forcefield_files"].items()
    }
    copied["adsorbate_parameter_files"] = [
        {
            "source": source.get("source", "unknown"),
            "atom_types": source.get("atom_types"),
            "components": source.get("components"),
            "files": {
                name: str(_copy_file(Path(path), source_dir / "forcefield" / f"adsorbate_{index}"))
                for name, path in source.get("files", {}).items()
            },
        }
        for index, source in enumerate(prepare_plan["inputs"].get("adsorbate_parameter_files", []))
    ]
    copied["adsorbate_definitions"] = {
        component: str(_copy_file(Path(path), source_dir / "molecules" / component))
        for component, path in prepare_plan["inputs"]["adsorbate_definitions"].items()
    }
    copied["guest_models"] = {
        c: str(_copy_file(Path(path), source_dir / "models" / c))
        for c,path in prepare_plan["parameters"].get("guest_models", {}).items() if isinstance(path,str)
    }
    copied["reference_files"] = [
        {
            **reference,
            "copied_path": str(_copy_file(Path(reference["path"]), source_dir / "references")),
        }
        for reference in prepare_plan["inputs"]["reference_files"]
    ]
    return copied


def _copy_file(source: Path, destination_dir: Path) -> Path:
    destination_dir.mkdir(parents=True, exist_ok=True)
    destination = destination_dir / source.name
    destination.write_bytes(source.read_bytes())
    return destination


def _count_unique_bond_types(molecules: Any) -> int:
    return len(unique(bond.bond_type for molecule in molecules for bond in molecule.bonds))


def _max_special_neighbors(molecules: Any) -> int:
    max_neighbors = 0
    for molecule in molecules:
        if molecule.bonds:
            max_neighbors = max(max_neighbors, len(molecule.atoms) - 1)
    return max_neighbors
