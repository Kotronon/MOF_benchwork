"""Shared benchmark pipeline components."""

