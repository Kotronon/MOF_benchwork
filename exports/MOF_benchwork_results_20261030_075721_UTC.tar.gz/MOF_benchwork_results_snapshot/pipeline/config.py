from __future__ import annotations

from copy import deepcopy
import json
import math
import re
from pathlib import Path
from typing import Any


DEFAULT_PRESSURES_BAR = [0.01, 0.05, 0.1, 0.5, 1, 5, 10]


def load_benchmark_data(file_path: str | Path) -> dict[str, Any]:
    """Load benchmark input data from a JSON file."""
    path = _resolve_input_path(file_path)
    with path.open("r", encoding="utf-8") as handle:
        data = json.load(handle)
    return data_to_dict(data)


def save_benchmark_data(file_path: str | Path, data: dict[str, Any]) -> None:
    """Save benchmark data to a JSON file."""
    with Path(file_path).open("w", encoding="utf-8") as handle:
        json.dump(data, handle, indent=2)
        handle.write("\n")


def data_to_dict(data: list[dict[str, Any]] | dict[str, Any]) -> dict[str, Any]:
    """Convert legacy list-style benchmark data to a dictionary."""
    if isinstance(data, dict):
        return data

    if isinstance(data, list):
        return {item["name"]: item for item in data if isinstance(item, dict) and "name" in item}

    raise TypeError("Benchmark data must be a dictionary or a list of dictionaries.")


def _resolve_input_path(file_path: str | Path) -> Path:
    path = Path(file_path)
    if path.exists():
        return path

    fallback = Path("input_json_files") / path.name
    if not path.is_absolute() and fallback.exists():
        return fallback

    return path


def normalize_config(raw_config: dict[str, Any]) -> dict[str, Any]:
    """Apply V1 defaults and normalize older benchmark.json shapes."""
    config = deepcopy(data_to_dict(raw_config))

    material = _require_mapping(config, "material")
    explicit_cif = material.get("cif_path") or material.get("structure_file")
    if not material.get("name") and explicit_cif:
        material["name"] = Path(str(explicit_cif)).stem
    if not material.get("name"):
        raise ValueError("'material.name' or 'material.cif_path' is required.")
    if explicit_cif:
        material["cif_path"] = str(explicit_cif)
    material.setdefault("cif_source", explicit_cif or "auto")
    material.setdefault("charge_scheme", "auto")
    material.setdefault("source", "crafted")

    adsorbates = config.setdefault("adsorbates", {})
    if not isinstance(adsorbates, dict):
        raise TypeError("'adsorbates' must be an object.")
    components = adsorbates.get("components", ["CO2"])
    if isinstance(components, str):
        components = [components]
    if not components:
        components = ["CO2"]
    adsorbates["components"] = [str(component).upper() for component in components]
    if len(set(adsorbates["components"])) != len(adsorbates["components"]) or any(not re.fullmatch(r"[A-Z][A-Z0-9_]*", c) for c in adsorbates["components"]):
        raise ValueError("Component IDs must be unique letters/digits/underscores starting with a letter.")
    adsorbates["mixture"] = _normalize_mixture(
        adsorbates.get("mixture"),
        adsorbates["components"],
    )

    conditions = config.setdefault("conditions", {})
    if not isinstance(conditions, dict):
        raise TypeError("'conditions' must be an object.")
    conditions.setdefault("temperature_K", 298.15)
    conditions.setdefault("pressures_bar", DEFAULT_PRESSURES_BAR)
    _validate_pressures(conditions["pressures_bar"])

    benchmark = config.setdefault("benchmark", {})
    if not isinstance(benchmark, dict):
        raise TypeError("'benchmark' must be an object.")
    benchmark.setdefault("task", "auto")
    benchmark.setdefault("metrics", [])
    potential_benchmark = benchmark.get("potential_benchmark")
    if potential_benchmark is not None:
        if not isinstance(potential_benchmark, dict):
            raise TypeError("'benchmark.potential_benchmark' must be an object.")
        if str(potential_benchmark.get("workflow", "")).strip().casefold() == "campaign":
            _normalize_module_c_campaign(potential_benchmark)
    benchmark.setdefault(
        "reference",
        {
            "source": "crafted",
            "material": material.get("name"),
            "adsorbate": adsorbates["components"][0],
        },
    )
    if not isinstance(benchmark["reference"], dict):
        raise TypeError("'benchmark.reference' must be an object.")
    benchmark["reference"].setdefault("temperature_tolerance_K", 2.0)
    benchmark["reference"].setdefault("max_nist_candidates", 5)
    benchmark["reference"].setdefault("preferred_sources", ["crafted", "nist_isodb"])
    benchmark["reference"].setdefault("deduplicate_nist_by_doi", True)
    benchmark["reference"].setdefault("exclude_nist_outliers", True)
    benchmark["reference"].setdefault("nist_max_loading_mol_per_kg", 60.0)
    benchmark["reference"].setdefault("nist_max_reference_ratio", 3.0)
    benchmark["reference"].setdefault("allowed_reference_basis", ["absolute", "simulation_reference", "excess"])
    benchmark["reference"].setdefault("allow_unknown_reference_basis", True)
    benchmark["reference"].setdefault("allow_excess_reference_basis", True)
    benchmark["reference"].setdefault("require_known_nist_article_source", False)

    simulation = config.setdefault("simulation", {})
    if not isinstance(simulation, dict):
        raise TypeError("'simulation' must be an object.")
    simulation["engine"] = str(simulation.get("engine", "LAMMPS")).upper()
    simulation["method"] = str(simulation.get("method", _default_method(config))).upper()
    simulation["forcefield"] = _normalize_forcefield(simulation.get("forcefield", "UFF"))
    simulation.setdefault("framework", "rigid")
    simulation.setdefault("units", "real")
    simulation.setdefault("atom_style", "full")
    simulation.setdefault("pair_style", "lj/cut/coul/long")
    pair_modify_shift = simulation.get("pair_modify_shift", False)
    if not isinstance(pair_modify_shift, bool):
        raise TypeError("'simulation.pair_modify_shift' must be a boolean.")
    simulation["pair_modify_shift"] = pair_modify_shift
    simulation.setdefault("cutoff_A", 12.0)
    simulation["kspace_style"] = str(simulation.get("kspace_style", "pppm")).strip().casefold()
    if simulation["kspace_style"] not in {"pppm", "ewald"}:
        raise ValueError("'simulation.kspace_style' must be 'pppm' or 'ewald'.")
    simulation.setdefault("kspace_accuracy", 1e-5)
    if float(simulation["kspace_accuracy"]) <= 0:
        raise ValueError("'simulation.kspace_accuracy' must be positive.")
    simulation.setdefault("unit_cells", simulation.get("supercell", "auto"))
    simulation["cell_representation"] = str(
        simulation.get("cell_representation", "source")
    ).strip().casefold()
    if simulation["cell_representation"] not in {"source", "primitive", "conventional", "auto"}:
        raise ValueError(
            "'simulation.cell_representation' must be 'source', 'primitive', "
            "'conventional', or 'auto'."
        )
    simulation["minimum_image_policy"] = str(
        simulation.get("minimum_image_policy", "error")
    ).strip().casefold()
    if simulation["minimum_image_policy"] not in {"error", "warn", "ignore"}:
        raise ValueError(
            "'simulation.minimum_image_policy' must be 'error', 'warn', or 'ignore'."
        )
    seeds = simulation.get("seeds")
    if seeds is None:
        seeds = [simulation.get("seed", 12345)]
    if not isinstance(seeds, list) or not seeds:
        raise ValueError("'simulation.seeds' must be a non-empty list of integers.")
    if any(isinstance(seed, bool) or not isinstance(seed, int) or seed <= 0 for seed in seeds):
        raise ValueError("'simulation.seeds' must contain positive integers.")
    if len(set(seeds)) != len(seeds):
        raise ValueError("'simulation.seeds' must not contain duplicates.")
    simulation["seeds"] = seeds
    simulation.pop("seed", None)

    convergence = config.setdefault("convergence", {})
    if not isinstance(convergence, dict):
        raise TypeError("'convergence' must be an object.")
    convergence.setdefault("minimum_replicates", 3)
    convergence.setdefault("relative_ci95_target", 0.2 if len(adsorbates["components"]) > 1 else 0.05)
    if int(convergence["minimum_replicates"]) < 2:
        raise ValueError("'convergence.minimum_replicates' must be at least 2.")
    if float(convergence["relative_ci95_target"]) <= 0:
        raise ValueError("'convergence.relative_ci95_target' must be positive.")

    evaluation = config.setdefault("evaluation", {})
    if not isinstance(evaluation, dict):
        raise TypeError("'evaluation' must be an object.")
    evaluation.setdefault("simulation_basis", "absolute")
    evaluation.setdefault("report_excess", True)
    evaluation.setdefault("pore_volume_cm3_g", "auto")
    evaluation.setdefault("pore_volume_source", None)
    evaluation.setdefault("pore_volume_method", None)
    evaluation.setdefault("gas_density_backend", "HEOS")
    evaluation.setdefault("reference_matching", "by_basis")

    output = config.setdefault("output", {})
    if not isinstance(output, dict):
        raise TypeError("'output' must be an object.")
    output.setdefault("directory", None)
    output.setdefault("run_id", None)
    output.setdefault("overwrite", True)
    output.setdefault("resume", False)
    output.setdefault("save_logs", True)
    output.setdefault("save_dumps", True)
    output.setdefault("dump_every_steps", 1000)
    output.setdefault("save_restarts", True)
    output.setdefault("restart_every_steps", 50000)
    output.setdefault("save_plots", True)
    output.setdefault("save_csv", True)
    if int(output["dump_every_steps"]) <= 0:
        raise ValueError("'output.dump_every_steps' must be positive.")
    if int(output["restart_every_steps"]) <= 0:
        raise ValueError("'output.restart_every_steps' must be positive.")

    return config


def _require_mapping(config: dict[str, Any], key: str) -> dict[str, Any]:
    value = config.setdefault(key, {})
    if not isinstance(value, dict):
        raise TypeError(f"'{key}' must be an object.")
    return value


def _normalize_forcefield(value: Any) -> dict[str, str]:
    if isinstance(value, str):
        return {
            "framework": value,
            "adsorbate": "auto",
            "cross_interactions": "auto",
        }
    if isinstance(value, dict):
        return {
            **deepcopy(value),
            "framework": str(value.get("framework", "UFF")),
            "adsorbate": str(value.get("adsorbate", "auto")),
            "cross_interactions": str(value.get("cross_interactions", "auto")),
        }
    raise TypeError("'simulation.forcefield' must be a string or object.")


def _normalize_mixture(value: Any, components: list[str]) -> dict[str, float] | None:
    """Normalize and validate gas-phase mole fractions for mixture runs."""
    if value is None:
        if len(components) > 1:
            raise ValueError("'adsorbates.mixture' is required when multiple components are configured.")
        return None
    if not isinstance(value, dict):
        raise TypeError("'adsorbates.mixture' must be an object mapping component names to mole fractions.")

    component_set = set(components)
    mixture = {str(component).upper(): fraction for component, fraction in value.items()}
    mixture_set = set(mixture)
    missing = sorted(component_set - mixture_set)
    extra = sorted(mixture_set - component_set)
    if missing or extra:
        details = []
        if missing:
            details.append(f"missing components: {', '.join(missing)}")
        if extra:
            details.append(f"unknown components: {', '.join(extra)}")
        raise ValueError("'adsorbates.mixture' must match adsorbates.components exactly (" + "; ".join(details) + ").")

    normalized: dict[str, float] = {}
    for component, fraction in mixture.items():
        if isinstance(fraction, bool) or not isinstance(fraction, (int, float)):
            raise ValueError(f"'adsorbates.mixture.{component}' must be a numeric mole fraction.")
        if not math.isfinite(fraction) or fraction < 0.0:
            raise ValueError(f"'adsorbates.mixture.{component}' must be finite and nonnegative.")
        normalized[component] = float(fraction)

    total = sum(normalized.values())
    if abs(total - 1.0) > 1.0e-9:
        raise ValueError("'adsorbates.mixture' mole fractions must sum to 1.0.")
    if len(components) == 1:
        only_component = components[0]
        if set(normalized) != {only_component}:
            raise ValueError("'adsorbates.mixture' must match the single configured component.")
        return None
    return normalized


def _default_method(config: dict[str, Any]) -> str:
    if "widom" in config and "gcmc" not in config:
        return "WIDOM"
    return "GCMC"


def _validate_pressures(pressures_bar: Any) -> None:
    if not isinstance(pressures_bar, list) or not pressures_bar:
        raise ValueError("'conditions.pressures_bar' must be a non-empty list.")
    for pressure in pressures_bar:
        if not isinstance(pressure, (int, float)) or pressure <= 0:
            raise ValueError("'conditions.pressures_bar' must contain positive numbers.")


def _normalize_module_c_campaign(settings: dict[str, Any]) -> None:
    """Apply stable defaults for the extensible Module C campaign workflow."""
    validation = settings.setdefault("validation", {})
    if not isinstance(validation, dict):
        raise TypeError("'benchmark.potential_benchmark.validation' must be an object.")
    validation["mode"] = str(validation.get("mode", "screening")).strip().casefold()
    if validation["mode"] not in {"reference", "screening", "active_learning"}:
        raise ValueError(
            "'benchmark.potential_benchmark.validation.mode' must be "
            "'reference', 'screening', or 'active_learning'."
        )

    settings["adsorption_engine"] = str(
        settings.get("adsorption_engine", "mlip_mc")
    ).strip().casefold().replace("-", "_")
    if settings["adsorption_engine"] not in {"mlip_mc", "flames", "lammps"}:
        raise ValueError("Unsupported Module C adsorption_engine.")
    cross_check = settings.get("cross_check_engine")
    if cross_check is not None:
        normalized_cross_check = str(cross_check).strip().casefold().replace("-", "_")
        if normalized_cross_check not in {"mlip_mc", "flames", "lammps"}:
            raise ValueError("Unsupported Module C cross_check_engine.")
        settings["cross_check_engine"] = normalized_cross_check

    active_learning = settings.setdefault("active_learning", {})
    if not isinstance(active_learning, dict):
        raise TypeError("'benchmark.potential_benchmark.active_learning' must be an object.")
    active_learning.setdefault("enabled", validation["mode"] == "active_learning")
    active_learning.setdefault("base_model", "mace_mp_0a_small")
    active_learning.setdefault("committee_size", 3)
    active_learning.setdefault("dft_labeler", "cp2k")
    active_learning.setdefault("initial_training_configurations", 30)
    active_learning.setdefault("validation_configurations", 6)
    active_learning.setdefault("test_configurations", 20)
    active_learning.setdefault("rounds", 4)
    active_learning.setdefault("configurations_per_round", 25)
    active_learning.setdefault("maximum_configurations", 150)
    active_learning.setdefault("stable_rounds_required", 2)
    active_learning.setdefault("energy_pass_mae_ev", 0.043)
    active_learning.setdefault("force_pass_mae_ev_per_A", 0.10)
    active_learning.setdefault("energy_warning_mae_ev", 0.10)
    active_learning.setdefault("force_warning_mae_ev_per_A", 0.20)
    active_learning.setdefault("candidate_fractions", {
        "framework": 0.20,
        "single_adsorbate": 0.40,
        "multiple_adsorbates": 0.40,
    })
    integer_fields = (
        "committee_size",
        "initial_training_configurations",
        "validation_configurations",
        "test_configurations",
        "rounds",
        "configurations_per_round",
        "maximum_configurations",
        "stable_rounds_required",
    )
    for field in integer_fields:
        value = active_learning[field]
        if isinstance(value, bool) or not isinstance(value, int) or value <= 0:
            raise ValueError(
                f"'benchmark.potential_benchmark.active_learning.{field}' "
                "must be a positive integer."
            )
    if (
        active_learning["validation_configurations"]
        >= active_learning["initial_training_configurations"]
    ):
        raise ValueError(
            "Active-learning validation_configurations must leave at least "
            "one fitting configuration in initial_training_configurations."
        )
    planned = (
        active_learning["initial_training_configurations"]
        + active_learning["test_configurations"]
        + active_learning["rounds"]
        * active_learning["configurations_per_round"]
    )
    if planned > active_learning["maximum_configurations"]:
        raise ValueError(
            "Active-learning initial, test, and round allocations exceed "
            "maximum_configurations."
        )
    fractions = active_learning["candidate_fractions"]
    if not isinstance(fractions, dict) or set(fractions) != {
        "framework", "single_adsorbate", "multiple_adsorbates"
    }:
        raise ValueError("Active-learning candidate_fractions has invalid keys.")
    if abs(sum(float(value) for value in fractions.values()) - 1.0) > 1.0e-9:
        raise ValueError("Active-learning candidate_fractions must sum to 1.0.")

    cp2k = active_learning.setdefault("cp2k", {})
    if not isinstance(cp2k, dict):
        raise TypeError("'active_learning.cp2k' must be an object.")
    cp2k.setdefault("executable", "cp2k")
    cp2k.setdefault("profile", "pbe_d3_bj")
    cp2k.setdefault("cutoff_Ry", 600)
    cp2k.setdefault("relative_cutoff_Ry", 60)
    cp2k.setdefault("cutoff_test_Ry", [400, 600, 800])
    cp2k.setdefault("scf_tolerance", 1.0e-6)
    cp2k.setdefault("scheduler", "local")
    cp2k["scheduler"] = str(cp2k["scheduler"]).casefold()
    cp2k.setdefault("charge", 0)
    cp2k.setdefault("multiplicity", 1)
    cp2k.setdefault("configuration_reviewed", False)
    if cp2k["scheduler"] not in {"local", "slurm"}:
        raise ValueError("'active_learning.cp2k.scheduler' must be 'local' or 'slurm'.")
    local_cp2k = cp2k.setdefault("local", {})
    if not isinstance(local_cp2k, dict):
        raise TypeError("'active_learning.cp2k.local' must be an object.")
    local_cp2k.setdefault("launcher", "mpirun")
    local_cp2k.setdefault("mpi_processes_per_job", 1)
    local_cp2k.setdefault("omp_threads_per_process", 1)
    local_cp2k.setdefault("max_parallel_jobs", 1)
    for field in (
        "mpi_processes_per_job",
        "omp_threads_per_process",
        "max_parallel_jobs",
    ):
        if not isinstance(local_cp2k[field], int) or local_cp2k[field] <= 0:
            raise ValueError(
                f"'active_learning.cp2k.local.{field}' must be a positive integer."
            )

    campaign = settings.setdefault("campaign", {})
    if not isinstance(campaign, dict):
        raise TypeError("'benchmark.potential_benchmark.campaign' must be an object.")
    campaign.setdefault("id", "module_c_campaign")
    campaign.setdefault("systems", [])
    campaign.setdefault("models", [])
    if not isinstance(campaign["systems"], list):
        raise TypeError("'campaign.systems' must be a list.")
    if not isinstance(campaign["models"], list):
        raise TypeError("'campaign.models' must be a list.")
    stages = campaign.setdefault("stages", {})
    if not isinstance(stages, dict):
        raise TypeError("'campaign.stages' must be an object.")
    stages.setdefault(
        "screening",
        {"method": "widom", "trials": 1_000, "block_size": 100},
    )
    stages.setdefault(
        "widom",
        {
            "method": "widom",
            "trials": 100_000,
            "block_size": 10_000,
            "convergence_checkpoints": [10_000, 25_000, 50_000, 75_000, 100_000],
        },
    )
    stages.setdefault(
        "gcmc_pilot",
        {
            "method": "gcmc",
            "equilibration_steps": 10_000,
            "production_steps": 20_000,
            "pressure_selection": "low_mid_high",
        },
    )
    stages.setdefault(
        "gcmc_production",
        {
            "method": "gcmc",
            "equilibration_steps": 100_000,
            "production_steps": 1_000_000,
        },
    )
