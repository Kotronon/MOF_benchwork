# MOF result snapshot for local consolidation

The outputs/ tree preserves the server's project-relative paths. It contains
result JSON/CSV, plots, status/provenance and analysis metadata across the
selected modules. Code/config snapshots and curated reference metadata are
included. Referenced CRAFTED isotherms found in exported metadata are included.

Start with RESULT_FILES.csv to locate reports, final_assessment.json,
isotherm_summary.csv, reference_metrics.csv and per-module result summaries.
TRANSFER_MANIFEST.json records the source commit, timestamps, checksums and
files omitted. Existing report/convergence status is authoritative: transfer
does not turn a provisional result into a completed validation.

Extract into a NEW directory. Compare paths with your local project before
copying files over existing results. Do not overwrite same-named local runs
blindly. Paths embedded in some original JSON may still name the server; use
the preserved relative tree to resolve matching files. Server absolute paths
have not been rewritten inside scientific provenance.

On Linux/macOS, from this extracted directory:

    shasum -a 256 -c CHECKSUMS.sha256

Code is a snapshot for reference, not a request to replace your local checkout.
Use the recorded git commit to compare versions. Models, training datasets,
checkpoints, environments, large raw comparison arrays, binary MC histories,
full DFT inputs/restarts and technical smoke artifacts are excluded. Therefore
this package is for result consolidation, not rerunning all simulations or
training. Old paths pointing at excluded files are expected.

A CRAFTED table validates the declared comparison against that reference;
retain labels distinguishing reference sources, pressure ranges and sampling
limitations. DFT stop/provisional states are preserved as recorded.
